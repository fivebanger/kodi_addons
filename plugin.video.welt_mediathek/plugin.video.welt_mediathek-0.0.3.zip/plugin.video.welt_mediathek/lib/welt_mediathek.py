# -*- coding: utf-8 -*-

import json
import re
import urllib2
import StringIO
import gzip

from bs4 import BeautifulSoup

import utils
from mediathek import Mediathek



categories = [
    {"name": "Dokumentation", "id": "docu", "url": "https://www.welt.de/mediathek/dokumentation/"},
    {"name": "Reportage", "id": "report", "url": "https://www.welt.de/mediathek/reportage/"},
    {"name": "Magazin", "id": "mag", "url": "https://www.welt.de/mediathek/magazin/"}
]



list_az_mapping = {
                    "09": "0 - 9",
                    "a": "A",
                    "b": "B",
                    "c": "C",
                    "d": "D",
                    "e": "E",
                    "f": "F",
                    "g": "G",
                    "h": "H",
                    "i": "I",
                    "j": "J",
                    "k": "K",
                    "l": "L",
                    "m": "M",
                    "n": "N",
                    "o": "O",
                    "p": "P",
                    "q": "Q",
                    "r": "R",
                    "s": "S",
                    "t": "T",
                    "u": "U",
                    "v": "V",
                    "w": "W",
                    "x": "X",
                    "y": "Y",
                    "z": "Z"
                 }



class WELTMediathek(Mediathek):

    def __init__(self):
        self.img_res_1 = "ci16x9-w880"
        self.img_res_2 = "ci16x9-w600"
        self.delta_t = 0
        self.strm_quality = "high"
        self.mediathek = "welt"
        self.program = "welt"
        self.source_url = ""
        self.curr_char = ""


    def get_categories(self, program):
        result = []
        self.source_url = ""

        for key in categories:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                        
            record["type"] = "category"
            record["mode"] = "get_content_from_categoy"
            record["name"] = key["name"]
            
            record["data"]["target_url"] = key["url"]
            record["data"]["args"]["id"] = key["id"]
            record["data"]["args"]["type"] = "main"
            
            result.append(record)
            
        return result


    def get_shows_by_char(self, program, charakter):
        result = []

        url = "https://www.welt.de/mediathek/sendungen-a-z/"
        content = self._load_json_page(url)
        soup = BeautifulSoup(content, 'html.parser')
        top = soup.find(id='top')
        
        page_container = None
        page_containers = top.find_all('section', class_='c-page-container')
        for item in page_containers:
            headline = item.find('h2', class_='c-stage-header__headline')
            if( None != headline ):
                header_type = headline.text.strip()
                if( "Alle Sendungen" == header_type ):
                    page_container = item
                    break
        
        if( None != page_container ):
            titles = []
            result_unsorted = []
            
            grid_items = page_container.find_all('li', class_='c-grid__item')
            for item in grid_items:                
                teaser_item = item.find('a', class_='o-link')
                target_url = teaser_item.get("href")
                target_url = "https://welt.de" + target_url
            
                title = teaser_item.get("title")
                
                topic = item.find('span', class_='o-topic')
                topic = topic.text.strip()
                    
                if( title.lower().startswith(charakter) ):
                    record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                     
                    record["type"] = "stream_meta_data"
                    record["mode"] = "play_stream"
                    record["name"] = title
                    record["aired"] = ""
                    record["subtitle_url"] = ""
                    record["plot"] = ""
                    record["availability"] = ""
                     
                    record["data"]["target_url"] = target_url
                    record["data"]["duration"] = ""
                    record["data"]["image_url"] = ""
                     
                    record["data"]["args"]["image_url"] = ""
                    record["data"]["args"]["name"] = title
                    record["data"]["args"]["availability"] = ""
                     
                    result_unsorted.append(record)
                    
                    if( title not in titles ):
                        titles.append(title)
            
            titles.sort()
            
            for title in titles:
                for item in result_unsorted:
                    if( title == item["name"] ):
                        result.append(item)

        return result
    

    def get_items_from_content(self, program, url, args):
        self.program = program
        
        result = []
        content = self._load_json_page(url)
        
        result.extend( self._get_sub_categories(content) )
        
        if( "main" == args["type"] ):
            result.extend( self._get_items_from_maincategory(content) )
        elif( "sub" == args["type"] ):
            result.extend( self._get_items_from_subcategory(content) )

        return result
    
    
    def _get_items_from_subcategory(self, content):
        result = []
                
        soup = BeautifulSoup(content, 'html.parser')
        top = soup.find(id='top')
        
        page_containers = top.find_all('section', class_='c-page-container')
        for page_container in page_containers:
            grid_items = page_container.find_all('li', class_='c-grid__item')
            for item in grid_items: 
                target_url = ""
                           
                try: 
                    image_urls = item.find('picture', class_='c-teaser-default__element')
                    image_urls = image_urls.find_all('source')
                     
                    for image_url in image_urls:
                        if( "Large" == image_url.get("data-breakpoint") ):
                            image_url = image_url.get("data-src-template")
                            image_url = image_url.replace("wWIDTH", "w800")
                            break
                 
                    teaser = item.find('h4', class_='o-teaser__title')
                    teaser = teaser.find('a')
                     
                    target_url = teaser.get("href")
                    target_url = "https://welt.de" + target_url
                     
                    title = teaser.text.strip()
                    
                    duration = item.find('li', class_='o-list__item o-list__item--is-inline o-teaser__footer-content-list-item o-list__item--is-separated')
                    duration = duration.text
                    if( "Min" in duration ):
                        duration = duration.replace("Min", "")
                        duration = duration.strip()
                        duration = int(duration) * 60
                    elif( "Sek" in duration ):
                        duration = duration.replace("Sek", "")
                        duration = int(duration.strip())
                    
                    availability = item.find('span', class_='o-teaser__video-available-to')
                    availability = availability.text.strip()
                except:
                    pass
                
                try:
                    image_urls = item.find('picture', class_='c-teaser-media-hero__element o-teaser__element')
                    image_urls = image_urls.find_all('source')
                     
                    for image_url in image_urls:
                        if( "Large" == image_url.get("data-breakpoint") ):
                            image_url = image_url.get("data-src-template")
                            image_url = image_url.replace("wWIDTH", "w800")
                            break
                 
                    teaser = item.find('h4', class_='o-teaser__title')
                    teaser = teaser.find('a')
                     
                    target_url = teaser.get("href")
                    target_url = "https://welt.de" + target_url
                     
                    title = teaser.text.strip()
                    
                    footers = item.find_all('li', class_='c-teaser-media-hero__footer-item')
                    for footer in footers:
                        if( "Teaser.VideoDuration" == footer.get("data-qa") ):
                            duration = footer.text
                            if( "Min" in duration ):
                                duration = duration.replace("Min", "")
                                duration = duration.strip()
                                duration = int(duration) * 60
                            elif( "Sek" in duration ):
                                duration = duration.replace("Sek", "")
                                duration = int(duration.strip())
                        
                        elif( "Teaser.AvailableTo" == footer.get("data-qa") ):
                            availability = footer.text.strip()
                except:
                    pass
        
                if( "" != target_url ):
                    record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                     
                    record["type"] = "stream_meta_data"
                    record["mode"] = "play_stream"
                    record["name"] = title
                    record["aired"] = ""
                    record["subtitle_url"] = ""
                    record["plot"] = ""
                    record["availability"] = availability
                     
                    record["data"]["target_url"] = target_url
                    record["data"]["duration"] = duration
                    record["data"]["image_url"] = image_url
                     
                    record["data"]["args"]["image_url"] = image_url
                    record["data"]["args"]["name"] = title
                    record["data"]["args"]["availability"] = availability
                     
                    result.append(record)
                
        return result
    
    
    def _get_items_from_maincategory(self, content):
        result = []
        
        soup = BeautifulSoup(content, 'html.parser')
        top = soup.find(id='top')
        page_containers = top.find_all('section', class_='c-page-container')
        
        
        for page_container in page_containers:
            slides = page_container.find_all('div', class_='c-swiper__slide')
            
            if( [] != slides ):
                for slide in slides:
                    availability = "No information"
                    
                    image_urls = slide.find('picture', class_='c-teaser-media-hero__element')
                    image_urls = image_urls.find_all('source')
                      
                    for image_url in image_urls:
                        if( "Large" == image_url.get("data-breakpoint") ):
                            image_url = image_url.get("data-src-template")
                            image_url = image_url.replace("wWIDTH", "w800")
                            #image_url = image_url.get("data-srcset")
                            break
                      
                    teaser = slide.find('h4', class_='o-teaser__title')
                    teaser = teaser.find('a')
                      
                    target_url = teaser.get("href")
                    target_url = "https://welt.de" + target_url
                      
                    title = teaser.text.strip()
                    
                    durations = slide.find_all('li', class_='c-teaser-media-hero__footer-item')
                    
                    for item in durations:
                        if( "Teaser.VideoDuration" == item.get("data-qa") ):
                            duration = item.text
                            if( "Min" in duration ):
                                duration = duration.replace("Min", "")
                                duration = duration.strip()
                                duration = int(duration) * 60
                            elif( "Sek" in duration ):
                                duration = duration.replace("Sek", "")
                                duration = int(duration.strip())
                            
                        if( "Teaser.AvailableTo" == item.get("data-qa") ):
                            availability = item.text.strip()
            
                    record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                     
                    record["type"] = "stream_meta_data"
                    record["mode"] = "play_stream"
                    record["name"] = title
                    record["aired"] = ""
                    record["subtitle_url"] = ""
                    record["plot"] = ""
                    record["availability"] = availability
                     
                    record["data"]["target_url"] = target_url
                    record["data"]["duration"] = duration
                    record["data"]["image_url"] = image_url
                     
                    record["data"]["args"]["image_url"] = image_url
                    record["data"]["args"]["name"] = title
                    record["data"]["args"]["availability"] = availability
                     
                    result.append(record)
            
            else:
                grid_items = page_container.find_all('li', class_='c-grid__item')
                 
                for item in grid_items:
                    try:
                        availability = "No information"
                        
                        image_urls = item.find('picture', class_='c-teaser-default__element')
                        image_urls = image_urls.find_all('source')
                         
                        for image_url in image_urls:
                            if( "Large" == image_url.get("data-breakpoint") ):
                                image_url = image_url.get("data-src-template")
                                image_url = image_url.replace("wWIDTH", "w800")
                                #image_url = image_url.get("data-srcset")
                                break
                         
                        teaser = item.find('h4', class_='o-teaser__title')
                        teaser = teaser.find('a')
                         
                        target_url = teaser.get("href")
                        target_url = "https://welt.de" + target_url
                         
                        title = teaser.text.strip()
                        
                        duration = item.find('li', class_='o-list__item o-list__item--is-inline o-teaser__footer-content-list-item o-list__item--is-separated')
                        duration = duration.text
                        if( "Min" in duration ):
                            duration = duration.replace("Min", "")
                            duration = duration.strip()
                            duration = int(duration) * 60
                        elif( "Sek" in duration ):
                            duration = duration.replace("Sek", "")
                            duration = int(duration.strip())
                        
                        availability = item.find('span', class_='o-teaser__video-available-to')
                        availability = availability.text.strip()
                
                        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                         
                        record["type"] = "stream_meta_data"
                        record["mode"] = "play_stream"
                        record["name"] = title
                        record["aired"] = ""
                        record["subtitle_url"] = ""
                        record["plot"] = ""
                        record["availability"] = availability
                         
                        record["data"]["target_url"] = target_url
                        record["data"]["duration"] = duration
                        record["data"]["image_url"] = image_url
                         
                        record["data"]["args"]["image_url"] = image_url
                        record["data"]["args"]["name"] = title
                        record["data"]["args"]["availability"] = availability
                         
                        result.append(record)
                    except:
                        pass
                    
        return result
    
    
    def _get_sub_categories(self, content):
        result = []
        
        soup = BeautifulSoup(content, 'html.parser')
        results = soup.find(id='top')
        page_containers = results.find_all('section', class_='c-page-container')
        
        for page_container in page_containers:
            stage_header = page_container.find('div', class_='c-stage-header')
            
            if( None != stage_header ):
                target_url = stage_header.find('a', class_='o-link')
        
                if( None != target_url ):
                    target_url = target_url.get('href')
                    target_url = "https://welt.de" + target_url
                    
                    title = page_container.find('h2', class_='c-stage-header__headline')
                    title = title.text.strip()
                        
                    record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                                
                    record["type"] = "category"
                    record["mode"] = "get_content_from_categoy"
                    record["name"] = title
                    
                    record["data"]["target_url"] = target_url
                    record["data"]["args"]["id"] = "void"
                    record["data"]["args"]["type"] = "sub"
                    
                    result.append(record)
        
        return result


    def get_stream_data(self, program, url, args, quality="high"):
        self.program = program
        result = []
        stream_mp4 = []
        
        
        content = self._load_json_page(url)
        soup = BeautifulSoup(content, 'html.parser')
        main = soup.find("main", class_="c-page-container c-page-container--has-detailed-content")
        stream_urls = main.find_all("script")
        
        
        for item in stream_urls:
            if( "VideoPlayer.Config" == item.get("data-qa") ):
                stream_urls = item.text
                stream_urls = json.loads(stream_urls)
                stream_urls = stream_urls["sources"]
                
                for item in stream_urls:
                    if( "mp4" == item["extension"] ):
                        stream_mp4.append(item["src"])

        quality_mapping = {"low": 2, "medium": 1, "high": 0}
        quality = quality_mapping[quality]
        target_url = ""
        
        try:
            target_url = stream_mp4[quality]
        except:
            pass

        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
        
        record["type"] = "play_stream"
        record["mode"] = "end"
        record["name"] = args["name"]
        record["subtitle_url"] = ""
        record["plot"] = ""
        record["availability"] = args["availability"]
        record["aired"] = ""
        
        record["data"]["duration"] = ""
        record["data"]["image_url"] = args["image_url"]
        record["data"]["target_url"] = target_url
        record["data"]["args"] = args
                
        result.append(record)
        return result




    def _load_json_page(self, url, headers=None):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")
        req = urllib2.Request(self.source_url)

        if( headers ):
            for key in headers:
                req.add_header(key, headers[key])
            req.has_header = lambda header_name: (True if header_name == 'Content-Length' else urllib2.Request.has_header(req, header_name))
        else:
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0')
            req.add_header('Accept-Encoding','gzip, deflate')
        
        response = urllib2.urlopen(req)

        compressed = response.info().get('Content-Encoding') == 'gzip'
        result = response.read()
        response.close()
        
        if( compressed ):
            buf = StringIO.StringIO(result)
            f = gzip.GzipFile(fileobj=buf)
            result = f.read()
        
        
        if( "<!doctype html>" in result[:40].lower() ):
            #jresult = self._extract_json(result)
            jresult = result
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""
        
        return jresult


    def _extract_json(self, html):
        try:
            content = re.compile("__INITIAL_STATE__ = ({.*});").search(html).group(1)
            content = json.loads(content)
        except:
            content = ""
        return content

    
    
    