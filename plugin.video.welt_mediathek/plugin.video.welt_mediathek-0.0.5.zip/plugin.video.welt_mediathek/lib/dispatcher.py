
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os
import json

try:
    # Python 3
    from urllib.parse import quote
except ImportError:
    # Python 2
    from urllib import quote

from mediathek_handler import MediathekHandler
from list_item import ListItem
from data import Data
import utils


log_level = xbmc.LOGDEBUG

quality_mapping = {"0": "low", "1": "medium", "2": "high"}


class Dispatcher():
    
    def __init__(self, addon_path, addon_id, addon_handle, addon_args):
        self.addon_path = addon_path
        self.addon_id = addon_id
        self.addon = xbmcaddon.Addon(addon_id)
        self.addon_handle = addon_handle
        self.addon_args = addon_args

            
    def route(self):
        result = []
        mh = MediathekHandler()

        addon_args = self.addon_args
        
        if {} == addon_args:
            mode = 'get_programs'
            data = {}
        else:
            mode = addon_args['mode']
            data = addon_args['data']
            data = json.loads(data)
            
        xbmc.log('[PubTV]: Dispatcher mode: %s, addon_args: %s' %(mode, addon_args), xbmc.LOGDEBUG)
        
        if( "new_search" == mode ):
            search_str = self._get_search_str()
            if( "" == search_str ):
                return
            
            self._add_to_search_history(search_str, data)
            search_str = quote(search_str)
            mh.set_search_string(search_str)
            mode = "get_search_result"
        
        quality = self.addon.getSetting("quality")
        mh.set_stream_quality(quality_mapping[quality])
        
        
        if( "get_programs" == mode ):
            result = mh.get_programs()
            result = self._filter_program(result)

        elif( "get_menu" == mode ):
            result = mh.get_menu(data)
        
        elif( "list_categories" == mode ):
            result = mh.list_categories(data)
        
        elif( "list_dates" == mode ):
            result = mh.list_dates(data)
        
        elif( "get_shows_by_date" == mode ):
            result = mh.get_shows_by_date(data)
        
        elif( "list_az" == mode ):
            result = mh.list_az(data)
        
        elif( "get_shows_by_char" == mode ):
            result = mh.get_shows_by_char(data)
        
        elif( "search" == mode ):
            result = self._get_search_menu(data)
        
        elif( "get_search_result" == mode ):
            result = mh.search(data)
        
        elif( "get_search_result_from_data" == mode ):
            search_str = quote(data["args"]["name"])
            mh.set_search_string(search_str)
            result = mh.search(data)
        
        elif( "get_content" == mode ):
            result = mh.get_content(data)
        
        elif( "get_content_from_categoy" == mode ):
            result = mh.get_items_from_content(data)
        
        elif( "play_stream" == mode ):
            result = mh.play_stream(data)
        
        elif( "get_my_list" == mode ):
            result = self._load_my_list()
        
        elif( "get_recently" == mode ):
            result = self._load_recently()
        
        elif( "add_to_list" == mode ):
            self._add_to_my_list(data)
            return
        
        elif( "remove_from_list" == mode ):
            self._remove_from_my_list(data)
            return
        
        elif( "clear_search_history" == mode ):
            self._clear_search_history()
            return
        
        elif( "remove_search" == mode ):
            self._remove_from_search_history(data)
            return
        
        elif( "get_all_programs" == mode ):
            result = mh.get_programs()
        
        elif( "hide_program" == mode ):
            self._hide_program(data)
            #result = mh.get_programs()
            return
        
        elif( "show_program" == mode ):
            self._show_program(data)
            #result = mh.get_programs()
            return
        
        elif( "show_availability" == mode ):
            result = mh.play_stream(data["data"])
            self._show_availability(result)
            return
        
        elif( "remove_recently" == mode ):
            self._remove_from_recently(data)
            return
        
        elif( "home" == mode ):
            xbmc.executebuiltin( "Container.Update(plugin://plugin.video.welt_mediathek, replace)" )
            return
        
        else:
            xbmc.log('[PubTV]: Dispatcher wrong mode: %s' %(mode), xbmc.LOGERROR)
            return
        
        #hmk result = mh.handle_mode(mode, data)

        list_item = ListItem(self.addon_id, self.addon_handle, self.addon_path)
        
        
        fanart_url = ""
        icon_url = ""


        for key in result:
            name = key["name"]
            data = json.dumps(key["data"])
            cm_data = json.dumps(key)
            
            if( "get_shows_by_date" == mode ):
                name = "(%s:%s) %s" %(key["aired"]["hour"], key["aired"]["min"], key["name"])

            if( "category" == key["type"] ):
            
            
        
                fanart = key["data"]["program"] + ".jpg"
                icon = key["data"]["program"] + ".png"
                
                fanart = "resources/fanart/" + fanart
                icon = "resources/icons/" + icon
                
                if( ("get_programs" == mode) or
                    ("get_all_programs" == mode) ):
                    #fanart_url = os.path.join(self.addon.getAddonInfo('path'), fanart)
                    icon_url = os.path.join(self.addon.getAddonInfo('path'), icon)
                else:
                    fanart_url = os.path.join(self.addon.getAddonInfo('path'), fanart)
                    #icon_url = os.path.join(self.addon.getAddonInfo('path'), icon)
                    
                #hmk icon_url = os.path.join(self.addon.getAddonInfo('path'), icon)
                
                if( "true" == self.addon.getSetting("category_fanart") ):
                    if( "" != key["data"]["image_url"] ):
                        #fanart_url = key["data"]["image_url"]
                        icon_url = key["data"]["image_url"]
                                      
                #list_item.cm_none()
                if( "get_my_list" != mode ):
                    if( ("get_content" == key["mode"]) or
                        ("get_content_from_categoy" == key["mode"]) ):
                        cm_type = "main_menu"
                        cm_name = "Add to my list"
                        cm_mode = "add_to_list"
                        list_item.cm_menu(cm_type, cm_name, cm_mode, cm_data)
                        
                    elif( ("get_programs" == mode) and
                          ("get_menu" == key["mode"]) ):
                        cm_type = "main_menu"
                        cm_name = "Hide program"
                        cm_mode = "hide_program"
                        list_item.cm_menu(cm_type, cm_name, cm_mode, cm_data)
                        
                    elif( "get_all_programs" == mode ):
                        if( "false" == self.addon.getSetting(key["data"]["program"]) ):
                            cm_type = "main_menu"
                            cm_name = "Show program"
                            cm_mode = "show_program"
                            list_item.cm_menu(cm_type, cm_name, cm_mode, cm_data)
                        else:
                            cm_type = "main_menu"
                            cm_name = "Hide program"
                            cm_mode = "hide_program"
                            list_item.cm_menu(cm_type, cm_name, cm_mode, cm_data)
                        
                    elif( "new_search" == key["mode"] ):
                        cm_type = "main_menu"
                        cm_name = "Clear search history"
                        cm_mode = "clear_search_history"
                        list_item.cm_menu(cm_type, cm_name, cm_mode, cm_data)
                        
                    elif( "get_search_result_from_data" == key["mode"] ):
                        cm_type = "main_menu"
                        cm_name = "Remove search"
                        cm_mode = "remove_search"
                        list_item.cm_menu(cm_type, cm_name, cm_mode, cm_data)
                else:
                    cm_type = "main_menu"
                    cm_name = "Remove from my list"
                    cm_mode = "remove_from_list"
                    list_item.cm_menu(cm_type, cm_name, cm_mode, cm_data)
                    
                if( ("get_content" == key["mode"]) or
                    ("get_content_from_categoy" == key["mode"]) ):
                    cm_type = "main_menu"
                    cm_name = "Home"
                    cm_mode = "home"
                    list_item.cm_menu_add(cm_type, cm_name, cm_mode, cm_data)
                
                list_item.addon_path({'mode': key["mode"], "data": data})
                list_item.menu('main', name, icon_url, fanart_url)
            
            elif( "stream_meta_data" == key["type"] ):
                cm_type = "main_menu"
                cm_name = "Available to"
                cm_mode = "show_availability"
                list_item.cm_menu(cm_type, cm_name, cm_mode, cm_data)
                
                if( "get_recently" == mode ):
                    cm_type = "main_menu"
                    cm_name = "Remove"
                    cm_mode = "remove_recently"
                    list_item.cm_menu_add(cm_type, cm_name, cm_mode, cm_data)
                    
                cm_type = "main_menu"
                cm_name = "Home"
                cm_mode = "home"
                list_item.cm_menu_add(cm_type, cm_name, cm_mode, cm_data)
                
                if( "" == key["data"]["image_url"] ):
                    icon_url = ""
                    fanart_url = os.path.join(self.addon.getAddonInfo('path'), "fanart.jpg")
                else:
                    icon_url = key["data"]["image_url"]
                    fanart_url = key["data"]["image_url"]
                        
                list_item.addon_path({'mode': key["mode"], "data": data})
                list_item.stream_new(name, key["data"]["target_url"], key["data"]["duration"], icon_url, fanart_url, key["plot"])

            elif( "play_stream" == key["type"] ):
                self._play_stream(result[0])
                return
        
            else:
                xbmc.log('[PubTV]: Dispatcher route: wrong mode: %s' %mode, xbmc.LOGERROR)
        
        
        if( "true" == self.addon.getSetting("use_thumbnail") ):
            xbmc.executebuiltin( "Container.SetViewMode(500)" )
        else:
            xbmc.executebuiltin( "Container.SetViewMode(0)" )
            
        list_item.end_of_directory()
    
    
    def _play_stream(self, result):
        stream_url = result["data"]["target_url"]
        play_item = xbmcgui.ListItem(path=stream_url)
        
        if( "" == stream_url ):
            xbmc.log('[PubTV]: Dispatcher play error: %s' %(result), xbmc.LOGERROR)
            xbmcplugin.setResolvedUrl(self.addon_handle, False, listitem=play_item)
            
            info = "Kein Video-Stream zur Wiedergabe gefunden"
            if( "" != result["availability"] ):
                info = result["availability"]
                
            dialog = xbmcgui.Dialog()
            dialog.ok('Play error', info)
        else:
            xbmc.log('[PubTV]: Play video stream: %s' %(stream_url), xbmc.LOGINFO)
            icon = result["data"]["image_url"]
            play_item.setLabel(result["name"])
            play_item.setArt({'thumb': icon, 'icon': icon, 'fanart': icon})
            self._add_to_recently(result)
            xbmcplugin.setResolvedUrl(self.addon_handle, True, listitem=play_item)

    
    def _filter_program(self, result):
        list_all = False
        data = []
        
        record = utils.get_new_record("none", "none", "none")
        record["type"] = "category"
        record["mode"] = "get_my_list"
        record["name"] = "My list"
        record["data"]["program"] = "list"
        data.append(record)
        
        record = utils.get_new_record("none", "none", "none")
        record["type"] = "category"
        record["mode"] = "get_recently"
        record["name"] = "Recently watched"
        record["data"]["program"] = "list"
        data.append(record)
        
        for key in result:
#             if( "true" == self.addon.getSetting(key["data"]["program"]) ):
#                 data.append(key)
#             else:
#                 list_all = True
            data.append(key)
            
        if( list_all ):
            record = utils.get_new_record("none", "none", "none")
            record["type"] = "category"
            record["mode"] = "get_all_programs"
            record["name"] = "Show all programs"
            record["data"]["program"] = "list"
            data.insert(2, record)

        return data

    
    def _hide_program(self, data):
        addon = xbmcaddon.Addon(self.addon_id)
        addon.setSetting(data["data"]["program"], "false")
        xbmc.executebuiltin( "Container.Refresh" )

    
    def _show_program(self, data):
        addon = xbmcaddon.Addon(self.addon_id)
        addon.setSetting(data["data"]["program"], "true")
        xbmc.executebuiltin( "Container.Update(%s, replace)" %(self.addon_path) )
    
    
    def _load_recently(self):
        list_type = "categories"
        filename = "recent"
        path = "profile"
        d = Data()
        result = d.load_list(list_type, filename, path)
        return result
    
    
    def _add_to_recently(self, data, max_items=50):
        data_copy = data.copy()
        
        
        data_copy["data"]["target_url"] = data_copy["source_url"]
        data_copy["type"] = "stream_meta_data"
        data_copy["mode"] = "play_stream"
        
#         if( "zdf" == data_copy["data"]["mediathek"] ):
#             data_copy["data"]["program"] = "ZDF"
#         
#         mh = MediathekHandler()
#         program = mh.get_program_name(data_copy["data"]["program"])
#         data_copy["name"] = program + " | " + data_copy["name"]
        data_copy["name"] = data_copy["name"]
        
        list_type = "categories"
        filename = "recent"
        path = "profile"
        d = Data()
        result = d.load_list(list_type, filename, path)
        
        if( [] != result ):
            for key in result:
                if( key["name"] == data_copy["name"] ):
                    return
        
        result.insert(0, data_copy)
        if( max_items < len(result) ):
            result.pop()
            
        d.save_list(type, filename, result, result, path)
    
    
    def _remove_from_recently(self, data):
        list_type = "categories"
        filename = "recent"
        path = "profile"
        d = Data()
        result = d.load_list(list_type, filename, path)
        
        for key in result:
            if( key["name"] == data["name"] ):
                result.remove(key)
                d.save_list(type, filename, result, result, path)
                xbmc.executebuiltin( "Container.Refresh" )
                break
    
    
    def _load_my_list(self):
        list_type = "categories"
        filename = "list"
        path = "data"
        d = Data()
        result = d.load_list(list_type, filename, path)
        return result
    
    
    def _add_to_my_list(self, data):
        data_copy = data.copy()
#         mh = MediathekHandler()
#         
#         if( "zdf" == data_copy["data"]["mediathek"] ):
#             data_copy["data"]["program"] = "ZDF"
        
        name = data_copy["name"]
#         program = mh.get_program_name(data_copy["data"]["program"])
#         data_copy["name"] = program + " | " + name
        data_copy["name"] = name
        
        list_type = "categories"
        filename = "list"
        path = "data"
        d = Data()
        result = d.load_list(list_type, filename, path)
        
        if( [] != result ):
            for key in result:
                if( key["name"] == data_copy["name"] ):
                    heading = name
                    message = "Already added to list"
                    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING)
                    return
        
        result.insert(0, data_copy)
        #result.append(data_copy)
        d.save_list(type, filename, result, result, path)
        
        heading = name
        message = "Added to list"
        icon = os.path.join(self.addon.getAddonInfo('path'), "icon.png")
        xbmcgui.Dialog().notification(heading, message, icon)
    
    
    def _remove_from_my_list(self, data):
        list_type = "categories"
        filename = "list"
        path = "data"
        d = Data()
        result = d.load_list(list_type, filename, path)
        
        for key in result:
            if( key["name"] == data["name"] ):
                result.remove(key)
                d.save_list(type, filename, result, result, path)
                xbmc.executebuiltin( "Container.Refresh" )
                break


    def _get_search_menu(self, data):
            result = []
            
            history = self._load_search_history(data)
            mediathek = data["mediathek"]
            program = data["program"]
            
            record = utils.get_new_record(mediathek, program, "")
            record["type"] = "category"
            record["mode"] = "new_search"
            record["name"] = "New search"
            record["data"] = data
            result.append(record)
            
            for key in history:
                record = utils.get_new_record(mediathek, program, "")
                record["type"] = "category"
                record["mode"] = "get_search_result_from_data"
                record["name"] = key["args"]["name"]
                record["data"] = key
                record["data"]["mediathek"]= data["mediathek"]
                record["data"]["program"]= data["program"]
                result.append(record)
            
            return result
    
    
    def _load_search_history(self, data):
        list_type = "search"
        filename = "search"
        path = "profile"
        d = Data()
        result = d.load_list(list_type, filename, path)
        return result
    
    
    def _add_to_search_history(self, search_str, data, max_items=20):
        list_type = "search"
        filename = "search"
        path = "profile"
        d = Data()
        result = d.load_list(list_type, filename, path)
        
        if( [] != result ):
            for key in result:
                if( key["args"]["name"].lower() == search_str.lower() ):
                    return
        
        data["args"]["name"] = search_str
        result.insert(0, data)
        if( max_items < len(result) ):
            result.pop()

        d.save_list(type, filename, result, result, path)
    
    
    def _remove_from_search_history(self, data):
        list_type = "search"
        filename = "search"
        path = "profile"
        d = Data()
        result = d.load_list(list_type, filename, path)
        
        for key in result:
            if( key["args"]["name"] == data["data"]["args"]["name"] ):
                result.remove(key)
                d.save_list(type, filename, result, result, path)
                xbmc.executebuiltin( "Container.Refresh" )
                break
    
    
    def _clear_search_history(self):
        result = []
        filename = "search"
        path = "profile"
        d = Data()
        d.save_list(type, filename, result, result, path)
        xbmc.executebuiltin( "Container.Refresh" )


    def _get_search_str(self):
        return self._get_text_from_keyboard("Search", "")
    
    
    def _show_availability(self, data):
        result = data[0]["availability"]
        dialog = xbmcgui.Dialog()
        dialog.ok('Available info', result)

    
    def _get_text_from_keyboard(self, heading="", text="", hidden=False):
        string = ""
        keyboard = xbmc.Keyboard(text, heading)
        keyboard.setHiddenInput(hidden)
        keyboard.doModal()
        if keyboard.isConfirmed():
            string = keyboard.getText()
        return string
        