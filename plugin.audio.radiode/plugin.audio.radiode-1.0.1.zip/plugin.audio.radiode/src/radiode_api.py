
import logging
import json

from urllib.request import urlopen, Request
from urllib.parse import quote


REGIONS = {
    'at': 'de-AT',
    'au': 'en-AU',
    'br': 'pt-BR',
    'ca': 'en-CA',
    'co': 'es-CO',
    'de': 'de-DE',
    'dk': 'da-DK',
    'es': 'es-ES',
    'fr': 'fr-FR',
    'ie': 'en-IE',
    'it': 'it-IT',
    'mx': 'es-MX',
    'nl': 'nl-NL',
    'nz': 'en-NZ',
    'pl': 'pl-PL',
    'pt': 'pt-PT',
    'se': 'sv-SE',
    'uk': 'en-GB',
    'us': 'en-US',
    'za': 'en-ZA',
}


class RadioDEApi():
    
    def __init__(self, language='de'):
        self.language = REGIONS[language]
        self.user_agent = 'Radio.net - Web V5'
        self.base_url = 'https://prod.radio-api.net'
        self.logger = logging.getLogger('radio_api')
    
    
    def set_logger(self, logger):
        self.logger = logger
    
    
    def search(self, query, count=20, offset=0):
        query = quote(query)
        url = self.base_url + f'/stations/search?query={query}&count={count}&offset={offset}'
        return self._open_url(url)
    
    
    def get_similar(self, station, count=20):
        url = self.base_url + f'/stations/{station}/similar?count={count}' 
        return self._open_url(url)
    
    
    def get_family(self, station, count=20, offset=0):
        url = self.base_url + f'/stations/{station}/family?count={count}&offset={offset}'
        return self._open_url(url)
    
    
    def get_local_stations(self, count=20, offset=0):
        url = self.base_url + f'/stations/local?count={count}&offset={offset}'
        return self._open_url(url)
    
    
    def get_tags(self):
        url = self.base_url + f'/stations/tags'
        return self._open_url(url)
    
    
    def get_genres(self):
        url = self.base_url + f'/stations/shortlist?tagType=genre'
        return self._open_url(url)
    
    
    def get_topics(self):
        url = self.base_url + f'/stations/shortlist?tagType=topic'
        return self._open_url(url)
    
    
    def get_cities(self):
        url = self.base_url + f'/stations/shortlist?tagType=city'
        return self._open_url(url)
    
    
    def get_countries(self):
        url = self.base_url + f'/stations/shortlist?tagType=country'
        return self._open_url(url)
    
    
    def get_stations_by_char(self, char, count=20, offset=0):
        url = self.base_url + f'/stations/all?character={char}&count={count}&offset={offset}'
        return self._open_url(url)
    
    
    def get_now_playing(self, station):
        url = self.base_url + f'/stations/now-playing?stationIds={station}'
        return self._open_url(url)
    
    
    def get_songs(self, station):
        url = self.base_url + f'/stations/{station}/songs'
        return self._open_url(url)
    
    
    def get_station_details(self, station):
        url = self.base_url + f'/stations/details?stationIds={station}'
        result = self._open_url(url)
        result = result[0]
        return result
    
    
    def get_stations_details(self, stations):
        return self.base_url + f'/stations/details?stationIds={stations}'
    
    
    def get_stations_by_genre(self, genre, count=20, offset=0):
        url = self.base_url + f'/stations/by-tag?tagType=genres&slug={genre}&count={count}&offset={offset}'
        return self._open_url(url)
    
    
    def get_stations_by_city(self, city, count=20, offset=0):
        url = self.base_url + f'/stations/cities/{city}/frequencies'
        return self._open_url(url)
    
    
    def get_stations_by_topic(self, topic, count=20, offset=0):
        url = self.base_url + f'/stations/by-tag?tagType=topics&slug={topic}&count={count}&offset={offset}'
        return self._open_url(url)
    
    '''
    def get_stations_by_country(self, country, count=20, offset=0):
        url = self.base_url + f'/stations/by-tag?tagType=genres&slug={genre}&count={count}&offset={offset}'
        return self._open_url(url)
    '''


    def resolve_url(self, url):
        try:
            result = urlopen(url)
            new_url = result.geturl()

            if 'm3u' in new_url:
                req = Request(new_url)
                response = urlopen(req, timeout=2).read()
                response = response.decode()
                response = response.split('\n')
                
                new_url = None
                for item in response:
                    if item.startswith('http'):
                        new_url = item
                        break
        except Exception as err:
            self.logger.error(f'resolve_url error: {err}')
            new_url = None
        
        return new_url


    def _open_url(self, url):
        result = []
        self.logger.debug(f'_open_url: {url}')
        try:
            req = Request(url)
            req.add_header('accept-language', self.language)
            req.add_header('user-agent', self.user_agent)
            response = urlopen(req).read()
        except Exception as err:
            self.logger.error(f'_open_url error: {err}')
            response = b''
            
        try:
            result = json.loads(response)
        except Exception as err:
            self.logger.error(f'_open_url error: {err}')
            
        return result



