
import os
import xbmcaddon
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs


from addon_utils import ListItem, DataHandler, get_text_from_keyboard, AddonLogger
from radiode_api import RadioDEApi


CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))


SEARCH_MENU = [
    {'mode': 'do_search', 'data': {'name': 'New search', 'query': '', 'cm': None}},
]

MAIN_MENU =  [
    {'mode': 'get_my_stations', 'data': {'name': 'My stations'}},
    {'mode': 'get_recently', 'data': {'name': 'Recently played'}},
    {'mode': 'search_station', 'data': {'name': 'Search', 'query': ''}},
    {'mode': 'get_local_stations', 'data': {'name': 'Local stations'}},
    {'mode': 'get_genres', 'data': {'name': 'Browse by genre'}},
    {'mode': 'get_topics', 'data': {'name': 'Browse by topic'}},
    {'mode': 'get_countries', 'data': {'name': 'Browse by country'}},
    {'mode': 'get_cities', 'data': {'name': 'Browse by city'}},
    {'mode': 'get_regions', 'data': {'name': 'Browse by region'}},
    {'mode': 'get_languages', 'data': {'name': 'Browse by language'}},
    #============================================================================================
    # testing only
    #============================================================================================
    # {'mode': '_test_search', 'data': {'name': '_test_search'}},
    # {'mode': '_test_get_similar', 'data': {'name': '_test_get_similar'}},
    # {'mode': '_test_get_family', 'data': {'name': '_test_get_family'}},
    # {'mode': '_test_get_local_stations', 'data': {'name': '_test_get_local_stations'}},
    # {'mode': '_test_get_genres', 'data': {'name': '_test_get_genres'}},
    # {'mode': '_test_get_cities', 'data': {'name': '_test_get_cities'}},
    # {'mode': '_test_get_countries', 'data': {'name': '_test_get_countries'}},
    # {'mode': '_test_get_stations_by_char', 'data': {'name': '_test_get_stations_by_char'}},
    # {'mode': '_test_get_now_playing', 'data': {'name': '_test_get_now_playing'}},
    # {'mode': '_test_get_songs', 'data': {'name': '_test_get_songs'}},
    # {'mode': '_test_get_station_details', 'data': {'name': '_test_get_station_details'}},
    # {'mode': '_test_get_stations_by_genre', 'data': {'name': '_test_get_stations_by_genre'}},
    # {'mode': '_test_get_stations_by_city', 'data': {'name': '_test_get_stations_by_city'}},
    # {'mode': '_test_get_topics', 'data': {'name': '_test_get_topics'}},
    # {'mode': '_test_get_stations_by_topic', 'data': {'name': '_test_get_stations_by_topic'}},
    # {'mode': '_test_get_tags', 'data': {'name': '_test_get_tags'}},
]

CM_MAP = {
    # !!! don't rename keys (search_cm, recently_cm, add_station, remove_station) !!!
    # !!! keys are maybe used in legacy v1.0.1 lists (data: {'cm': key}) !!! 
    'search_cm': [
        {'name': 'Remove from search', 'mode': 'remove_from_serach', 'data': {}, 'action': 'RunPlugin'},
    ],
    'recently_cm': [
        {'name': 'Add to my stations', 'mode': 'add_to_stations', 'data': {}, 'action': 'RunPlugin'},
        {'name': 'Show similar stations', 'mode': 'get_similar', 'data': {}, 'action': 'Container.Refresh'},
        {'name': 'Show station family', 'mode': 'get_family', 'data': {}, 'action': 'Container.Refresh'},
        {'name': 'Add to IPTV Simple', 'mode': 'add_to_iptv', 'data': {}, 'action': 'RunPlugin'},
        {'name': 'Recently played songs', 'mode': 'recently_played_songs', 'data': {}, 'action': 'RunPlugin'},
        {'name': 'Remove from recently', 'mode': 'remove_from_recently', 'data': {}, 'action': 'RunPlugin'},
    ],
    'add_station': [
        {'name': 'Add to my stations', 'mode': 'add_to_stations', 'data': {}, 'action': 'RunPlugin'},
        {'name': 'Show similar stations', 'mode': 'get_similar', 'data': {}, 'action': 'Container.Refresh'},
        {'name': 'Show station family', 'mode': 'get_family', 'data': {}, 'action': 'Container.Refresh'},
        {'name': 'Add to IPTV Simple', 'mode': 'add_to_iptv', 'data': {}, 'action': 'RunPlugin'},
        {'name': 'Recently played songs', 'mode': 'recently_played_songs', 'data': {}, 'action': 'RunPlugin'},
    ],
    'remove_station': [
        {'name': 'Show similar stations', 'mode': 'get_similar', 'data': {}, 'action': 'Container.Refresh'},
        {'name': 'Show station family', 'mode': 'get_family', 'data': {}, 'action': 'Container.Refresh'},
        {'name': 'Remove from my stations', 'mode': 'remove_from_stations', 'data': {}, 'action': 'RunPlugin'},
        {'name': 'Add to IPTV Simple', 'mode': 'add_to_iptv', 'data': {}, 'action': 'RunPlugin'},
        {'name': 'Recently played songs', 'mode': 'recently_played_songs', 'data': {}, 'action': 'RunPlugin'},
    ]
}




class RadioDE():
    
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.addon_path = None
        self.addon_handle = None
        self.min_cnt = 100
        self.log_name = 'radio.de'
        self.icon = os.path.join(CURRENT_DIR, '..', 'icon.png')
        self.fanart = os.path.join(CURRENT_DIR, '..', 'fanart.jpg')
        
        self.search_list = 'search'
        self.recent_list = 'recent'
        self.my_stations_list = 'stations'
        
        self.dh = DataHandler()
        self.dh.register_path(self.my_stations_list, '/.radiode', 'use_xchange_folder', 'xchange_folder')
    
    
    def set_addon_data(self, addon_path, addon_handle):
        self.addon_path = addon_path
        self.addon_handle = addon_handle
        
        self.min_cnt = self.addon.getSettingInt('min_cnt')
        region = self.addon.getSetting('radio_region').lower()
        self.radio = RadioDEApi(region)


    def root(self, data):
        self._handle_result('menu_list', MAIN_MENU)
    
    
    def recently_played_songs(self, data):
        station = data['id']
        api_result = self.radio.get_songs(station)
        
        songs = ''
        for item in api_result[:4]:
            songs += f'{item["rawInfo"]}\n'
        
        dialog = xbmcgui.Dialog()
        dialog.ok("Recently played songs:", songs[:-1])
    
    
    def search_station(self, data):
        result = SEARCH_MENU
        history = self.dh.load_list(self.search_list)
        result.extend(history)
        self._handle_result('menu_list', result, 'search_cm')
    
    
    def do_search(self, data):
        query = data['query']
        count, offset = self._get_count(data)
        
        if '' == query:
            query = get_text_from_keyboard()
            self._add_to_search(query)

        api_result = self.radio.search(query, count, offset)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'do_search', query=query)
        self._handle_result('stations_list', result, 'add_station')
        
        
    def remove_from_serach(self, data):
        result = self.dh.load_list(self.search_list)
        
        for item in result:
            if item['data']["query"] == data['query']:
                result.remove(item)
                self.dh.save_list(self.search_list, result)
                xbmc.executebuiltin( "Container.Refresh" )
                break
    
    
    def get_similar(self, data):
        station = data['id']
        count, offset = self._get_count(data, 50, 0)
        api_result = self.radio.get_similar(station, count)
        result = self._unify_stations(api_result)
        self._handle_result('stations_list', result, 'add_station')
    
    
    def get_family(self, data):
        station = data['id']
        api_result = self.radio.get_family(station, 50)
        result = self._unify_stations(api_result)
        self._handle_result('stations_list', result, 'add_station')
    
    
    def get_local_stations(self, data):
        count, offset = self._get_count(data)
        api_result = self.radio.get_local_stations(count, offset)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_local_stations')
        self._handle_result('stations_list', result, 'add_station')
    
    
    def get_genres(self, data):
        api_result = self.radio.get_shortlist_genres()
        result = self._unify_menu(api_result, 'get_stations_by_genre')
        self._handle_result('menu_list', result)
        
    
    def get_stations_by_genre(self, data):
        genre = data['slug']
        count, offset = self._get_count(data)
        api_result = self.radio.get_stations_by_genre(genre, count, offset)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_genre', slug=genre)
        self._handle_result('stations_list', result, 'add_station')
    
    
    def get_topics(self, data):
        api_result = self.radio.get_shortlist_topics()
        result = self._unify_menu(api_result, 'get_stations_by_topic')
        self._handle_result('menu_list', result)
    
    
    def get_stations_by_topic(self, data):
        topic = data['slug']
        count, offset = self._get_count(data)
        api_result = self.radio.get_stations_by_topic(topic, count, offset)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_topic', slug=topic)
        self._handle_result('stations_list', result, 'add_station')
    
    
    def get_countries(self, data):
        api_result = self.radio.get_countries(self.min_cnt)
        result = self._unify_menu(api_result, 'get_stations_by_country')
        self._handle_result('menu_list', result)
        
    
    def get_stations_by_country(self, data):
        country = data['slug']
        count, offset = self._get_count(data)
        api_result = self.radio.get_stations_by_country(country, count, offset)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_country', slug=country)
        self._handle_result('stations_list', result, 'add_station')
    
    
    def get_cities(self, data):
        api_result = self.radio.get_cities(self.min_cnt)
        result = self._unify_menu(api_result, 'get_stations_by_city')
        self._handle_result('menu_list', result)
        
    
    def get_stations_by_city(self, data):
        city = data['slug']
        count, offset = self._get_count(data)
        api_result = self.radio.get_stations_by_city(city, count, offset)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_city', slug=city)
        self._handle_result('stations_list', result, 'add_station')
        
    
    def get_regions(self, data):
        api_result = self.radio.get_regions(self.min_cnt)
        result = self._unify_menu(api_result, 'get_stations_by_region')
        self._handle_result('menu_list', result)
        
    
    def get_stations_by_region(self, data):
        region = data['slug']
        count, offset = self._get_count(data)
        api_result = self.radio.get_stations_by_region(region, count, offset)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_region', slug=region)
        self._handle_result('stations_list', result, 'add_station')
    
    
    def get_languages(self, data):
        api_result = self.radio.get_languages(self.min_cnt)
        result = self._unify_menu(api_result, 'get_stations_by_language')
        self._handle_result('menu_list', result)
        
    
    def get_stations_by_language(self, data):
        language = data['slug']
        count, offset = self._get_count(data)
        api_result = self.radio.get_stations_by_language(language, count, offset)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_city', slug=language)
        self._handle_result('stations_list', result, 'add_station')
    

    def play_stream(self, data):
        station = self.radio.get_station_details(data["id"])
        name = data["name"]
        icon = data["icon_url"]
        stream_url = 'invalid'
        url_resolved = None
        
        if station['hasValidStreams']:
            stream_url = station["streams"][0]['url']
            url_resolved = self.radio.resolve_url(stream_url)
        
        if( None == url_resolved ):
            xbmc.log(f'[{self.log_name}] play error {name}, url: {stream_url}, url_resolved: {url_resolved}', xbmc.LOGERROR)
            heading = name
            message = "Cannot play stream"
            xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING)
        else:
            xbmc.log(f'[{self.log_name}] play stream {name}, url: {url_resolved}', xbmc.LOGINFO)
            self._add_to_recently(data)
            li = xbmcgui.ListItem(path=url_resolved)
            li.setInfo('music', {'title': name})
            li.setArt({'thumb': icon, 'icon': icon, 'fanart': self.fanart})
            xbmcplugin.setResolvedUrl(self.addon_handle, True, listitem=li)
    

    def play_stream_tmp(self, data):
        station = self.radio.get_station_details(data["id"])
        name = data["name"]
        icon = data["icon_url"]
        stream_url = 'invalid'
        url_resolved = None
        
        if station['hasValidStreams']:
            stream_url = station["streams"][0]['url']
            url_resolved = self.radio.resolve_url(stream_url)
        
        if( None == url_resolved ):
            xbmc.log(f'[{self.log_name}] play error {name}, url: {stream_url}, url_resolved: {url_resolved}', xbmc.LOGERROR)
            heading = name
            message = "Cannot play stream"
            xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING)
        else:
            xbmc.log(f'[{self.log_name}] play stream {name}, url: {url_resolved}', xbmc.LOGINFO)
            self._add_to_recently(data)
            li = xbmcgui.ListItem()

            li.setInfo('music', {'title': name})
            li.setArt({'thumb': icon, 'icon': icon, 'fanart': self.fanart})
            
            fullscreen = False
            if fullscreen:
                player = xbmc.Player()
                player.stop()
                player.play(url_resolved, li)
            else:
                playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
                playlist.clear()
                playlist.add(url=url_resolved, listitem=li)
    
                player = xbmc.Player()
                player.play()
    
    
    
    def get_my_stations(self, data):
        result = self.dh.load_list(self.my_stations_list)
        result = sorted(result, key=lambda k: k['data']['name'].lower())
        self._handle_result('stations_list', result, 'remove_station')
    
    
    def add_to_stations(self, data):
        name = data["name"]
        result = self.dh.load_list(self.my_stations_list)
        
        if( [] != result ):
            for item in result:
                if( item['data']["id"] == data["id"] ):
                    heading = name
                    message = "Already added to list"
                    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING)
                    return
                
        record = {}
        record['data'] = data
        record['mode'] = 'play_stream'
        result.insert(0, record)
        
        self.dh.save_list(self.my_stations_list, result)
        heading = name
        message = "Added to my stations"
        xbmcgui.Dialog().notification(heading, message, self.icon)
    
    
    def remove_from_stations(self, data):
        result = self.dh.load_list(self.my_stations_list)
        
        for item in result:
            if( item['data']["name"] == data["name"] ):
                result.remove(item)
                self.dh.save_list(self.my_stations_list, result)
                xbmc.executebuiltin( "Container.Refresh" )
                break

    
    def add_to_iptv(self, data):
        retry = 2
        
        while retry:
            retry -= 1
            
            m3u_file = self.addon.getSetting('m3u_file')
            m3u_bak = m3u_file + 'bak'
            
            if not xbmcvfs.exists(m3u_file):
                if retry:
                    dialog = xbmcgui.Dialog()
                    dialog.ok("Radio.de", "Please choose a valid m3u file")
                    self.addon.openSettings()
                else:
                    dialog = xbmcgui.Dialog()
                    dialog.ok("Radio.de", "No valid m3u file list specified")
                    return
            else:
                break
            
        tvg_name = data['name']
        group_title = 'Radio-DE'
        tvg_logo = data['icon_url']
        stream_url = self.radio.resolve_url(data['stream_url'])
        
        if None == stream_url:
            heading = tvg_name
            message = "No valid stream found"
            xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING)
            return
        
        fh = xbmcvfs.File(m3u_file, 'r')
        m3u_dat = fh.read()
        fh.close()
        
        if tvg_name in m3u_dat:
            heading = tvg_name
            message = "Already added to IPTV Simple"
            xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING)
            return
        
        if not m3u_dat.startswith('#EXTM3U'):
            m3u_tmp = m3u_dat
            m3u_dat = '#EXTM3U\n'
            m3u_dat = m3u_dat + m3u_tmp
        
        fh = xbmcvfs.File(m3u_bak, 'w')
        fh.write(m3u_dat)
        fh.close() 

        new_line = f'#EXTINF:-1 tvg-name="{tvg_name}" group-title="{group_title}" radio="true" tvg-logo="{tvg_logo}",{tvg_name}\n'
        new_stream = f'{stream_url}\n'
        m3u_dat = m3u_dat + new_line + new_stream
            
        fh = xbmcvfs.File(m3u_file, 'w')
        fh.write(m3u_dat)
        fh.close()
        
        heading = tvg_name
        message = "Added to IPTV Simple"
        xbmcgui.Dialog().notification(heading, message, self.icon)
        
        
    def get_recently(self, data):
        result = self.dh.load_list(self.recent_list)
        self._handle_result('stations_list', result, 'recently_cm')
        
        
    def remove_from_recently(self, data):
        result = self.dh.load_list(self.recent_list)
        
        for item in result:
            if item['data']["id"] == data['id']:
                result.remove(item)
                self.dh.save_list(self.recent_list, result)
                xbmc.executebuiltin( "Container.Refresh" )
                break
    
    def _get_count(self, data, count=20, offset=0):
        count = data.get('count', count)
        offset = data.get('offset', offset)
        return count, offset
        
        
    def _add_to_search(self, query, max_items=50):
        result = self.dh.load_list(self.search_list)
        
        for item in result:
            if item['data']["query"] == query:
                return
        
        record = {'data': {}, 'mode': ''}
        record['mode'] = 'do_search'
        record['data']['name'] = query
        record['data']['query'] = query
        
        result.insert(0, record)
               
        if( max_items < len(result) ):
            result.pop()

        self.dh.save_list(self.search_list, result)
    
    
    def _add_to_recently(self, data, max_items=50):
        result = self.dh.load_list(self.recent_list)
        
        for item in result:
            if item['data']["id"] == data["id"]:
                result.remove(item)
                break
        
        record = {'data': {}, 'mode': ''}
        record['mode'] = 'play_stream'
        record['data']['id'] = data['id']
        record['data']['name'] = data['name']
        record['data']['icon_url'] = data['icon_url']
        record['data']['stream_url'] = data['stream_url']
        
        result.insert(0, record)
               
        if( max_items < len(result) ):
            result.pop()

        self.dh.save_list(self.recent_list, result)

        
    def _unify_stations(self, data):
        result = []
        
        if data:
            stations = data.get('playables', [])
            for item in stations:
                record = {'data': {}, 'mode': ''}
                record['mode'] = 'play_stream'
                record['data']['id'] = item['id']
                record['data']['name'] = item['name']
                record['data']['icon_url'] = item['logo300x300']
                record['data']['stream_url'] = item['streams'][0]['url']
                result.append(record)

        return result
    
    
    def _unify_menu(self, data, mode):
        result = []

        if data:
            for item in data:
                record = {'data': {}, 'mode': ''}
                record['data']['count'] = 20
                record['data']['offset'] = 0
                record['data']['name'] = item['name']
                record['data']['slug'] = item['slug']
                record['mode'] = mode
                result.append(record)
            
        return result
    

    def _add_next(self, data, result, count, offset, mode, **kwargs):
        if data:
            total = data.get('totalCount', 0)
            
            if  (count + offset) < total:
                record = {'data': {}, 'mode': ''}
                record['mode'] = mode
                record['data']['id'] = ''
                record['data']['name'] = 'Next >>'
                record['data']['icon_url'] = ''
                record['data']['stream_url'] = ''
                record["data"]['count'] = count
                record["data"]['offset'] = offset + count
                
                for key, val in kwargs.items():
                    record["data"][key] = val

                result.append(record)
            
        return result
        
        
    def _handle_result(self, mode, result, cm_menu=None):
        li = ListItem(self.addon_path, self.addon_handle)
        
        if 'menu_list' == mode:
            for item in result:
                context_menu = cm_menu
                if 'cm' in item['data']:
                    context_menu = item['data']['cm']
                
                if context_menu:
                    for cm in CM_MAP[context_menu]:
                        li.add_context_menu_item(cm['name'], cm['mode'], item['data'], cm['action'])
                
                li.add_item(item['data']["name"], item["mode"], item["data"], self.icon, self.fanart)
                
        elif 'stations_list' == mode:
            for item in result:
                context_menu = cm_menu
                # if 'cm' in item['data']:
                #     context_menu = item['data']['cm']

                if context_menu:
                    for cm in CM_MAP[context_menu]:
                        li.add_context_menu_item(cm['name'], cm['mode'], item['data'], cm['action'])

                if '' == item['data']["icon_url"]:
                    item["data"]['icon_url'] = self.icon
                
                if 'play_stream' == item["mode"]:
                    li.add_music_item(item['data']["name"], item["mode"], item["data"], item['data']["icon_url"], self.fanart)
                else:
                    li.add_item(item['data']["name"], item["mode"], item["data"], item['data']["icon_url"], self.fanart)
                
        elif 'stations_list_tmp' == mode:
            for item in result:
                context_menu = cm_menu
                # if 'cm' in item['data']:
                #     context_menu = item['data']['cm']

                if context_menu:
                    for cm in CM_MAP[context_menu]:
                        li.add_context_menu_item(cm['name'], cm['mode'], item['data'], cm['action'])

                if '' == item['data']["icon_url"]:
                    item["data"]['icon_url'] = self.icon

                li.add_item(item['data']["name"], item["mode"], item["data"], item['data']["icon_url"], self.fanart)

        li.end_of_directory()





    
    # =====================================================================
    # test section
    #======================================================================
    def _test_search(self, data):
        query = 'rock antenn'
        count = 20
        offset = 0
        api_result = self.radio.search(query, count, offset)
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        result = self._unify_stations(api_result)
        self._handle_result('stations_list', result)
    
    
    def _test_get_similar(self, data):
        station = 'swr3'
        count = 20
        offset = 0
        api_result = self.radio.get_similar(station, count)
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        result = self._unify_stations(api_result)
        self._handle_result('stations_list', result)
    
    
    def _test_get_family(self, data):
        station = 'swr3'
        count = 20
        offset = 0
        api_result = self.radio.get_family(station, count)
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        result = self._unify_stations(api_result)
        self._handle_result('stations_list', result)
    
    
    def _test_get_local_stations(self, data):
        count = 20
        offset = 0
        api_result = self.radio.get_local_stations(count, offset)
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        result = self._unify_stations(api_result)
        self._handle_result('stations_list', result)
    
    
    def _test_get_genres(self, data):
        api_result = self.radio.get_shortlist_genres()
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        result = self._unify_menu(api_result, 'get_stations_by_genre')
        self._handle_result('menu_list', result)
        
    
    def _test_get_stations_by_genre(self, data):
        genre = 'rock'
        count = 20
        offset = 0
        api_result = self.radio.get_stations_by_genre(genre, count, offset)
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        result = self._unify_stations(api_result)
        self._handle_result('stations_list', result)
    
    
    def _test_get_cities(self, data):
        api_result = self.radio.get_shortlist_cities()
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        result = self._unify_menu(api_result, 'get_stations_by_cities')
        self._handle_result('menu_list', result)
        
    
    def _test_get_stations_by_city(self, data):
        # returns only station names, ids and frequencies
        city = 'berlin'
        count = 20
        offset = 0
        api_result = self.radio.get_stations_by_city(city, count, offset)
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
                
        result = []
        for item in api_result:
            record = {'data': {}, 'mode': ''}
            record['mode'] = 'play_stream'
            record['data']['id'] = item['stationId']
            record['data']['name'] = item['stationName']
            record['data']['icon_url'] = ''
            record['data']['stream_url'] = ''
            result.append(record)

        self._handle_result('stations_list', result)
    
    
    def _test_get_countries(self, data):
        api_result = self.radio.get_shortlist_countries()
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        result = self._unify_menu(api_result, 'get_stations_by_countries')
        self._handle_result('menu_list', result)
    
    
    def _test_get_stations_by_char(self, data):
        # returns only a list with stations, but no stream information available
        char = 'a'
        count = 20
        offset = 0
        api_result = self.radio.get_stations_by_char(char, count, offset)
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        result = []
        
        if data:
            stations = data.get('playables', [])
            for item in stations:
                record = {'data': {}, 'mode': ''}
                record['mode'] = 'play_stream'
                record['data']['id'] = item['id']
                record['data']['name'] = item['name']
                record['data']['icon_url'] = ''
                record['data']['stream_url'] = ''
                result.append(record)

        self._handle_result('stations_list', result)
    
    
    def _test_get_now_playing(self, data):
        station = 'swr3'
        api_result = self.radio.get_now_playing(station)
        # result: [{"title":"Cruel Summer / Taylor Swift","stationId":"swr3"}]
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
    
    
    def _test_get_songs(self, data):
        station = 'swr3'
        api_result = self.radio.get_songs(station)
        # result: [{"rawInfo":"RELAX mit Marcus Barsch"},{"rawInfo":"Stumblin' in / CYRIL"},{"rawInfo":"Cruel Summer / Taylor Swift"},{"rawInfo":"Running back to you / Martin Jensen, Alle Farben \u0026 Nico Santos"},{"rawInfo":"Ride / Twenty One Pilots"},{"rawInfo":"Use somebody / Kings Of Leon"},{"rawInfo":"Houdini / Dua Lipa"},{"rawInfo":"SWR3 Nachrichten - auch zum Nachhören in der SWR3 App"},{"rawInfo":"Looking for love / Lena"},{"rawInfo":"RELAX mit Nicola Müntefering"}]
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
    
    
    def _test_get_station_details(self, data):
        station = 'swr3'
        api_result = self.radio.get_station_details(station)
        #[{"id":"swr3","name":"SWR3","lastModified":1700138079,"logo44x44":"https://d3kle7qwymxpcy.cloudfront.net/images/broadcasts/cd/0c/2275/3/c44.png","logo100x100":"https://d3kle7qwymxpcy.cloudfront.net/images/broadcasts/cd/0c/2275/3/c100.png","logo175x175":"https://d3kle7qwymxpcy.cloudfront.net/images/broadcasts/cd/0c/2275/3/c175.png","logo300x300":"https://d3kle7qwymxpcy.cloudfront.net/images/broadcasts/cd/0c/2275/3/c300.png","logo630x630":"","logo1200x1200":"","hasValidStreams":true,"streams":[{"url":"https://liveradio.swr.de/rddez3a/swr3/","contentFormat":"audio/aac","status":"VALID"},{"url":"https://d131.rndfnk.com/ard/swr/swr3/live/mp3/128/stream.mp3","contentFormat":"audio/mpeg","status":"VALID"}],"city":"Baden-Baden","country":"Germany","genres":["Top 40 \u0026 Charts","Pop"],"type":"STATION","description":"SWR3 plays the best pop songs, radio comics and live concerts around the clock.","homepageUrl":"https://www.swr3.de/","adParams":"advertising=true\u0026family=SWR3\u0026genres=Top 40 \u0026 Charts\u0026genres=Pop\u0026languages=German\u0026st_city=Baden-Baden\u0026st_cont=Europe\u0026st_country=Germany\u0026st_region=Baden-Wuerttemberg\u0026station=swr3\u0026type=radio_station","hideReferer":false,"continent":"Europe","languages":["German"],"families":["SWR3"],"region":"Baden-Wuerttemberg","genreTags":[{"systemName":"Top 40 \u0026 Charts","name":"Top 40 \u0026 Charts","slug":"top-40-and-charts","count":3289},{"systemName":"Pop","name":"Pop","slug":"pop","count":14085}],"cityTag":{"systemName":"Baden-Baden","name":"Baden-Baden","slug":"baden-baden","count":17},"parentTag":{"systemName":"Südwestrundfunk","name":"Südwestrundfunk","slug":"suedwestrundfunk","count":25},"familyTag":{"systemName":"SWR3","name":"SWR3","slug":"swr3","count":4},"languageTags":[{"systemName":"German","name":"German","slug":"german","count":15468}],"regionTag":{"systemName":"Baden-Wuerttemberg","name":"Baden-Wuerttemberg","slug":"baden-wuerttemberg","count":773},"countryTag":{"systemName":"Germany","name":"Germany","slug":"germany","count":14515},"frequencies":[{"area":"Haardtkopf","type":"FM","value":90},{"area":"Saarburg/Geisberg","type":"FM","value":90.6},{"area":"Koblenz/Naßheck (Waldesch)","type":"FM","value":91.6},{"area":"Alf-Bullay","type":"FM","value":92.6},{"area":"Bad Marienberg","type":"FM","value":92.8},{"area":"Kirn","type":"FM","value":93.3},{"area":"Rüdesheim","type":"FM","value":93.3},{"area":"Bad Kreuznach/Kauzenburg","type":"FM","value":93.5},{"area":"Mainz-Kastel","type":"FM","value":93.7},{"area":"Linz/Ginsterhahn","type":"FM","value":94.8},{"area":"Bornberg","type":"FM","value":97.5},{"area":"Idar-Oberstein","type":"FM","value":98.1},{"area":"Diez","type":"FM","value":98.2},{"area":"Trier/Markusberg","type":"FM","value":98.2},{"area":"Nierstein","type":"FM","value":98.4},{"area":"Scharteberg (Eifel)","type":"FM","value":98.5},{"area":"Bleialf","type":"FM","value":98.9},{"area":"Altenahr ","type":"FM","value":99.4},{"area":"Donnersberg","type":"FM","value":101.1},{"area":"Kettrichhof","type":"FM","value":107.2}],"rank":168,"shortDescription":"SWR3 plays the best pop songs, radio comics and live concerts around the clock.","enabled":true,"seoRelevantIn":["sv_SE","it_IT","pt_BR","es_CO","es_ES","en_US","fr_FR","nl_NL","da_DK","en_NZ","de_DE","de_AT","en_GB","es_MX","en_IE","en_CA","pt_PT","pl_PL"],"aliases":[],"blockingInformation":{"isBlocked":false,"isBlockedIn":[]}}]
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
    
    
    def _test_get_topics(self, data):
        api_result = self.radio.get_shortlist_topics()
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        result = self._unify_menu(api_result, 'get_stations_by_topic')
        self._handle_result('menu_list', result)
    
    
    def _test_get_stations_by_topic(self, data):
        topic = 'news'
        api_result = self.radio.get_stations_by_topic(topic, count=20, offset=0)
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        result = self._unify_stations(api_result)
        self._handle_result('stations_list', result)
    
    
    def _test_get_tags(self, data):
        api_result = self.radio.get_tags()
        xbmc.log(f'[{self.log_name}] result: {api_result}', xbmc.LOGDEBUG)
        
    
