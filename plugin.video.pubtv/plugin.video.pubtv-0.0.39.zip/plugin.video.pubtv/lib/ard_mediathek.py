# -*- coding: utf-8 -*-

import re
import time
import json
import requests
import logging

import utils
from mediathek import Mediathek

try:
    from debug import dump_to_file
except:
    from release import dump_to_file


list_az_mapping = {
    "09": "%23",
    "a": "A",
    "b": "B",
    "c": "C",
    "d": "D",
    "e": "E",
    "f": "F",
    "g": "G",
    "h": "H",
    "i": "I",
    "j": "J",
    "k": "K",
    "l": "L",
    "m": "M",
    "n": "N",
    "o": "O",
    "p": "P",
    "q": "Q",
    "r": "R",
    "s": "S",
    "t": "T",
    "u": "U",
    "v": "V",
    "w": "W",
    "x": "X",
    "y": "Y",
    "z": "Z"
}



def get_stream_record(mime_type, quality, stream_url, kind, language):
    record = {}
    record["mime_type"] = mime_type
    record["quality"] = quality
    record["stream_url"] = stream_url
    record["kind"] = kind
    record["language"] = language
    return record



class ARDMediathek(Mediathek):

    def __init__(self):
        self.img_res = "768"
        self.show_visible_title = True
        self.delta_t = 1
        self.mediathek = "ard"
        self.program = ""
        self.source_url = ""
        self.audio_description = "&withAudiodescription=false"
        #self.audio_description = ""
        self.base_url = "https://api.ardmediathek.de/public-gateway"
        self.logger = logging.getLogger('[ard_mediathek]')
        
        if( True == time.localtime().tm_isdst ):
            self.delta_t = 2

        
    def get_categories(self, program):
        self.program = program
        return self._get_content_from_default_page(program)


    def get_shows_by_date(self, program, date):
        self.program = program
        return self._get_content_from_program_page(program, date)


    def get_shows_by_char(self, program, charakter):
        self.program = program
        charakter = list_az_mapping[charakter]
        url = self._get_shows_az_url(program, charakter)
        return self.get_content(program, url)


    def search(self, program, search_str):
        self.program = program
        
        locations = [program, "ard"]
        for location in locations:
            url = self._get_search_url(location, search_str, 0)
            result = self.get_content(program, url)
            if [] != result:
                break
            
        return result
        

    def get_content(self, program, url):
        self.program = program

        result = []
        content = self._load_json_page(url)
        
        if( "" != content ):  
            if( content.get("teasers") ):
                result = self._get_content_from_teasers(content)
                
            elif ( content.get("widgets") ):
                result = self._get_content_from_widgets(content)
           
        return result
    

    def get_items_from_content(self, program, url, args):
        self.program = program
        result = []
        pagination = None
        
        if "target_url" in args:
            content = self._load_json_page(args["target_url"])
            if( "" != content ):
                result = self._get_data_from_teasers(content["teasers"])
                pagination = content

        else:
            content = self._load_json_page(url)
            if( "" != content ):
                # widget_idx = args["widget_idx"]
                # result = self._get_data_from_teasers(content["widgets"][widget_idx]["teasers"])
                for key in content["widgets"]:
                    if( args["ref"] == key["id"] ):
                        result = self._get_data_from_teasers(key["teasers"])
                        pagination = key
                        break

        if( "" != content ):
            page_number = utils.get_safe(pagination, '["pagination"]["pageNumber"]', 0)
            page_size = utils.get_safe(pagination, '["pagination"]["pageSize"]', 0)
            total = utils.get_safe(pagination, '["pagination"]["totalElements"]', 0)
            
            #if( (total > ((page_number + 1) * page_size)) and (1 <= len(result)) ):
            if( total > ((page_number + 1) * page_size) ):
                current_number = "pageNumber=" + str(page_number)
                next_number = "pageNumber=" + str(page_number + 1)
                url = pagination["links"]["self"]["href"].replace(current_number, next_number)
                
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = "Next page >>"
                record["data"]["target_url"] = url
                
                result.append(record)
        
        return result


    def get_stream_data(self, program, url, quality="high"):
        self.program = program
        result = []
        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
        
        content = self._load_json_page(url)
        
        if '' != content:            
            show = utils.get_safe(content, '["widgets"][0]["show"]["title"]').replace("\n", " ")
            name = utils.get_safe(content, '["widgets"][0]["title"]').replace("\n", " ")
            name = u'{} - {}'.format(show, name)
            
            record["type"] = "play_stream"
            record["mode"] = "end"
            record["name"] = name
            record["subtitle_url"] = ""
            record["plot"] = utils.get_safe(content, '["widgets"][0]["synopsis"]')
            record["availability"] = self._encode_avail(utils.get_safe(content, '["widgets"][0]["availableTo"]'))
            record["aired"] = self._get_aired(utils.get_safe(content, '["widgets"][0]["broadcastedOn"]'))
    
            record["data"]["duration"] = utils.get_safe(content, '["widgets"][0]["mediaCollection"]["embedded"]["meta"]["durationSeconds"]', 0)
            record["data"]["image_url"] = utils.get_safe(content, '["widgets"][0]["image"]["src"]').replace("{width}", self.img_res)
            
            stream_urls = utils.get_safe(content, '["widgets"][0]["mediaCollection"]["embedded"]["streams"][0]["media"]', [])
            record["data"]["target_url"] = self._get_stream_url(stream_urls, quality=quality)
            
            if( record["data"]["target_url"].startswith("//") ):
                record["data"]["target_url"] = "https:" + record["data"]["target_url"]
                
        result.append(record)
        return result
    
    
    def _get_stream_url(self, data, quality='high', audio_track='german'):
        # filter streams
        audio_map = {
            'german': {'kind': 'standard', 'language': 'deu'},              # german without audio description
            'german_ad': {'kind': 'audio-description', 'language': 'deu'},  # german with audio description
            'ot': {'kind': 'TBD', 'language': 'any'}                        # original audio version
        }
        
        #mime_types = ['application/vnd.apple.mpegurl', 'video/mp4']
        mime_types = ['video/mp4']
        streams_filtered = []
        audio = audio_map[audio_track]

        for stream in data:
            for mime_type in mime_types:
                mime_type_stream = stream["mimeType"]
                
                if mime_type == mime_type_stream:
                    for track in stream["audios"]:
                        kind = track.get("kind", audio["kind"])
                        language = track.get("languageCode", audio["language"])
                        
                        if 'any' == audio["language"]:
                            language = 'any'

                        if (audio["kind"] == kind) and (audio["language"] == language):
                            record = get_stream_record(mime_type, stream["maxVResolutionPx"], stream["url"], kind, language)
                            streams_filtered.append(record)
    
        # get stream according to quality request
        qlist_high = [1080, 720, 540, 360]
        qlist_medium = [540, 360]
        qlist_low = [360]
        
        quality_map = {'high': qlist_high, 'medium': qlist_medium, 'low': qlist_low}
        target_quality_list = quality_map[quality]
        
        for quality in target_quality_list:
            for stream in streams_filtered:
                if stream["quality"] == quality:
                    return stream["stream_url"]
                
        return ''

    
    def _get_content_from_teasers(self, content):
        teasers = content["teasers"]
        result = self._get_data_from_teasers(teasers)
        
        page_number = content["pagination"]["pageNumber"]
        page_size = content["pagination"]["pageSize"]
        total = content["pagination"]["totalElements"]
        
        #if( (total > ((page_number + 1) * page_size)) and (1 <= len(result)) ):
        if( total > ((page_number + 1) * page_size) ):
            current_number = "pageNumber=" + str(page_number)
            next_number = "pageNumber=" + str(page_number + 1)
            url = content["links"]["self"]["href"].replace(current_number, next_number)
            
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = "Next page >>"
            record["data"]["target_url"] = url
            
            result.append(record)
            
        return result

    
    def _get_data_from_teasers(self, teasers):
        result = []
        season = False
        
        for teaser in teasers:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                    
            if( teaser.get("type") ):
                name = teaser["mediumTitle"]
                name = name.replace("\n", " ")
                name = name.replace("|", " - ")
                
                if( ("compilation" == teaser["type"]) or
                    ("show" == teaser["type"]) ):
                    #asset_type = teaser.get("coreAssetType")
                    #if "SEASON_SERIES" == asset_type:
                        
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = name
                    record["data"]["target_url"] = teaser["links"]["target"]["href"] + "&seasoned=true" + self.audio_description
                    record["data"]["image_url"] = self._get_image_url(teaser["images"])
                    
                    result.append(record)
                
                elif( ("editorialPage" == teaser["type"]) ):
                        
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = name
                    record["data"]["target_url"] = teaser["links"]["target"]["href"] + self.audio_description
                    record["data"]["image_url"] = self._get_image_url(teaser["images"])
                    
                    result.append(record)
                    
                elif( "live" != teaser["type"] ):
                    number_of_clips = utils.get_safe(teaser, '["numberOfClips"]', 1)
                    
                    if( 0 < number_of_clips):
                        record["type"] = "stream_meta_data"
                        record["mode"] = "play_stream"
                        record["name"] = name
                        record["plot"] = utils.get_safe(teaser, '["show"]["longSynopsis"]')
                        record["subtitle_url"] = ""
                        record["aired"] = self._get_aired(utils.get_safe(teaser, '["broadcastedOn"]'))
                        
                        record["data"]["target_url"] = teaser["links"]["target"]["href"] + self.audio_description + '&mcV6=true'
                        record["data"]["duration"] = utils.get_safe(teaser, '["duration"]')
                        record["data"]["image_url"] = self._get_image_url(teaser["images"])
    
                        if not "AD" in utils.get_safe(teaser, '["binaryFeatures"]', []):
                            '''
                            # possible sort algorithm for seasons/episodes. not needed currently
                            res = re.search("(\(S\d\d.*?E\d\d\))", record['name'])
                            if None != res:
                                record['data']['args']['season'] = res.group()
                            else:
                                record['data']['args']['season'] = '(S99/E99)'
                            season = True
                            '''
                            result.append(record)
                        else:
                            # add anyway...?
                            result.append(record)
                            pass
        
        if season:
            result = sorted(result, key=lambda k: k['data']['args']['season'])
        
        return result

    
    def _get_content_from_widgets(self, content):
        result = []
        
        if( len(content["widgets"]) <= 1 ):
            widgets = content["widgets"][0]
            
            result = self._get_data_from_teasers(widgets["teasers"])
            
            page_number = widgets["pagination"]["pageNumber"]
            page_size = widgets["pagination"]["pageSize"]
            total = widgets["pagination"]["totalElements"]
            
            #if( (total > ((page_number + 1) * page_size)) and (1 <= len(result)) ):
            if( total > ((page_number + 1) * page_size) ):
                current_number = "pageNumber=" + str(page_number)
                next_number = "pageNumber=" + str(page_number + 1)
                url = widgets["links"]["self"]["href"].replace(current_number, next_number)
                
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = "Next page >>"
                record["data"]["target_url"] = url
                
                result.append(record)
        else:
            for idx, key in enumerate(content["widgets"]):
                if not "AD" in key.get("binaryFeatures", []):
                    # don't list audio description
                    record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                    record["type"] = "category"
                    record["mode"] = "get_content_from_categoy"
                    record["name"] = key["title"]
                    record["data"]["target_url"] = self.source_url
                    # legacy approach (widget_idx nad ref). keep for legacy reason.
                    record["data"]["args"]["widget_idx"] = idx
                    record["data"]["args"]["ref"] = key["id"]
                    # new approach. if legacy is not needed any longer, this should become the real target url.
                    record["data"]["args"]["target_url"] = key["links"]["self"]["href"]
                                        
                    result.append(record)
        
        return result


    def _get_content_from_default_page(self, program):
        url = self._get_default_url(program)
        content = self._load_json_page(url)
        result = self._get_content_from_widgets(content)
            
        return result


    def _get_content_from_program_page(self, program, date):
        result = []
        
        url = self._get_program_url(program, date)
        content = self._load_json_page(url)
        
        if( "" != content ):
            result = self._get_content_from_teasers(content[0])
        
        return result


    def _get_default_url(self, program):
        url_base = "https://api.ardmediathek.de/page-gateway/pages/%s/home" %(program)
        return url_base
    
    
    def _get_program_url(self, program, date):
        page_number = 0
        page_size = 200
        url_base = "https://api.ardmediathek.de/page-gateway/compilations/%s/pastbroadcasts" %(program)
        url = "?startDateTime=%sT00:00:00.000Z&endDateTime=%sT23:59:59.000Z&pageNumber=%d&pageSize=%d" %(date, date, page_number, page_size)
        return url_base + url
    
    
    def _get_shows_az_url(self, program, charakter):
        page_number = 0
        page_size = 20
        url_base = "https://api.ardmediathek.de/page-gateway/compilations/%s/shows/" %(program)
        url = "%s?pageNumber=%d&pageSize=%d&embedded=true" %(charakter, page_number, page_size)
        return url_base + url
    
    
    def _get_search_url(self, program, search_str, page_number):
        page_size = 20
        url_base = "https://api.ardmediathek.de/page-gateway/widgets/%s/search/vod" %(program)
        url = "?searchString=%s&pageNumber=%d&pageSize=%d" %(search_str, page_number, page_size)
        return url_base + url
    
    
    def _encode_avail(self, avail):
        availability = "Keine Information"
        
        try:
            if( 10 < len(avail) ):
                # 2021-10-12T21:59:00Z
                #avail = time.strptime(avail,"%Y-%m-%dT%H:%M:%SZ")
                #availability = "Video verfügbar bis "
                #availability = availability + str(avail.tm_mday).zfill(2) + "."
                #availability = availability + str(avail.tm_mon).zfill(2) + "."
                #availability = availability + str(avail.tm_year)
                
                availability = "Video verfügbar bis "
                availability = availability + str(avail[8:10]) + "."
                availability = availability + str(avail[5:7]) + "."
                availability = availability + str(avail[0:4])
        except:
            pass
        
        return availability
    
    
    def _get_image_url(self, images):
        image_url = ""
        
        for key in images:
            if( key.startswith("aspect") ):
                image_url = images[key]["src"].replace("{width}", self.img_res)
                break
            
        return image_url


    def _get_aired(self, broadcasted):
        aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
        
        if(("" != broadcasted) and (None != broadcasted)):
            aired_format = ["%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S.%fZ"]
            
            for item in aired_format:
                try:
                    bcstd = time.strptime(broadcasted,item)
                
                    tm_hour = bcstd.tm_hour + self.delta_t
                    if( 24 <= tm_hour ):
                        tm_hour = tm_hour - 24
                    
                    aired["year"] = str(bcstd.tm_year)
                    aired["mon"] = str(bcstd.tm_mon).zfill(2)
                    aired["day"] = str(bcstd.tm_mday).zfill(2)
                    aired["hour"] = str(tm_hour).zfill(2)
                    aired["min"] = str(bcstd.tm_min).zfill(2)
                    
                    break                
                except:
                    # maybe alternative time format: bcstd = time.strptime(broadcasted,"%Y-%m-%dT%H:%M:%S.%fZ")
                    pass
            
        return aired
    
    
    def _load_json_page(self, url):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")
        self.logger.debug("loading page {}".format(self.source_url))
        content = requests.get(self.source_url, allow_redirects=True)
        if(content.encoding is not None):
            result = content.text.encode(content.encoding)
        else:
            result = content.text
        
        result = result.decode("utf-8")
        if( "<!DOCTYPE html>" in result[:40] ):
            jresult = self._extract_json(result)
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""
        
        dump_to_file(jresult)
        return jresult


    def _extract_json(self, html):
        try:
            content = re.compile("__APOLLO_STATE__ = ({.*});").search(html).group(1)
            content = json.loads(content)
        except:
            content = ""
        return content


'''
Already seen URL arguments:
---------------------------
&pageNumber=0
&pageSize=48
&embedded=true
&seasoned=true
&seasonNumber=1
&withAudiodescription=false
&withOriginalWithSubtitle=false
&withOriginalversion=false
&single=false


sttream data:
https://api.ardmediathek.de/page-gateway/pages/ard/item/Y3JpZDovL25kci5kZS9wcm9wbGFuXzE5NjE5NDY1NV9nYW56ZVNlbmR1bmc?devicetype=pc&embedded=true&&mcV6=true
'''

