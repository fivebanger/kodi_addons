# -*- coding: utf-8 -*-

import time
import json
import requests
import logging

import utils
from mediathek import Mediathek


api_token = "5d60797c60d131389d7d216941705bd790002bb5 reraeB"
user_agent = "Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0"
header = {'Api-Auth': api_token[::-1], 'Accept-Encoding': 'gzip, deflate', 'User-Agent': user_agent}

base_url = 'https://api.zdf.de'
player_id = 'ngplayer_2_4'


categories = [
    {"name": "Startseite", "url": "https://api.zdf.de/content/documents/zdf?profile=cellular-5"},
    {"name": "Filme", "url": "https://api.zdf.de/content/documents/filme-104.json?profile=cellular-5"},
    {"name": "Serien", "url": "https://api.zdf.de/content/documents/serien-100.json?profile=cellular-5"},
    {"name": "Dokus & Reportagen", "url": "https://api.zdf.de/content/documents/doku-wissen-104.json?profile=cellular-5"},
    {"name": "Nachrichten", "url": "https://api.zdf.de/content/documents/nachrichten-sendungen-100.json?profile=cellular-5"},
    {"name": "Comedy & Satire", "url": "https://api.zdf.de/content/documents/comedy-102.json?profile=cellular-5"},
    {"name": "Kinder/ZDFtivi", "url": "https://api.zdf.de/content/documents/zdftivi-fuer-kinder-100.json?profile=cellular-5"},
    {"name": "Politik & Gesellschaft", "url": "https://api.zdf.de/content/documents/politik-gesellschaft-102.json?profile=cellular-5"},
    {"name": "ZDFkultur", "url": "https://api.zdf.de/content/documents/kultur-110.json?profile=cellular-5"},
    {"name": "sportstudio", "url": "https://api.zdf.de/content/documents/sport-106.json?profile=cellular-5"},
    {"name": "Krimi", "url": "https://api.zdf.de/content/documents/krimi-102.json?profile=cellular-5"},
    {"name": "Verbraucher", "url": "https://api.zdf.de/content/documents/verbraucher-102.json?profile=cellular-5"},
]



list_az_mapping = {
                    "09": "0 - 9",
                    "a": "A",
                    "b": "B",
                    "c": "C",
                    "d": "D",
                    "e": "E",
                    "f": "F",
                    "g": "G",
                    "h": "H",
                    "i": "I",
                    "j": "J",
                    "k": "K",
                    "l": "L",
                    "m": "M",
                    "n": "N",
                    "o": "O",
                    "p": "P",
                    "q": "Q",
                    "r": "R",
                    "s": "S",
                    "t": "T",
                    "u": "U",
                    "v": "V",
                    "w": "W",
                    "x": "X",
                    "y": "Y",
                    "z": "Z"
                 }



class ZDFMediathek(Mediathek):

    def __init__(self):
        self.img_res = "1080"
        self.delta_t = 0
        self.strm_quality = "high"
        self.mediathek = "zdf"
        self.program = ""
        self.source_url = ""
        self.curr_char = ""
        self.dump_to_file = True
        self.logger = logging.getLogger('[zdf_mediathek]')


    def get_categories(self, program):
        self.program = program
        return self._get_categories_static()
        #return self._get_categories_api()
    

    def get_shows_by_date(self, program, date):
        self.program = program
        url = f"https://api.zdf.de/content/documents/zdf/sendung-verpasst?profile=cellular-5&airtimeDate={date}T05:30:00Z"
        content = self._load_json_page(url)
        teaser = utils.get_safe(content, "['http://zdf.de/rels/broadcasts-page']['teaser']", [])
        return self._get_content_from_teaser(teaser)
        

    def get_shows_by_char(self, program, charakter):
        self.program = program
        self.curr_char = list_az_mapping[charakter]
        result = []
        
        url = "https://api.zdf.de/content/documents/zdf/sendungen-a-z?profile=cellular-5"
        content = self._load_json_page(url)
        
        brand = utils.get_safe(content, "['brand']", [])
        for key in brand:
            if( self.curr_char == key["title"]):
                result = self._get_content_from_teaser(key["teaser"])
                break
                
        return result


    def search(self, program, search_str):
        self.curr_prog = program
        search_str = search_str.replace(" ", "+")
        #url = "https://api.zdf.de/search/documents?profile=cellular-5&q=" + search_str
        url = "https://api.zdf.de/content/documents/zdf/suche?profile=cellular-5&q=" + search_str
        content = self._load_json_page(url)
        teaser = utils.get_safe(content, "['http://zdf.de/rels/search/result-page']['teaser']", [])
        return self._get_content_from_teaser(teaser)


    def get_content(self, program, url):
        self.program = program
        
        result = []
        content = self._load_json_page(url)
        
        if( "" != content ):
            if content.get("module"):
                result = self._get_content_from_module(content)
        
        return result
    

    def get_items_from_content(self, program, url, args):
        self.program = program
        
        result = []
        content = self._load_json_page(url)
        
        if( "" != content ):
            for key in content["module"]:
                tracking_title = key.get("trackingTitle")
                if( args["ref"] == tracking_title ):
                    result = self._get_content_from_teaser(key["teaser"])
                    break
        
        return result


    def get_stream_data(self, program, url, quality="high"):
        self.program = program
        result = []
        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
        
        record["type"] = "play_stream"
        record["mode"] = "end"

        # load info page
        data = self._load_json_page(url)
        if( "" != data ):
            steam_target = utils.get_safe(data, "['mainVideoContent']['http://zdf.de/rels/target']['streams']['default']['http://zdf.de/rels/streams/ptmd-template']", None)
            if steam_target:
                steam_target = 'https://api.zdf.de' + steam_target
                steam_target = steam_target.replace('{playerId}', player_id)
                
                availability = utils.get_safe(data, "['dotty']['endDate']")
                images = utils.get_safe(data, "['teaserImageRef']['layouts']", [])
            
                record["name"] = data['title']
                record["plot"] = data.get('leadParagraph', '')
                record["availability"] = self._get_availibility(availability)
                record["data"]["image_url"] = self._get_image_url(images)
                record["data"]["duration"] = data['mainVideoContent']['http://zdf.de/rels/target']['duration']
        
                # load streams
                content = self._load_json_page(steam_target)
                if( "" != content ):
                    '''
                    broadcasted = utils.get_safe(content, '["document"]["airtime"]')
                    record["aired"] = self._get_aired(broadcasted)
                    
                    headline = ['', '']
                    headline[1] = utils.get_safe(content, '["document"]["headline"]')
                    headline = headline[1].split(' | ', 1) if ' | ' in headline[1] else headline
                    name = utils.get_safe(content, '["document"]["titel"]')
                    name = u'{} - {}'.format(headline[1], name)
                    
                    record["type"] = "play_stream"
                    record["mode"] = "end"
                    record["name"] = name
                    record["subtitle_url"] = ""
                    record["plot"] = utils.get_safe(content, '["document"]["beschreibung"]')
                    record["availability"] = utils.get_safe(content, '["document"]["availabilityInfo"]', "Keine Information")
            
                    record["data"]["duration"] = utils.get_safe(content, '["document"]["length"]')
                    record["data"]["image_url"] = self._get_image_url(utils.get_safe(content, '["document"]'))
            
                    stream_urls = utils.get_safe(content, '["document"]["formitaeten"]', [])
                    
                    quality_idx = {"low": 1, "medium": 2, "high": 4}
                    quality_mapping = ["void", "low", "med", "high", "veryhigh"]
                    q = quality_idx[quality]
                        
                    while(q):
                        for key in stream_urls:
                            
                            key_mime_type = utils.get_safe(key, '["mimeType"]', "")
                            key_quality = utils.get_safe(key, '["quality"]', "")
                            key_url = utils.get_safe(key, '["url"]', "")
                            
                            if( ("video/mp4" == key_mime_type) or
                                ("application/x-mpegURL" == key_mime_type) ):
                                if( quality_mapping[q] == key_quality ):
                                    record["data"]["target_url"] = key_url
                                    q = 0
                                    break
                                
                        if( 0 < q ):
                            q = q - 1
                    '''
                    
                    #mime_types = ['video/mp4', 'application/x-mpegURL', 'video/webm']
                    mime_types = ['application/x-mpegURL', 'video/webm', 'video/mp4']
                    
                    stream_list = []
                    
                    for mime_type in mime_types:
                        for stream in content['priorityList']:
                            if mime_type == stream['formitaeten'][0]['mimeType']:
                                stream_list = stream['formitaeten'][0]['qualities']
                                break
                            
                        if [] != stream_list:
                            #print(stream_list)
                            break
                    
                    # TODO: check quality and language
                    stream_url = stream_list[0]['audio']['tracks'][0]['uri']
                    record["data"]["target_url"] = stream_url

        result.append(record)
        return result
    
    
    def _get_content_from_teaser(self, teaser):
        result = []
        
        for key in teaser:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)

            video_content = utils.get_safe(key, "['target']['mainVideoContent']", None)
            video_type = utils.get_safe(key, "['target']['videoType']", 'live')
            has_video = utils.get_safe(key, "['target']['hasVideo']", False)
            
            if (('live' != video_type) and video_content):
                program = utils.get_safe(key, "['broadcastInformation']['station']", self.program)
                if self.program == program:
                    # filter "missed" result by current program
                    title = key.get("overline")
                    name = key["title"]
                    if title and not name.startswith(title):
                            name = f'{title} - {name}'
                            
                    target = key["target"]['canonical']
                    broadcasted = utils.get_safe(key, "['broadcastInformation']['effectiveAirtimeBegin']")
                    availability = utils.get_safe(key, "['dotty']['endDate']")
                    images = utils.get_safe(key, "['image']['layouts']", [])
                    
                    record["availability"] = self._get_availibility(availability)
                    record["aired"] = self._get_aired(broadcasted)
                    record["data"]["duration"] = key['target']['mainVideoContent']['http://zdf.de/rels/target']['duration']
                    record["data"]["image_url"] = self._get_image_url(images)
                    #record["data"]["target_url"] = 'https://api.zdf.de' + target + '?profile=cellular-5'
                    record["data"]["target_url"] = 'https://api.zdf.de' + target # don't use '?profile=cellular-5', otherwise information is missing
                    record["type"] = "stream_meta_data"
                    record["mode"] = "play_stream"
                    record["name"] = name
                    record["plot"] = key.get('text', '')
                
                    result.append(record)
            
            elif has_video:
                if 'ARD' != key['category']:
                    # filter ARD content, no idea how to get items later on
                    name = key["title"]
                    target = key["target"]["canonical"]
                    
                    record["data"]["target_url"] = 'https://api.zdf.de' + target + '?profile=cellular-5'
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = name
                
                    result.append(record)
            
        return result


    def _get_categories_api(self):
        result = []
        
        url = "https://api.zdf.de/content/documents/zdf?profile=cellular-5"
        content = self._load_json_page(url)
        if( "" != content ): 
            result = self._get_content_from_module(content)
        
        return result
    

    def _get_categories_static(self):
        result = []
        self.source_url = ""

        for key in categories:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)

            record["data"]["target_url"] = key["url"]
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = key["name"]
            
            result.append(record)
            
        return result
        
        
    def _get_content_from_module(self, content):
        result = []

        for idx, key in enumerate(content["module"]):
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            tracking_title = key.get("trackingTitle")
            teaser = key.get("teaser")
            
            if( (None != tracking_title) and
                (list == type(teaser)) ):
                record["type"] = "category"
                record["mode"] = "get_content_from_categoy"
                record["name"] = key["title"]
                record["data"]["target_url"] = self.source_url
                record["data"]["args"]["module_idx"] = idx
                record["data"]["args"]["ref"] = tracking_title
                                    
                result.append(record)
            
            elif dict == type(teaser):
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = key["title"]
                record["data"]["target_url"] = 'https://api.zdf.de' + teaser['target']['canonical'] + '?profile=cellular-5'
                                    
                result.append(record)
            
            elif list == type(teaser):
                teaser_result = self._get_content_from_teaser(teaser)
                result.extend(teaser_result)
        
        return result


    def _get_image_url(self, data):
        #image_quality = ['1280x720', '768x432', '384x216']
        image_quality = ['768x432', '384x216']
        image_url = ""
        
        for resolution in image_quality:
            image_url = data.get(resolution, "")
            if "" != image_url:
                break

        return image_url
    
    
    def _get_aired(self, broadcasted):
        aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
        
        # broadcasted: 2024-07-24T05:40:00+02:00
        if( "" != broadcasted):
            bcstd = time.strptime(broadcasted,"%Y-%m-%dT%H:%M:%S%z")
            
            '''
            tm_hour = bcstd.tm_hour + self.delta_t
            if( 24 <= tm_hour ):
                tm_hour = tm_hour - 24
            '''
            tm_hour = bcstd.tm_hour
            
            aired["year"] = str(bcstd.tm_year)
            aired["mon"] = str(bcstd.tm_mon).zfill(2)
            aired["day"] = str(bcstd.tm_mday).zfill(2)
            aired["hour"] = str(tm_hour).zfill(2)
            aired["min"] = str(bcstd.tm_min).zfill(2)
            
        return aired
    
    
    def _get_availibility(self, end_date):        
        try:
            date = self._get_aired(end_date)
            date_str = f'Video verfügbar bis {date["day"]}.{date["mon"]}.{date["year"]}'
        except:
            date_str = 'Keine Information'

        return date_str


    def _load_json_page(self, url):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")
        self.logger.debug("loading page {}".format(self.source_url))

        content = requests.get(self.source_url, allow_redirects=True, headers=header)
        '''
        if(content.encoding is not None):
            result = content.text.encode(content.encoding)
        else:
            result = content.text.encode("utf-8")

        result = result.decode("utf-8")
        '''
        result = content.text
        if( "<!DOCTYPE html>" in result[:40] ):
            jresult = ""
        else:
            try:
                jresult = json.loads(result)
                if self.dump_to_file:
                    self._dump_result(result)
            except:
                jresult = ""

        #self.logger.debug(jresult)
        return jresult
    
    def _dump_result(self, result):
        fh = open('dump.json', 'w')
        fh.write(result)
        fh.close()

    
    
    
