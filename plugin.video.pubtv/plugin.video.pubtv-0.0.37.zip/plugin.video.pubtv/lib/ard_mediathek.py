# -*- coding: utf-8 -*-

import re
import time
import json
import requests
import datetime

from mediathek import Mediathek


list_az_mapping = {
                    "09": "shows09",
                    "a": "showsA",
                    "b": "showsB",
                    "c": "showsC",
                    "d": "showsD",
                    "e": "showsE",
                    "f": "showsF",
                    "g": "showsG",
                    "h": "showsH",
                    "i": "showsI",
                    "j": "showsJ",
                    "k": "showsK",
                    "l": "showsL",
                    "m": "showsM",
                    "n": "showsN",
                    "o": "showsO",
                    "p": "showsP",
                    "q": "showsQ",
                    "r": "showsR",
                    "s": "showsS",
                    "t": "showsT",
                    "u": "showsU",
                    "v": "showsV",
                    "w": "showsW",
                    "x": "showsX",
                    "y": "showsY",
                    "z": "showsZ"
                 }


class ARDMediathek(Mediathek):

    def __init__(self):
        self.img_res = "768"
        self.show_visible_title = True
        self.delta_t = 1
        self.mediathek = "ard"
        self.program = ""
        self.source_url = ""
        self.curr_char = ""
        
        if( True == time.localtime().tm_isdst ):
            self.delta_t = 2
        
        
    def get_categories(self, program):
        self.program = program
        url = "https://www.ardmediathek.de/" + program +"/"
        return self.get_content(program, url)


    def get_shows_by_date(self, program, date):
        self.program = program
        date = self._get_date(date)
        url = "https://www.ardmediathek.de/" + program + "/program/" + date + "#night-" + program
        return self.get_content(program, url)


    def get_shows_by_char(self, program, charakter):
        self.program = program
        self.curr_char = charakter
        url = "https://www.ardmediathek.de/" + program + "/shows"
        result = self.get_content(program, url)
        if( [] == result ):
            # depending on "program", a backslash is needed at the end
            url = "https://www.ardmediathek.de/" + program + "/shows/"
            result = self.get_content(program, url)
        return result


    def search(self, program, search_str):
        self.program = program
        url = "https://www.ardmediathek.de/" + self.program + "/search/" + search_str +"/"
        #hmk url = "https://www.ardmediathek.de/ard/search/" + search_str +"/"
        return self.get_content(program, url)
        

    def get_content(self, program, url):
        self.program = program

        result = []
        content = self._load_json_page(url)
        
        if( content ):  
            if( content.get("ROOT_QUERY") ):
                result = self._get_content_from_root(content)
            
            elif( content.get("teasers") ):
                teasers = content["teasers"]
                result = self._get_content_from_teasers(teasers)
                
            elif ( content.get("widgets") ):
                teasers = content["widgets"][0]["teasers"]
                result = self._get_content_from_teasers(teasers)
        
        return result


    def get_stream_data(self, program, url, quality="high"):
        self.program = program
        result = []
        
        content = self._load_json_page(url)
        record = self._get_new_record()
        
        aired = {}       
        try:
            bcstd = content["widgets"][0]["broadcastedOn"]
            bcstd = time.strptime(bcstd,"%Y-%m-%dT%H:%M:%SZ")
            
            aired["year"] = str(bcstd.tm_year)
            aired["mon"] = str(bcstd.tm_mon).zfill(2)
            aired["day"] = str(bcstd.tm_mday).zfill(2)
            aired["hour"] = str(bcstd.tm_hour + self.delta_t).zfill(2)
            aired["min"] = str(bcstd.tm_min).zfill(2)
            
            record["aired"] = aired
        except:
            pass
        
        record["type"] = "play_stream"
        record["mode"] = "end"
        record["name"] = content["widgets"][0]["title"].replace("\n", " ")
        record["subtitle_url"] = ""
        record["plot"] = content["widgets"][0]["synopsis"]
        record["availability"] = self._encode_avail(content)

        record["data"]["duration"] = content["widgets"][0]["mediaCollection"]["embedded"]["_duration"]
        record["data"]["image_url"] = content["widgets"][0]["image"]["src"].replace("{width}", self.img_res)
        
        stream_urls = self._get_safe(content, ["widgets", 0, "mediaCollection", "embedded", "_mediaArray", 0, "_mediaStreamArray"], [])

        quality_idx = {"low": 1, "medium": 2, "high": 3}
        quality_mapping = [0, 1, 2, 3]
        q = quality_idx[quality]

        while(q):
            try:
                for key in stream_urls:
                    if( quality_mapping[q] == key["_quality"] ):
                        if( isinstance(key["_stream"], list) ):
                            record["data"]["target_url"] = key["_stream"][0]
                        else:
                            record["data"]["target_url"] = key["_stream"]
                        q = 0
                        break
            except:
                pass
            
            if( 0 < q ):
                q = q - 1

        if( record["data"]["target_url"].startswith("//") ):
            record["data"]["target_url"] = "https:" + record["data"]["target_url"]
            
        result.append(record)
        return result


    def _get_content_from_root(self, content):
        result = []
        root_id = ""
        for key in content["ROOT_QUERY"]:
            if( key.startswith("defaultPage") ):
                root_id = content["ROOT_QUERY"][key]["id"]
                result = self._get_content_from_default_page(content, root_id)
                break
            elif( key.startswith("programPage") ):
                root_id = content["ROOT_QUERY"][key]["id"]
                result = self._get_content_from_program_page(content, root_id)
                break
            elif( key.startswith("showsPage") ):
                root_id = content["ROOT_QUERY"][key]["id"]
                result = self._get_content_from_shows_page(content, root_id)
                break
            elif( key.startswith("searchPage") ):
                root_id = content["ROOT_QUERY"][key]["id"]
                result = self._get_content_from_search_page(content, root_id)
                break

        return result
    
    
    def _get_content_from_default_page(self, content, root_id):
        result = []

        widgets = content[root_id]["widgets"]
        
        for key in widgets:
            widget_id = key["id"]
            link = "$" + widget_id + ".links.self"
            
            record = self._get_new_record()
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = content[widget_id]["title"].replace("\n", " ")
            record["data"]["target_url"] = content[link]["href"]
            record["data"]["image_url"] = ""
            
            result.append(record)
            
        return result
    
    
    def _get_content_from_program_page(self, content, root_id):
        result = []

        if( [] == content[root_id]["widgets"] ):
            return result
        
        widget_id = content[root_id]["widgets"][0]["id"]
        program_widget = content[widget_id]
        
        for key in program_widget["teasers"]:
            teaser_id = key["id"]
            teaser = content[teaser_id]
            
            if( 0 < teaser["numberOfClips"] ):
                record = self._get_new_record()
                aired = {}
                
                link_id = teaser["links"]["id"]
                link_target = content[link_id]["target"]["id"]
                stream_meta_url = content[link_target]["href"]
                            
                image_id = teaser["images"]["id"]
                image_aspect = content[image_id]["aspect16x9"]["id"]
                image_url = content[image_aspect]["src"].replace("{width}", self.img_res)
                
                try:
                    bcstd = teaser["broadcastedOn"]
                    bcstd = time.strptime(bcstd,"%Y-%m-%dT%H:%M:%SZ")
                    
                    aired["year"] = str(bcstd.tm_year)
                    aired["mon"] = str(bcstd.tm_mon).zfill(2)
                    aired["day"] = str(bcstd.tm_mday).zfill(2)
                    aired["hour"] = str(bcstd.tm_hour + self.delta_t).zfill(2)
                    aired["min"] = str(bcstd.tm_min).zfill(2)
                    
                    record["aired"] = aired
                except:
                    pass
                
                record["type"] = "stream_meta_data"
                record["mode"] = "play_stream"
                record["name"] = teaser["mediumTitle"].replace("\n", " ")
                record["subtitle_url"] = ""
                record["plot"] = ""
        
                record["data"]["duration"] = ""
                record["data"]["image_url"] = image_url
                record["data"]["target_url"] = stream_meta_url
                
                if( "" != record["data"]["target_url"] ):
                    result.append(record)
            
        return result
    
    
    def _get_content_from_search_page(self, content, root_id):
        result = []
        
        vod_results = content[root_id]["vodResults"]
        shows_result = content[root_id]["showResults"]

        for key in vod_results:
            try:
                teaser_id = key["id"]
                teaser_links = content[teaser_id]["links"]["id"]
                link_id = content[teaser_links]["target"]["id"]
                
                record = self._get_new_record()
                record["type"] = "stream_meta_data"
                record["mode"] = "play_stream"
                record["name"] = content[teaser_id]["mediumTitle"].replace("\n", " ")
                record["data"]["target_url"] = content[link_id]["href"]
                record["data"]["image_url"] = self._get_image_from_content(content, teaser_id)
                record["data"]["duration"] = content[teaser_id]["duration"]
                
                result.append(record)
            except:
                pass

        for key in shows_result:
            try:
                teaser_id = key["id"]
                url_id = content[teaser_id]["id"]                
                
                record = self._get_new_record()
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = content[teaser_id]["mediumTitle"].replace("\n", " ")
                record["data"]["target_url"] = "https://page.ardmediathek.de/page-gateway/pages/" + self.program + "/grouping/" + url_id
                record["data"]["image_url"] = self._get_image_from_content(content, teaser_id)
                
                result.append(record)
            except:
                pass
            
        return result
                    
                    
    def _get_content_from_shows_page(self, content, root_id):
        result = []
        shows_key = list_az_mapping[self.curr_char]
        
        shows_page_glossary_id = content[root_id]["glossary"]["id"]
        shows = content[shows_page_glossary_id]
        shows_az = shows[shows_key]

        for key in shows_az:
            
            try:
                teaser_id = key["id"]
                url_id = content[teaser_id]["id"]                
                
                record = self._get_new_record()
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = content[teaser_id]["mediumTitle"].replace("\n", " ")
                record["data"]["target_url"] = "https://page.ardmediathek.de/page-gateway/pages/" + self.program + "/grouping/" + url_id
                record["data"]["image_url"] = self._get_image_from_content(content, teaser_id)
                
                result.append(record)
            except:
                pass

        return result
                    
                    
    def _get_safe(self, dict_base, keys, default=""):
        result = default
        try:
            for key in keys:
                dict_base = dict_base[key]
            result = dict_base
        except:
            pass
        return result
    
    
    def _encode_avail(self, content):
        availability = ""
        try:
            avail = content["widgets"][0]["availableTo"]
            avail = time.strptime(avail,"%Y-%m-%dT%H:%M:%SZ")
            availability = "Video verfügbar bis "
            availability = availability + str(avail.tm_mday).zfill(2) + "."
            availability = availability + str(avail.tm_mon).zfill(2) + "."
            availability = availability + str(avail.tm_year)
        except:
            pass
        
        return availability

    
    def _get_content_from_teasers(self, teasers):
        content = []
        
        for teaser in teasers:
            data = {}
            data["type"] = "unknown"

            if( teaser.get("type") ):
                if( ("compilation" == teaser["type"]) or
                    ("show" == teaser["type"]) ):
                    data["type"] = "category"
                    data["category_url"] = teaser["links"]["target"]["href"]
                    data["name"] = teaser["mediumTitle"]
                    data["params"] = {}
                        
                    record = self._get_new_record()
                    record["data"]["target_url"] = teaser["links"]["target"]["href"]
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = teaser["mediumTitle"].replace("\n", " ")
                    
                    content.append(record)
                    
                    
                elif( "live" != teaser["type"] ):                        
                    record = self._get_new_record()
                    record["type"] = "stream_meta_data"
                    record["mode"] = "play_stream"
                    record["name"] = teaser["mediumTitle"].replace("\n", " ")
                    #record["plot"] = self._get_safe(teaser["show"]["longSynopsis"])
                    record["plot"] = self._get_safe(teaser, ["show", "longSynopsis"])
                    #record["plot"] = teaser["show"]["longSynopsis"]
                    record["subtitle_url"] = ""
                    
                    record["data"]["target_url"] = teaser["links"]["target"]["href"]
                    record["data"]["duration"] = self._get_safe(teaser, ["duration"])
                    record["data"]["image_url"] = self._get_image_url(teaser["images"])

                    content.append(record)
        
        return content


    def _get_image_from_content(self, content, teaser_id, img_format="16x9"):
        image_url = ""

        iamge_data = content[teaser_id]["images"]["id"]
        
        for key in content[iamge_data]:
            if( key.startswith("aspect"+img_format) ):
                iamge_data = content[iamge_data][key]["id"]
                image_url = content[iamge_data]["src"].replace("{width}", self.img_res)
                break
            
        return image_url
    
    
    def _get_image_url(self, images):
        image_url = ""
        
        for key in images:
            if( key.startswith("aspect") ):
                image_url = images[key]["src"].replace("{width}", self.img_res)
                break
            
        return image_url
    
    
    def _load_json_page(self, url):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")
        content = requests.get(self.source_url, allow_redirects=True)
        if(content.encoding is not None):
            result = content.text.encode(content.encoding)
        else:
            result = content.text

        if( "<!DOCTYPE html>" in result[:40] ):
            jresult = self._extract_json(result)
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""

        return jresult


    def _extract_json(self, html):
        try:
            content = re.compile("__APOLLO_STATE__ = ({.*});").search(html).group(1)
            content = json.loads(content)
        except:
            content = ""
        return content


    def _get_date(self, date):
        d = datetime
        today = d.datetime.now()
        today = today.strftime("%Y-%m-%d")
        if( today == date ):
            date = ""
        return date
    

    def _get_new_record(self):
        data = {"mediathek": self.mediathek, "program": self.program, "target_url": "", "duration": "", "image_url": "", "args":{}}
        aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
        return {"type": "unknown", "mode": "unknown", "name": "unknown", "aired": aired, "subtitle_url": "", "plot": "", "availability": "", "source_url": self.source_url, "data": data}
    
    

