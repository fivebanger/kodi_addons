# -*- coding: utf-8 -*-

import re
import time
import json
import requests
import logging
        
import utils
from mediathek import Mediathek

try:
    from debug import dump_to_file
except:
    from release import dump_to_file



opa_token = "AOwImM4EGZ2gjYjRGZzEzYxMTNxMWOjJDO4gDO3UWN3UmN5IjNzAzMlRmMwEWM2I2NhFWN1kjYkJjZ1cjY1czN reraeB"
emac_token = "wYxYGNiBjNwQjZzIjMhRDOllDMwEjM2MDN3MjY4U2M1ATYkVWOkZTM5QzM4YzN2ITM0E2MxgDO1EjN5kjZmZWM reraeB"
player_token = "QMjZTOkF2NwQDZlFTOmJDOiFGN1QGM4EjY5QWOhBzN4YzM4YGMiRTNjZjZyImMjFWZlRWZ3Q2Y1MmYyYDZyYzM reraeB"

opa_header  = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:60.0) Gecko/20100101 Firefox/60.0', 'Authorization': opa_token[::-1]}
emac_header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:60.0) Gecko/20100101 Firefox/60.0', 'Authorization': emac_token[::-1]}
player_header  = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:60.0) Gecko/20100101 Firefox/60.0", "Authorization": player_token[::-1]}



url_start = 'https://api-cdn.arte.tv/api/emac/v3/{}/web/pages/HOME/'
url_concert = 'https://api-cdn.arte.tv/api/emac/v3/{}/web/ARTE_CONCERT/'
url_music = 'https://api.arte.tv/api/opa/v3/categories?language={}&limit=50'
url_genres = 'https://api-cdn.arte.tv/api/emac/v3/{}/web/MENU/'

main_menu = [
                {'label': 'ARTE Home', 'target_url': url_start, 'type': 'general'},
                {'label': 'ARTE Concert', 'target_url': url_concert, 'type': 'general'},
                {'label': 'Music', 'target_url': url_music, 'type': 'music'},
                {'label': 'Genres', 'target_url': url_genres, 'type': 'general'}
            ]



def get_stream_record(mime_type, quality, stream_url, ad, language):
    record = {}
    record["mime_type"] = mime_type
    record["quality"] = quality
    record["stream_url"] = stream_url
    record["ad"] = ad
    record["language"] = language
    return record



class ARTEMediathek(Mediathek):

    def __init__(self):
        self.img_res = 2
        self.delta_t = 1
        self.strm_quality = "high"
        self.mediathek = "arte"
        self.program = "arte_de"
        self.source_url = ""
        self.country = "de"
        self.page_limit = 20
        self.logger = logging.getLogger('[arte_mediathek]')
        
        if( True == time.localtime().tm_isdst ):
            self.delta_t = 2


    def get_categories(self, program):
        self._select_country(program)
        
        result = []
        for key in main_menu:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            record["type"] = "category"
            record["mode"] = "get_content_from_categoy"
            record["name"] = key["label"]
            record["data"]["target_url"] = key['target_url'].format(self.country)
            record["data"]["args"]["type"] = key['type']
            
            result.append(record)

        return result
    

    def get_shows_by_date(self, program, date):
        self._select_country(program)
        url = 'https://api-cdn.arte.tv/api/emac/v3/{}/web/pages/TV_GUIDE/?day={}'.format(self.country, date)
        content = self._load_json_page(url, emac_header)
        return self._get_content_from_data(content["zones"][1])


    def search(self, program, search_str):
        self._select_country(program)
        url = "https://api-cdn.arte.tv/api/emac/v3/{}/web/data/SEARCH_LISTING/?query={}&page=1&limit={}".format(self.country, search_str, self.page_limit)
        return self.get_content(program, url)


    def get_content(self, program, url):
        self._select_country(program)
        
        result = []
        content = None
        if( "/api/emac/" in url ):
            content = self._load_json_page(url, emac_header)
        elif( "/api/opa/" in url ):
            content = self._load_json_page(url, opa_header)

        if( content ):
            if( content.get("data") ):
                result = self._get_content_from_data(content)
            elif( content.get("zones") ):
                result = self._get_content_from_zones(content)
            elif( content.get("categories") ):
                result = self._get_content_from_categories(content)
            elif( content.get("main") ):
                result = self._get_content_from_main(content)

        return result
            
    
    def get_items_from_content(self, program, url, args):
        self._select_country(program)
        result = []
        
        if not args.get('type'):
            # set 'zones' as default for backward compatibility
            args['type'] = 'zones'

        if 'zones' == args['type']:
            if( args.get("id") ):
                content = self._get_zones_from_url(url, emac_header)
                
                for key in content:
                    if( args["id"] == key["id"] ):
                        result = self._get_content_from_data(key)
                        break
        
        elif 'subcategories' == args['type']:
            if( args.get("id") ):
                content = self._get_subcategories_from_url(url, opa_header)

                for key in content:
                    if( args["id"] == key["code"] ):
                        #result = self._get_content_from_subcategories(key, key['code'], 'MOST_RECENT')
                        result = self._get_content_from_subcategories(key, key['code'], 'MOST_VIEWED')
                        break
        
        elif 'general' == args['type']:
            result = self.get_content(self.program, url)
        
        elif 'music' == args['type']:
            content = self.get_content(self.program, url)
            
            for item in content:
                if 'ARS' == item['data']['args']['id']:
                    result = self.get_items_from_content(program, item['data']['target_url'], item['data']['args'])
                    break
        
        return result


    def get_stream_data(self, program, url, quality="high"):
        self._select_country(program)
        result = []
        record = utils.get_new_record(self.mediathek, self.program, url)
        audio_tracks = {'de': 'german', 'fr': 'france'}
        audio_track = audio_tracks[self.country]
        '''
        url = url.replace("player", "opa")
        url = url.replace("v2", "v3")
        url = url.replace("config", "programs")
        content = self._load_json_page(url, opa_header)
        '''
        content = self._load_json_page(url, player_header)
        
        if '' != content:
            content = content["data"]["attributes"]
            stream_content = content["streams"]
            
            record["type"] = "play_stream"
            record["mode"] = "end"
            record["name"] = utils.get_safe(content, '["metadata"]["title"]')
            record["subtitle_url"] = ""
            record["plot"] = utils.get_safe(content, '["metadata"]["description"]')
            record["availability"] = self._encode_avail(utils.get_safe(content, '["rights"]["end"]'))
    
            record["data"]["duration"] = content["metadata"]["duration"]["seconds"]
            record["data"]["image_url"] = utils.get_safe(content, '["metadata"]["images"][0]["url"]')
            
            #dump_to_file(stream_content)
            record["data"]["target_url"] = self._get_stream_url(stream_content, quality, audio_track)
                    
        result.append(record)
        return result
    
    def _get_stream_url(self, data, quality, audio_track):
        '''
        version['code']:
        
        V         voix
        A         Allemagne
        F         France
        O         original
        ST        sous-titrer
        M         malentendant
        AUD       audio
        
        VA-STA    Deutsch                             closedCaptioning: false
        VOA-STA   Deutsch                             closedCaptioning: false
        VO-STA    Originalfassung - UT deutsch        closedCaptioning: false
        VAAUD     Deutsch (Hörfilm)                                                audioDescription: true
        VA-STMA   Deutsch (Hörgeschädigte)            closedCaptioning: true
        VF-STF    Französisch                         closedCaptioning: false
        VOF-STF   Französisch                         closedCaptioning: false
        VO-STF    Originalfassung - UT französisch    closedCaptioning: false
        VFAUD     Französisch (Hörfilm)                                            audioDescription: true
        VF-STMF   Französisch (Hörgeschädigte)        closedCaptioning: true
        VO        Originalfassung
        '''
        
        # filter streams
        audio_map = {
            'german': {'versions': ['VA', 'VO'], 'ad': False, 'closed_captioning': False},       # german or original version 
            'german_ad': {'versions': ['VAAUD', 'VO'], 'ad': True, 'closed_captioning': False},  # german with audio description or original version
            'german_cc': {'versions': ['VA', 'VO'], 'ad': False, 'closed_captioning': True},     # german with closed captioning or original version
            'france': {'versions': ['VF', 'VO'], 'ad': False, 'closed_captioning': False},       # france or original version
            'france_ad': {'versions': ['VFAUD', 'VO'], 'ad': True, 'closed_captioning': False},  # france with audio description or original version
            'france_cc': {'versions': ['VF', 'VO'], 'ad': False, 'closed_captioning': True},     # france with closed captioning or original version
        }
        
        streams_filtered = []
        audio = audio_map[audio_track]
        
        if False:
            # debugging only
            self.logger.debug(f'data: {data}')
            for stream in data:
                versions = stream.get("versions", [])
                self.logger.debug(f'versions: {versions}')

        for audio_version in audio['versions']:
            for stream in data:
                versions = stream.get("versions", [])
                
                if 1 <= len(versions):
                    version = versions[0]
                    stream_code = version['code']
                    ad = utils.get_safe(version, '["audioDescription"]', False)
                    closed_captioning = utils.get_safe(version, '["closedCaptioning"]', False)
                    language = utils.get_safe(version, '["audioLanguage"]', 'und')
                    quality = stream['mainQuality']['code']
    
                    if (audio_version in stream_code) and (audio["closed_captioning"] == closed_captioning) and (audio["ad"] == ad):
                        record = get_stream_record('hls', quality, stream["url"], ad, language)
                        streams_filtered.append(record)
                            
        if [] != streams_filtered:
            # no information about different qualities known yet. all qualities = XQ/720p
            return streams_filtered[0]["stream_url"]
        
        elif [] != data:
            # fallback, use first stream returned
            self.logger.error('no stream found, using fallback')
            #self.logger.debug(f'streams: {data}')
            return data[0]["url"]
        
        '''
        # get stream according to quality request
        qlist_high = [1080, 720, 406, 360, 216]
        qlist_medium = [406, 360, 216]
        qlist_low = [360, 216]
        
        quality_map = {'high': qlist_high, 'medium': qlist_medium, 'low': qlist_low}
        target_quality_list = quality_map[quality]
        
        for quality in target_quality_list:
            for stream in streams_filtered:
                if stream["quality"] == quality:
                    return stream["stream_url"]
        '''
                
        return ''


    def _get_content_from_categories(self, content):
        result = []
        for key in content['categories']:
            if "" != key['description']:
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                record["type"] = "category"
                record["mode"] = "get_content_from_categoy"
                record["name"] = key["label"]
                record["data"]["target_url"] = self.source_url
                record["data"]["args"]["type"] = 'subcategories'
                record["data"]["args"]["id"] = key["code"]
                record["data"]["args"]["name"] = key["label"]
                
                result.append(record)

        return result


    def _get_subcategories_from_url(self, url, header):
        result = []
        content = self._load_json_page(url, header)
        try:
            result = content['categories']
        except:
            pass
        return result


    def _get_content_from_subcategories(self, content, category, sort_method):
        result = []
        
        for item in content['subcategories']:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)

            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = item["label"]
            record["data"]["target_url"] = 'https://api-cdn.arte.tv/api/emac/v3/de/web/data/VIDEO_LISTING/?category={}&subcategories={}&imageFormats=landscape%2Cbanner%2Csquare%2Cportrait&imageWithText=true&videoType={}&limit={}'.format(category, item['code'], sort_method, self.page_limit)   
            
            result.append(record)
            
        return result


    def _get_content_from_main(self, content):
        result = []
        for key in content['main']:
            if "" != key['description']:
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = key["label"]
                record["data"]["target_url"] = "https://api-cdn.arte.tv/api/emac/v3/{}/web/{}?limit={}".format(self.country, key["code"], self.page_limit)
                record["data"]["image_url"] = self._get_image_url(key)
                
                result.append(record)
            
        return result


    def _get_content_from_data(self, content):
        result = []

        for key in content["data"]:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)

            if( "external" == key["kind"]["code"].lower() ):
                pass
            
            elif( False == key["kind"]["isCollection"] ):
                broadcasted =  utils.get_safe(key, '["availability"]["upcomingDate"]')
                record["aired"] = self._get_aired(broadcasted)
                
                record["type"] = "stream_meta_data"
                record["mode"] = "play_stream"
                record["name"] = key["title"]
                record["subtitle_url"] = ""
                record["plot"] = utils.get_safe(key, '["shortDescription"]')
                record["availability"] = self._encode_avail(utils.get_safe(key, '["availability"]["end"]'))
                
                record["data"]["target_url"] = "https://api.arte.tv/api/player/v2/config/{}/{}".format(self.country, key["programId"])
                record["data"]["duration"] = key["duration"]
                record["data"]["image_url"] = self._get_image_url(key)
                
                result.append(record)
                
            elif key.get('programId'):
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = key["title"]
                record["data"]["target_url"] = "https://api-cdn.arte.tv/api/emac/v3/{}/web/{}/?limit={}".format(self.country, key["programId"], self.page_limit)
                record["data"]["image_url"] = self._get_image_url(key)
                    
                result.append(record)
        
        next_page = utils.get_safe(content, '["nextPage"]', None)
        if( None != next_page ):
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = "Next page >>"
            record["data"]["target_url"] = content["nextPage"].replace("https://api-internal", "https://api-cdn")
            
            result.append(record)
            
        return result


    def _get_zones_from_url(self, url, header):
        result = []
        content = self._load_json_page(url, header)
        try:
            result = content["zones"]
        except:
            pass
        return result


    def _get_content_from_zones(self, content):
        result = []
        
        for key in content["zones"]:

            if( 'event' == key['displayOptions']['zoneLayout'] ):
                pass
            elif( (False == key['displayOptions']['showZoneTitle']) and
                  (False == key['displayOptions']['showItemTitle'])):
                pass
            else:
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
    
                data_result = self._get_content_from_data(key)
                link_url = utils.get_safe(key, '["link"]["url"]', None)
                deep_link = utils.get_safe(key, '["link"]["deeplink"]', None)
                
                if( len(data_result) and 
                    ((None == link_url) or (None == deep_link)) ):
                    record["type"] = "category"
                    record["mode"] = "get_content_from_categoy"
                    record["name"] = key["title"]
                    record["data"]["target_url"] = self.source_url
                    record["data"]["args"]["type"] = 'zones'
                    record["data"]["args"]["id"] = key["id"]
                    record["data"]["args"]["name"] = key["title"]

                    result.append(record)

                elif (len(data_result) and (None != link_url)):
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = key["title"]
                    record["data"]["target_url"] = 'https://api-cdn.arte.tv/api/emac/v3/{}/web/{}/?limit={}'.format(self.country, key["link"]['page'], self.page_limit)
                    
                    result.append(record)

        if( 1 == len(result) ):
            if( {} != result[0]["data"]["args"] ):
                result = self.get_items_from_content(self.program, result[0]["data"]["target_url"], result[0]["data"]["args"])
        
        return result


    def _get_aired(self, broadcasted):
        aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
        
        broadcasted = broadcasted[0:19]
        
        if( "" != broadcasted):
            bcstd = time.strptime(broadcasted,"%Y-%m-%dT%H:%M:%S")
            
            tm_hour = bcstd.tm_hour + self.delta_t
            if( 24 <= tm_hour ):
                tm_hour = tm_hour - 24
            
            aired["year"] = str(bcstd.tm_year)
            aired["mon"] = str(bcstd.tm_mon).zfill(2)
            aired["day"] = str(bcstd.tm_mday).zfill(2)
            aired["hour"] = str(tm_hour).zfill(2)
            aired["min"] = str(bcstd.tm_min).zfill(2)
            
        return aired


    def _get_image_url(self, data):
        url = ""
        img_format = ["landscape", "square"]
        
        for key in img_format:
            url = utils.get_safe(data, '["images"]["' + key + '"]["resolutions"][' + str(self.img_res) + ']["url"]')
            if( "" != url ):
                break

        if( "" == url ):
            url = utils.get_safe(data, '["images"]["portrait"]["resolutions"][0]["url"]')
                
        return url
    
    
    def _encode_avail(self, avail):
        availability = "Keine Information"
        
        try:
            if( 10 < len(avail) ):
                #'2025-02-07T04:00:00+00:00'
                #avail = time.strptime(avail,"%Y-%m-%dT%H:%M+%S:%S")
                availability = "Video verfügbar bis "
                availability = availability + str(avail[8:10]) + "."
                availability = availability + str(avail[5:7]) + "."
                availability = availability + str(avail[0:4])
        except:
            pass
        
        return availability


    def _select_country(self, program):
        if( "arte_de" == program ):
            self.country = "de"
        elif( "arte_fr" == program ):
            self.country = "fr"
        self.program = program


    def _load_json_page(self, url, headers=None):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")
        self.logger.debug("loading page {}".format(self.source_url))

        if( None == headers ):
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0'}
        
        content = requests.get(self.source_url, allow_redirects=True, headers=headers)
        if(content.encoding is not None):
            result = content.text.encode(content.encoding)
        else:
            result = content.text
        
        result = result.decode("utf-8")
        if( "<!doctype html>" in result[:40].lower() ):
            jresult = self._extract_json(result)
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""
        
        dump_to_file(jresult)
        return jresult


    def _extract_json(self, html):
        try:
            content = re.compile("type=\"application/json\">({.*})").search(html).group(1)
            content = json.loads(content)
        except:
            content = ""
        return content


    def _decode_deeplink(self, deeplink):
        # arte://collection/RC-014095?tab=RC-016723
        try:
            from urllib.parse import parse_qsl
        except ImportError:
            from urlparse import parse_qsl

        #deeplink = "arte://collection/RC-014095?tab=RC-016723"
        #deeplink = "arte://collection/RC-014095"
        
        link = ""
        
        if( None == deeplink ):
            return link
        
        encoded = deeplink.split("?")
        args = {}
        
        if( 1 < len(encoded) ):
            args = parse_qsl(encoded[1])
            args = dict(args)
        
        if( encoded[0].startswith("arte://collection/") ):
            collectionId = encoded[0].replace("arte://collection/", "")
            link = "https://api-cdn.arte.tv/api/emac/v3/{}/web/data/COLLECTION_SUBCOLLECTION/?collectionId={}&page=1&limit={}".format(self.country, collectionId, self.page_limit)
            
            
            if( args.get("tab") ):
                link = link + "&subCollectionId=" + args["tab"]
        
        return link


