


class Debug():
    
    def __init__(self):
        return
    
    
    def add_context_menu_item(self, li, function, data):
        return
        
        
    def debug_01(self, data):
        return
        
        
def dump_to_file(data):
    return

