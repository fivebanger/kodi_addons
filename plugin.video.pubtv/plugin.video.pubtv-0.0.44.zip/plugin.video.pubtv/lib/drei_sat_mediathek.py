# -*- coding: utf-8 -*-

import time
import logging

import utils
from zdf_dreisat_mediathek import ZDFDreiSatMediathek

try:
    from debug import dump_to_file
except:
    from release import dump_to_file


api_token_3sat = "528573d9434d560d7ccbdda720c337a7c9a81922 reraeB"
user_agent_3sat = "Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0"
header_3sat = {'Api-Auth': api_token_3sat[::-1], 'Accept-Encoding': 'gzip, deflate', 'User-Agent': user_agent_3sat}
#header_3sat = {'Api-Auth': api_token_3sat[::-1]}

categories_3sat = [
    {"name": "Startseite", "url": "/content/documents/zdf"},
    {"name": "Themen", "url": "/content/documents/zdf/themen"},
    {"name": "Kultur", "url": "/content/documents/zdf/kultur"},
    {"name": "Wissenschaft", "url": "/content/documents/zdf/wissen"},
    {"name": "Gesellschaft", "url": "/content/documents/zdf/gesellschaft"},
    {"name": "Film", "url": "/content/documents/zdf/film"},
    {"name": "Dokumentation", "url": "/content/documents/zdf/dokumentation"},
    {"name": "Kaberett & Comedy", "url": "/content/documents/zdf/kabarett"},
]

list_az_mapping_3sat = {
    "09": "0-9",
    "a": "A",
    "b": "B",
    "c": "C",
    "d": "D",
    "e": "E",
    "f": "F",
    "g": "G",
    "h": "H",
    "i": "I",
    "j": "J",
    "k": "K",
    "l": "L",
    "m": "M",
    "n": "N",
    "o": "O",
    "p": "P",
    "q": "Q",
    "r": "R",
    "s": "S",
    "t": "T",
    "u": "U",
    "v": "V",
    "w": "W",
    "x": "X",
    "y": "Y",
    "z": "Z"
}



class DreiSatMediathek(ZDFDreiSatMediathek):

    def __init__(self):
        self.delta_t = 0
        self.mediathek = "3sat"
        self.program = "3sat"
        self.source_url = ""
        self.base_url = "https://api.3sat.de"
        self.header = header_3sat
        self.categories = categories_3sat
        self.list_az = list_az_mapping_3sat
        self.player_id = 'ngplayer_2_4'
        self.search_str = ''
        self.from_to = ''
        self.logger = logging.getLogger('[3sat_mediathek]')
        
        if( True == time.localtime().tm_isdst ):
            self.delta_t = 1


    def _get_content_from_module(self, content, show_teaser=False):
        result = []
        
        for idx, key in enumerate(content['module']):
            filter_ref = key.get('filterRef')
            
            if key.get('title'):
                if key.get('teaser'):
                    add = True
                    live = key.get('livestreamRef')
                    
                    if None != live:
                        add = False
                            
                    result_tmp = self._get_content_from_teaser(key['teaser'])
                    
                    if [] == result_tmp:
                        add = False
                    
                    if add:
                        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                    
                        record["type"] = "category"
                        record["mode"] = "get_content_from_categoy"
                        record["name"] = key['title']
                        record["data"]["target_url"] = self.source_url
                        record["data"]["args"]["ref"] = idx
                        record["data"]["args"]['timestamp'] = content['modificationDate']
                        record["data"]["args"]["mode"] = 'get_from_teaser'
                                            
                        result.append(record)
                
                elif filter_ref:
                    if 0 != filter_ref['resultsWithVideo']['totalResultsCount']:
                        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                        
                        #url = filter_ref['resultsWithVideo']['self']
                        url = filter_ref['resultsWithVideo']['first']
                        
                        record["type"] = "category"
                        record["mode"] = "get_content"
                        record["name"] = key['title']
                        record["data"]["target_url"] = f"{self.base_url}{url}"
                                            
                        result.append(record)

            elif key.get('teaser') and show_teaser:
                result.extend(self._get_content_from_teaser(key['teaser']))
                
            elif filter_ref:
                results_videos = filter_ref['resultsWithVideo']
                videos = self._get_content_from_teaser(results_videos['http://zdf.de/rels/search/results'])
                # add next...?
                result.extend(videos)
                
        return result

