
import sys

from addon_utils import Dispatcher, sys_path_insert

#Make lib available
sys_path_insert('/lib')

from pubtv import PubTV


pubtv = PubTV()
dispatcher = Dispatcher(sys.argv)
dispatcher.handle(pubtv)

