
import xbmcvfs
import xbmc
import xbmcaddon
import xbmcplugin
import xbmcgui
import json
import inspect
import os
import sys

try:
    # Python 3
    from urllib.parse import urlencode, parse_qsl
except ImportError:
    # Python 2
    from urllib import urlencode
    from urlparse import parse_qsl
 
    

log_level = xbmc.LOGDEBUG


# icon: https://kodi.wiki/view/Default_Icons
# content: https://alwinesch.github.io/group__python__xbmcplugin.html#gaa30572d1e5d9d589e1cd3bfc1e2318d6
item_types = {'folder': {'icon': 'DefaultFolder.png', 'content': 'files',   'info_type': ''},
              'artist': {'icon': 'DefaultArtist.png', 'content': 'artists', 'info_type': ''},
              'music':  {'icon': 'DefaultFolder.png', 'content': 'songs',   'info_type': 'music'},
              'video':  {'icon': 'DefaultVideo.png',  'content': 'videos',  'info_type': 'video'}}


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')


def sys_path_insert(path):
    addon_path = ADDON.getAddonInfo('path')
    
    path = path.split('/')
    for item in path:
        if '' != item:
            addon_path = os.path.join(addon_path, item)
    
    sys.path.insert(0, addon_path)



class Dispatcher():
    
    def __init__(self, sys_args):        
        self.addon_url = sys_args[0]
        self.addon_handle = int(sys_args[1])
        addon_args = parse_qsl(sys_args[2][1:])
        self.addon_args = dict(addon_args)
        
    
    def get_addon_url(self):
        return self.addon_url
        
    
    def get_addon_handle(self):
        return self.addon_handle
        
    
    def get_addon_args(self):
        return self.addon_args

        
    def handle(self, appl):
        xbmc.log('[{}]: Dispatcher AddOn args: {}'.format(ADDON_NAME, self.addon_args), log_level)
        handle_err = True
        
        if {} == self.addon_args:
            mode = 'root'
            data = {}
        else:
            mode = self.addon_args['mode']
            data = self.addon_args['data']
            data = json.loads(data)
        
        result = inspect.getmembers(appl, predicate=inspect.ismethod)
        
        for item in result:
            name = item[0]
            funtion = item[1]
            
            if name == mode:
                appl.set_addon_data(self.addon_url, self.addon_handle)
                funtion(data)
                handle_err = False
                break
        
        if handle_err:
            xbmc.log('[{}]: Dispatcher mode error: {}'.format(ADDON_NAME, mode), xbmc.LOGERROR)
            

class ListItem():

    def __init__(self, addon_url, addon_handle, default_icon='', default_fanart=''):
        self.addon_handle = addon_handle
        self.addon_url = addon_url
        self.cm_items = []
        self.info_labels = {}
        self.default_icon = default_icon
        self.default_fanart = default_fanart
        self.li = None


    def add_item(self, name, mode, data, icon='', fanart='', item_type=''):
        if '' == item_type:
            item_type = 'folder'
        
        self.li = xbmcgui.ListItem(name)        
        self._add(mode, data, item_type, icon, fanart, True)
    
    
    def add_music_item(self, name, mode, data, icon='', fanart='', duration=0):
        item_type = 'music'
        self.info_labels.update({'duration': duration, "title": name})
        
        self.li = xbmcgui.ListItem(name)
        #hmk TODO: check self.li.setProperty('IsPlayable', 'true')
        self.li.setProperty('IsPlayable', 'true')
        self._add(mode, data, item_type, icon, fanart, False)
    
    def add_video_item(self, name, mode, data, icon='', fanart='', duration=0, plot=''):
        item_type = 'video'
        self.info_labels.update({'duration': duration, "plot": plot})
        
        self.li = xbmcgui.ListItem(name)
        #hmk TODO: check self.li.setProperty('IsPlayable', 'true')
        self.li.setProperty('IsPlayable', 'true')
        self._add(mode, data, item_type, icon, fanart, False)


    def end_of_directory(self):
        xbmcplugin.endOfDirectory(self.addon_handle)
        
        
    def add_context_menu_item(self, entry, mode, data):
        path = self._build_path(mode, data)
        self.cm_items.append((entry, 'RunPlugin({})'.format(path)))
    
    
    def clear_context_menu(self):
        self.cm_items = []
        
        
    def add_info_labels(self, info_lables):
            self.info_labels.update(info_lables)
    
    
    def clear_info_lables(self):
        self.info_labels = {}
        
        
    def _add(self, mode, data, item_type, icon, fanart, is_folder):
        path = self._build_path(mode, data)
        content = self._get_content(item_type)
        info_type = self._get_info_type(item_type)

        icon = self._get_icon(icon, item_type)
        fanart = self._get_fanart(fanart)
        
        self.li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
        self.li.addContextMenuItems(self.cm_items)
        self.li.setInfo(info_type, self.info_labels)
        
        xbmcplugin.addDirectoryItem(self.addon_handle, path, self.li, is_folder)
        xbmcplugin.setContent(self.addon_handle, content)
        
        self.cm_items = []
        self.info_labels = {}
    
    
    def _build_path(self, mode, data):
        data = json.dumps(data)
        query = {'mode': mode, 'data': data}
        encoded = urlencode(query)
        return '{}?{}'.format(self.addon_url, encoded)
    
    
    def _get_icon(self, icon, item_type):
        if '' == icon:
            if item_types.get(item_type):
                return item_types[item_type]['icon']
        elif 'default' == icon:
            icon = self.default_icon
        return icon
    
    
    def _get_fanart(self, fanart):
        if 'default' == fanart:
            fanart = self.default_fanart
        return fanart
    
    
    def _get_content(self, item_type):
        if item_types.get(item_type):
            return item_types[item_type]['content']
        return ''
    
    
    def _get_info_type(self, item_type):
        if item_types.get(item_type):
            return item_types[item_type]['info_type']
        return ''
    
    
class DataHandler():
    
    def __init__(self):
        self.paths = {}
    
    
    def register_path(self, item_name, path='', use_custom_folder_tag='', custom_folder_tag=''):
        result = False
        data_dir = self._check_path(path, use_custom_folder_tag, custom_folder_tag)
        
        if data_dir:
            new_path = {item_name: data_dir}
            self.paths.update(new_path)
            result = True

        return result
    
        
    def load_list(self, list_name, defaultList=[]):
        result = defaultList
        file_name = list_name + '.jsn'
        
        self._check_list_path(list_name, file_name)
        data = self.load_file(file_name)
        
        if data:
            try:
                result = json.loads(data)
            except:
                xbmc.log( ('[{}]: Error loading list {}'.format(ADDON_NAME, file_name)), xbmc.LOGERROR)
        else:
            xbmc.log( ('[{}]: Cannot load list {}'.format(ADDON_NAME, file_name)), xbmc.LOGERROR)
            self.save_list(list_name, defaultList, False)
        
        return result
    
    
    def save_list(self, list_name, list_data, list_backup=False):
        file_name_bak = list_name + '_bak.jsn'
        file_name = list_name + '.jsn'
        
        self._check_list_path(list_name, file_name_bak)
        self._check_list_path(list_name, file_name)
        
        if list_backup:
            result = self.load_file(file_name)
            if result:
                try:
                    # try to load json data
                    tmp = json.loads(result)
                    result = json.dumps(tmp)
                    # save old list data to backup file
                    self.save_file(file_name_bak, result)
                except:
                    xbmc.log( ('[{}]: Error loading list {}'.format(ADDON_NAME, file_name)), xbmc.LOGERROR)
        
        list_data = json.dumps(list_data)
        self.save_file(file_name, list_data)
            
    
    def load_file(self, file_name):
        result = None
        
        self._check_file_path(file_name)
        filePath = self._get_path(file_name)
        file = filePath + file_name

        if xbmcvfs.exists(file):
            fh = xbmcvfs.File(file, 'r')
            result = fh.read()
            fh.close()
        else:
            xbmc.log( ('[{}]: Cannot load file {}'.format(ADDON_NAME, file)), xbmc.LOGERROR)
        
        return result
            

    def save_file(self, file_name, data):
        result = False
        
        self._check_file_path(file_name)
        filePath = self._get_path(file_name)
        file = filePath + file_name
        
        try:
            fh = xbmcvfs.File(file, 'w')
            fh.write(data)
            fh.close()
            result = True
        except:
            xbmc.log( ('[{}]: Cannot save {}'.format(ADDON_NAME, file)), xbmc.LOGERROR)
            
        return result
            

    def delete_file(self, file_name, path='data'):
        pass
            

    def rename_file(self, old_filename, new_filename, backup=True, path='data'):
        pass
    
    
    def _get_path(self, item_name):
        if self.paths.get(item_name):
            return self.paths[item_name]

    
    def _check_list_path(self, list_name, file_name):
        if not self._get_path(list_name):
            self.register_path(list_name, '', '', '')
            
        if not self._get_path(file_name):
            # register a path for the list's filename
            list_path = self._get_path(list_name)
            new_path = {file_name: list_path}
            self.paths.update(new_path)
    
    
    def _check_file_path(self, file_name):
        if not self._get_path(file_name):
            self.register_path(file_name, '', '', '')
           
    
    def _check_path(self, path, use_custom_folder_tag, custom_folder_tag):
        data_dir = 'special://profile/addon_data/' + ADDON_ID + '/'
            
        if '' != use_custom_folder_tag:
            use_xchange_folder = ADDON.getSetting(use_custom_folder_tag)
            
            if 'true' == use_xchange_folder:
                if '' != data_dir:
                    data_dir = ADDON.getSetting(custom_folder_tag)
                else:
                    data_dir = None

        if data_dir:
            path = path.split('/')
            for item in path:
                if '' != item:
                    data_dir = data_dir + item + '/'
            
            if not xbmcvfs.exists(data_dir):
                if not xbmcvfs.exists(data_dir):
                    xbmc.log('[{}]: Create data folder {}'.format(ADDON_NAME, data_dir), log_level)
                    res = xbmcvfs.mkdir(data_dir)
                    
                    if False == res:
                        data_dir = None
        
        return data_dir
    
     
            