from url_utils import Urlbuild



class Contextmenu():
    
    def __init__(self, base_url):
        self.base_url = base_url
        
            
    def menu_item(self, type, name, cm_mode, data):
    
        ContextMenueItems = []
        
        url_create = Urlbuild(self.base_url)

        if type == 'main_menu':
            url_menu = url_create.addon({'mode': cm_mode, "data": data})
            ContextMenueItems.append((name, 'RunPlugin('+url_menu+')'))

        elif type == 'recently_menu':
            url_menu = url_create.addon({'mode': 'recently_items_play', 'type': 'played'})
            ContextMenueItems.append(('Play', 'RunPlugin('+url_menu+')'))
            
        elif type == 'categories_menu':
            url_menu = url_create.addon({'mode': 'recommend_genre', 'seed': id})
            ContextMenueItems.append(('Recommended albums', 'Container.Refresh('+url_menu+')'))
                        
        return ContextMenueItems

