# -*- coding: utf-8 -*-

import re
import time
import json
import requests

import utils
from mediathek import Mediathek


list_az_mapping = {
                    "09": "%23",
                    "a": "A",
                    "b": "B",
                    "c": "C",
                    "d": "D",
                    "e": "E",
                    "f": "F",
                    "g": "G",
                    "h": "H",
                    "i": "I",
                    "j": "J",
                    "k": "K",
                    "l": "L",
                    "m": "M",
                    "n": "N",
                    "o": "O",
                    "p": "P",
                    "q": "Q",
                    "r": "R",
                    "s": "S",
                    "t": "T",
                    "u": "U",
                    "v": "V",
                    "w": "W",
                    "x": "X",
                    "y": "Y",
                    "z": "Z"
                 }


class ARDMediathek(Mediathek):

    def __init__(self):
        self.img_res = "768"
        self.show_visible_title = True
        self.delta_t = 1
        self.mediathek = "ard"
        self.program = ""
        self.source_url = ""
        self.base_url = "https://api.ardmediathek.de/public-gateway"
        
        if( True == time.localtime().tm_isdst ):
            self.delta_t = 2

        
    def get_categories(self, program):
        self.program = program
        return self._get_content_from_default_page(program)


    def get_shows_by_date(self, program, date):
        self.program = program
        return self._get_content_from_program_page(program, date)


    def get_shows_by_char(self, program, charakter):
        self.program = program
        charakter = list_az_mapping[charakter]
        url = self._get_shows_az_url(program, charakter)
        return self.get_content(program, url)


    def search(self, program, search_str):
        self.program = program
        url = self._get_search_url(program, search_str, 0)
        return self.get_content(program, url)
        

    def get_content(self, program, url):
        self.program = program

        result = []
        content = self._load_json_page(url)
        
        if( "" != content ):  
            if( content.get("teasers") ):
                result = self._get_content_from_teasers(content)
                
            elif ( content.get("widgets") ):
                result = self._get_content_from_widgets(content)
           
        return result
    

    def get_items_from_content(self, program, url, args):
        self.program = program
        
        result = []
        content = self._load_json_page(url)
        
        if( "" != content ):
#             widget_idx = args["widget_idx"]
#             result = self._get_data_from_teasers(content["widgets"][widget_idx]["teasers"])
            for key in content["widgets"]:
                if( args["ref"] == key["id"] ):
                    result = self._get_data_from_teasers(key["teasers"])
        
                    page_number = key["pagination"]["pageNumber"]
                    page_size = key["pagination"]["pageSize"]
                    total = key["pagination"]["totalElements"]
                    
                    if( total > ((page_number + 1) * page_size) ):
                        current_number = "pageNumber=" + str(page_number)
                        next_number = "pageNumber=" + str(page_number + 1)
                        url = key["links"]["self"]["href"].replace(current_number, next_number)
                        
                        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                        
                        record["type"] = "category"
                        record["mode"] = "get_content"
                        record["name"] = "Next page >>"
                        record["data"]["target_url"] = url
                        
                        result.append(record)
                    
                    break
        
        return result


    def get_stream_data(self, program, url, quality="high"):
        self.program = program
        result = []
        
        content = self._load_json_page(url)
        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
        
        record["type"] = "play_stream"
        record["mode"] = "end"
        record["name"] = utils.get_safe(content, '["widgets"][0]["title"]').replace("\n", " ")
        record["subtitle_url"] = ""
        record["plot"] = utils.get_safe(content, '["widgets"][0]["synopsis"]')
        record["availability"] = self._encode_avail(utils.get_safe(content, '["widgets"][0]["availableTo"]'))
        record["aired"] = self._get_aired(utils.get_safe(content, '["widgets"][0]["broadcastedOn"]'))

        record["data"]["duration"] = utils.get_safe(content, '["widgets"][0]["mediaCollection"]["embedded"]["_duration"]', 0)
        record["data"]["image_url"] = utils.get_safe(content, '["widgets"][0]["image"]["src"]').replace("{width}", self.img_res)
        
        stream_urls = utils.get_safe(content, '["widgets"][0]["mediaCollection"]["embedded"]["_mediaArray"][0]["_mediaStreamArray"]', [])

        quality_idx = {"low": 1, "medium": 2, "high": 3}
        quality_mapping = [0, 1, 2, 3]
        q = quality_idx[quality]

        while(q):
            try:
                for key in stream_urls:
                    if( quality_mapping[q] == key["_quality"] ):
                        if( isinstance(key["_stream"], list) ):
                            record["data"]["target_url"] = key["_stream"][0]
                        else:
                            record["data"]["target_url"] = key["_stream"]
                        q = 0
                        break
            except:
                pass
            
            if( 0 < q ):
                q = q - 1

        if( record["data"]["target_url"].startswith("//") ):
            record["data"]["target_url"] = "https:" + record["data"]["target_url"]
            
        result.append(record)
        return result

    
    def _get_content_from_teasers(self, content):
        teasers = content["teasers"]
        result = self._get_data_from_teasers(teasers)
        
        page_number = content["pagination"]["pageNumber"]
        page_size = content["pagination"]["pageSize"]
        total = content["pagination"]["totalElements"]
        
        if( total > ((page_number + 1) * page_size) ):
            current_number = "pageNumber=" + str(page_number)
            next_number = "pageNumber=" + str(page_number + 1)
            url = content["links"]["self"]["href"].replace(current_number, next_number)
            
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = "Next page >>"
            record["data"]["target_url"] = url
            
            result.append(record)
            
        return result

    
    def _get_data_from_teasers(self, teasers):
        result = []
        
        for teaser in teasers:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                    
            if( teaser.get("type") ):
                if( ("compilation" == teaser["type"]) or
                    ("show" == teaser["type"]) ):
                        
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = teaser["mediumTitle"].replace("\n", " ")
                    record["data"]["target_url"] = teaser["links"]["target"]["href"]
                    record["data"]["image_url"] = self._get_image_url(teaser["images"])
                    
                    result.append(record)
                
                elif( ("editorialPage" == teaser["type"]) ):
                        
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = teaser["mediumTitle"].replace("\n", " ")
                    record["data"]["target_url"] = teaser["links"]["target"]["href"]
                    record["data"]["image_url"] = self._get_image_url(teaser["images"])
                    
                    result.append(record)
                    
                elif( "live" != teaser["type"] ):
                    number_of_clips = utils.get_safe(teaser, '["numberOfClips"]', 1)
                    
                    if( 0 < number_of_clips):
                        record["type"] = "stream_meta_data"
                        record["mode"] = "play_stream"
                        record["name"] = teaser["mediumTitle"].replace("\n", " ")
                        record["plot"] = utils.get_safe(teaser, '["show"]["longSynopsis"]')
                        record["subtitle_url"] = ""
                        record["aired"] = self._get_aired(utils.get_safe(teaser, '["broadcastedOn"]'))
                        
                        record["data"]["target_url"] = teaser["links"]["target"]["href"]
                        record["data"]["duration"] = utils.get_safe(teaser, '["duration"]')
                        record["data"]["image_url"] = self._get_image_url(teaser["images"])
    
                        result.append(record)
        
        return result

    
    def _get_content_from_widgets(self, content):
        result = []
        
        if( len(content["widgets"]) <= 1 ):
            widgets = content["widgets"][0]
            
            result = self._get_data_from_teasers(widgets["teasers"])
            
            page_number = widgets["pagination"]["pageNumber"]
            page_size = widgets["pagination"]["pageSize"]
            total = widgets["pagination"]["totalElements"]
            
            if( total > ((page_number + 1) * page_size) ):
                current_number = "pageNumber=" + str(page_number)
                next_number = "pageNumber=" + str(page_number + 1)
                url = widgets["links"]["self"]["href"].replace(current_number, next_number)
                
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = "Next page >>"
                record["data"]["target_url"] = url
                
                result.append(record)
        else:
            for idx, key in enumerate(content["widgets"]):
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
                record["type"] = "category"
                record["mode"] = "get_content_from_categoy"
                record["name"] = key["title"]
                record["data"]["target_url"] = self.source_url
                record["data"]["args"]["widget_idx"] = idx
                record["data"]["args"]["ref"] = key["id"]
                                    
                result.append(record)
        
        return result


    def _get_content_from_default_page(self, program):
        result = []

        url = self._get_default_url(program)
        content = self._load_json_page(url)
        result = self._get_content_from_widgets(content)
            
        return result


    def _get_content_from_program_page(self, program, date):
        result = []
        
        url = self._get_program_url(program, date)
        content = self._load_json_page(url)
        
        if( "" != content ):
            result = self._get_content_from_teasers(content[0])
        
        return result


    def _get_default_url(self, program):
        url_base = "https://api.ardmediathek.de/page-gateway/pages/%s/home" %(program)
        return url_base
    
    
    def _get_program_url(self, program, date):
        page_number = 0
        page_size = 200
        url_base = "https://api.ardmediathek.de/page-gateway/compilations/%s/pastbroadcasts" %(program)
        url = "?startDateTime=%sT00:00:00.000Z&endDateTime=%sT23:59:59.000Z&pageNumber=%d&pageSize=%d" %(date, date, page_number, page_size)
        return url_base + url
    
    
    def _get_shows_az_url(self, program, charakter):
        page_number = 0
        page_size = 20
        url_base = "https://api.ardmediathek.de/page-gateway/compilations/%s/shows/" %(program)
        url = "%s?pageNumber=%d&pageSize=%d&embedded=true" %(charakter, page_number, page_size)
        return url_base + url
    
    
    def _get_search_url(self, program, search_str, page_number):
        page_size = 20
        url_base = "https://api.ardmediathek.de/page-gateway/widgets/%s/search/vod" %(program)
        url = "?searchString=%s&pageNumber=%d&pageSize=%d" %(search_str, page_number, page_size)
        return url_base + url
    
    
    def _encode_avail(self, avail):
        availability = "Keine Information"
        
        try:
            if( 10 < len(avail) ):
                # 2021-10-12T21:59:00Z
                #avail = time.strptime(avail,"%Y-%m-%dT%H:%M:%SZ")
                #availability = "Video verfügbar bis "
                #availability = availability + str(avail.tm_mday).zfill(2) + "."
                #availability = availability + str(avail.tm_mon).zfill(2) + "."
                #availability = availability + str(avail.tm_year)
                
                availability = "Video verfügbar bis "
                availability = availability + str(avail[8:10]) + "."
                availability = availability + str(avail[5:7]) + "."
                availability = availability + str(avail[0:4])
        except:
            pass
        
        return availability
    
    
    def _get_image_url(self, images):
        image_url = ""
        
        for key in images:
            if( key.startswith("aspect") ):
                image_url = images[key]["src"].replace("{width}", self.img_res)
                break
            
        return image_url


    def _get_aired(self, broadcasted):
        aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
        
        if( "" != broadcasted):
            bcstd = time.strptime(broadcasted,"%Y-%m-%dT%H:%M:%SZ")
            
            tm_hour = bcstd.tm_hour + self.delta_t
            if( 24 <= tm_hour ):
                tm_hour = tm_hour - 24
            
            aired["year"] = str(bcstd.tm_year)
            aired["mon"] = str(bcstd.tm_mon).zfill(2)
            aired["day"] = str(bcstd.tm_mday).zfill(2)
            aired["hour"] = str(tm_hour).zfill(2)
            aired["min"] = str(bcstd.tm_min).zfill(2)
            
        return aired
    
    
    def _load_json_page(self, url):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")
        content = requests.get(self.source_url, allow_redirects=True);
        if(content.encoding is not None):
            result = content.text.encode(content.encoding)
        else:
            result = content.text
        
        result = result.decode("utf-8")
        if( "<!DOCTYPE html>" in result[:40] ):
            jresult = self._extract_json(result)
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""

        return jresult


    def _extract_json(self, html):
        try:
            content = re.compile("__APOLLO_STATE__ = ({.*});").search(html).group(1)
            content = json.loads(content)
        except:
            content = ""
        return content

    

