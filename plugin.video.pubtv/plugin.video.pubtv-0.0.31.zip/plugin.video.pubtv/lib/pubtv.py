
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import os

try:
    # Python 3
    from urllib.parse import quote
except ImportError:
    # Python 2
    from urllib import quote
    
try:
    from internal import Debug
except:
    from release import Debug


from mediathek_handler import MediathekHandler
import utils


from addon_utils import ListItem, DataHandler



quality_mapping = {"0": "low", "1": "medium", "2": "high"}



class PubTVLogger():
    
    def __init__(self):
        self.do_log = True
        #self.do_log = False
    
    
    def error(self, text):
        self._log(text, xbmc.LOGERROR)
    
    
    def warning(self, text):
        self._log(text, xbmc.LOGWARNING)
    
    
    def debug(self, text):
        self._log(text, xbmc.LOGDEBUG)
    
    
    def info(self, text):
        self._log(text, xbmc.LOGINFO)


    def _log(self, text, level):
        if xbmc.LOGERROR == level:
            xbmc.log('[PubTV]: {}'.format(text), level)
        elif self.do_log:
            xbmc.log('[PubTV]: {}'.format(text), level)


class PubTV():
    
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.addon_url = None
        self.addon_handle = None
        
        self.mh = MediathekHandler()
        self.logger = PubTVLogger()
        self.data = DataHandler()
        self.data.register_path('list', '/.mdat', 'use_xchange_folder', 'xchange_folder')
        
        self.dbg = Debug()
        
        self.listRecent = 'recent'
        self.listMyList = 'list'
        self.listSearch = 'search'
        
        quality = self.addon.getSetting("quality")
        self.mh.set_stream_quality(quality_mapping[quality])
        self.mh.set_logger(self.logger)
    
    
    def set_addon_data(self, addon_url, addon_handle):
        self.addon_url = addon_url
        self.addon_handle = addon_handle
    
    
    def root(self, data):
        result = self.mh.get_programs()
        result = self._filter_program(result)
        self._handle_result('get_programs', result)
        
        
    def new_search(self, data):
        search_str = self._get_search_str()
        if( "" == search_str ):
            return
        
        self._add_to_search_history(search_str, data)
        search_str = quote(search_str)
        self.mh.set_search_string(search_str)
        result = self.mh.search(data)
        self._handle_result('get_search_result', result)
        
        
    def get_menu(self, data):
        result = self.mh.get_menu(data)
        self._handle_result('get_menu', result)


    def list_categories(self, data):
        result = self.mh.list_categories(data)
        self._handle_result('list_categories', result)
        
        
    def list_dates(self, data):
        result = self.mh.list_dates(data)
        self._handle_result('list_dates', result)
        
        
    def get_shows_by_date(self, data):
        result = self.mh.get_shows_by_date(data)
        self._handle_result('get_shows_by_date', result)
        
        
    def list_az(self, data):
        result = self.mh.list_az(data)
        self._handle_result('list_az', result)
        
        
    def get_shows_by_char(self, data):
        result = self.mh.get_shows_by_char(data)
        self._handle_result('get_shows_by_char', result)
        
        
    def search(self, data):
        result = self._get_search_menu(data)
        self._handle_result('search', result)
        
        
    def get_search_result_from_data(self, data):
        search_str = quote(data["args"]["name"])
        self.mh.set_search_string(search_str)
        result = self.mh.search(data)
        self._handle_result('get_search_result_from_data', result)
        
        
    def get_content(self, data):
        result = self.mh.get_content(data)
        self._handle_result('get_content', result)
        
        
    def get_content_from_categoy(self, data):
        result = self.mh.get_items_from_content(data)
        self._handle_result('get_content_from_categoy', result)
        
        
    def play_stream(self, data):
        result = self.mh.play_stream(data)
        self._handle_result('play_stream', result)
        
        
    def get_my_list(self, data):
        result = self._load_my_list()
        self._handle_result('get_my_list', result)
        
        
    def get_recently(self, data):
        result = self._load_recently()
        self._handle_result('get_recently', result)
    
    
    def get_all_programs(self, data):
        result = self.mh.get_programs()
        self._handle_result('get_all_programs', result)
        
        
    def home(self, data):
        xbmc.executebuiltin( "Container.Update(plugin://plugin.video.pubtv, replace)" )

    
    def hide_program(self, data):
        self.addon.setSetting(data["data"]["program"], "false")
        xbmc.executebuiltin( "Container.Refresh" )

    
    def show_program(self, data):
        self.addon.setSetting(data["data"]["program"], "true")
        xbmc.executebuiltin( "Container.Update(%s, replace)" %(self.addon_url) )
    
    
    def remove_recently(self, data):
        result = self.data.load_list(self.listRecent)
        
        for key in result:
            if( key["name"] == data["name"] ):
                result.remove(key)
                self.data.save_list(self.listRecent, result)
                xbmc.executebuiltin( "Container.Refresh" )
                break
    
    
    def add_to_list(self, data):
        data_copy = data.copy()
        
        if( "zdf" == data_copy["data"]["mediathek"] ):
            data_copy["data"]["program"] = "ZDF"
        
        name = data_copy["name"]
        program = self.mh.get_program_name(data_copy["data"]["program"])
        data_copy["name"] = program + " | " + name
        
        result = self.data.load_list(self.listMyList)
        
        if( [] != result ):
            for key in result:
                if( key["name"] == data_copy["name"] ):
                    heading = name
                    message = "Already added to list"
                    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING)
                    return
        
        result.insert(0, data_copy)
        #result.append(data_copy)
        self.data.save_list(self.listMyList, result)
        
        heading = name
        message = "Added to list"
        icon = os.path.join(self.addon.getAddonInfo('path'), "icon.png")
        xbmcgui.Dialog().notification(heading, message, icon)
    
    
    def remove_from_list(self, data):
        result = self.data.load_list(self.listMyList)
        
        for key in result:
            if( key["name"] == data["name"] ):
                result.remove(key)
                self.data.save_list(self.listMyList, result)
                xbmc.executebuiltin( "Container.Refresh" )
                break
    
    
    def remove_search(self, data):
        result = self.data.load_list(self.listSearch)
        
        for key in result:
            if( key["args"]["name"] == data["data"]["args"]["name"] ):
                result.remove(key)
                self.data.save_list(self.listSearch, result)
                xbmc.executebuiltin( "Container.Refresh" )
                break
    
    
    def clear_search_history(self):
        result = []
        self.data.save_list(self.listSearch, result)
        xbmc.executebuiltin( "Container.Refresh" )
    
    
    def show_availability(self, data):
        result = self.mh.play_stream(data["data"])
        result = result[0]["availability"]
        dialog = xbmcgui.Dialog()
        dialog.ok('Available info', result)
        
    
    def debug_01(self, data):
        result = self.mh.play_stream(data['data'])
        self.dbg.debug_01(result)
        
        
    def _handle_result(self, mode, result):        
        li = ListItem(self.addon_url, self.addon_handle)
        
        fanart_url = os.path.join(self.addon.getAddonInfo('path'), 'fanart.jpg')
        #fanart_url = ""
        icon_url = ""

        for key in result:
            name = key["name"]
            
            if( "get_shows_by_date" == mode ):
                name = "(%s:%s) %s" %(key["aired"]["hour"], key["aired"]["min"], key["name"])

            if( "category" == key["type"] ):
                fanart = key["data"]["program"] + ".jpg"
                icon = key["data"]["program"] + ".png"
                
                if( ("get_programs" == mode) or
                    ("get_all_programs" == mode) ):
                    #fanart_url = os.path.join(self.addon.getAddonInfo('path'), 'resources', 'fanart', fanart)
                    icon_url = os.path.join(self.addon.getAddonInfo('path'), 'resources', 'icons', icon)
                else:
                    fanart_url = os.path.join(self.addon.getAddonInfo('path'), 'resources', 'fanart',  fanart)
                    #icon_url = os.path.join(self.addon.getAddonInfo('path'), 'resources', 'icons', icon)
                    
                #hmk icon_url = os.path.join(self.addon.getAddonInfo('path'), icon)
                
                if( "true" == self.addon.getSetting("category_fanart") ):
                    if( "" != key["data"]["image_url"] ):
                        #fanart_url = key["data"]["image_url"]
                        icon_url = key["data"]["image_url"]
                                      
                if( "get_my_list" != mode ):
                    if( ("get_content" == key["mode"]) or
                        ("get_content_from_categoy" == key["mode"]) ):
                        li.add_context_menu_item('Add to my list', 'add_to_list', key)
                        
                    elif( ("get_programs" == mode) and
                          ("get_menu" == key["mode"]) ):
                        li.add_context_menu_item('Hide program', 'hide_program', key)
                        
                    elif( "get_all_programs" == mode ):
                        if( "false" == self.addon.getSetting(key["data"]["program"]) ):
                            li.add_context_menu_item('Show program', 'show_program', key)
                        else:
                            li.add_context_menu_item('Hide program', 'hide_program', key)
                        
                    elif( "new_search" == key["mode"] ):
                        li.add_context_menu_item('Clear search history', 'clear_search_history', key)
                        
                    elif( "get_search_result_from_data" == key["mode"] ):
                        li.add_context_menu_item('Remove from search', 'remove_search', key)
                else:
                    li.add_context_menu_item('Remove from my list', 'remove_from_list', key)
                    
                if( ("get_content" == key["mode"]) or
                    ("get_content_from_categoy" == key["mode"]) ):
                    li.add_context_menu_item('Home', 'home', key)
                
                li.add_item(name, key["mode"], key["data"], icon_url, fanart_url)
            
            elif( "stream_meta_data" == key["type"] ):
                fanart_url = key["data"]["image_url"]
                
                if( "" == fanart_url ):
                    fanart = key["data"]["program"] + ".jpg"
                    fanart_url = os.path.join(self.addon.getAddonInfo('path'), 'resources', 'fanart', fanart)
                
                li.add_context_menu_item('Available to', 'show_availability', key)
                
                if( "get_recently" == mode ):
                    li.add_context_menu_item('Remove from recently', 'remove_recently', key)
                
                li.add_context_menu_item('Home', 'home', key)
                self.dbg.add_context_menu_item(li, 'debug_01', key)
                
                li.add_video_item(name, key["mode"], key["data"], key["data"]["image_url"], fanart_url, key["data"]["duration"], key["plot"])
                
            elif( "play_stream" == key["type"] ):
                self._play_stream(result[0])
                return
        
            else:
                xbmc.log('[PubTV]: Dispatcher route: wrong mode: %s' %mode, xbmc.LOGERROR)
        
        
        if( "true" == self.addon.getSetting("use_thumbnail") ):
            xbmc.executebuiltin( "Container.SetViewMode(500)" )
        else:
            xbmc.executebuiltin( "Container.SetViewMode(0)" )
            
        li.end_of_directory()
    
    
    def _play_stream(self, result):
        stream_url = result["data"]["target_url"]
        play_item = xbmcgui.ListItem(path=stream_url)
        
        if( "" == stream_url ):
            xbmc.log('[PubTV]: Dispatcher play error: %s' %(result), xbmc.LOGERROR)
            xbmcplugin.setResolvedUrl(self.addon_handle, False, listitem=play_item)
            
            info = "Kein Video-Stream zur Wiedergabe gefunden"
            dialog = xbmcgui.Dialog()
            dialog.ok('Play error', info)
        else:
            xbmc.log('[PubTV]: Play video stream: %s' %(stream_url), xbmc.LOGINFO)
            icon = result["data"]["image_url"]
            play_item.setLabel(result["name"])
            play_item.setArt({'thumb': icon, 'icon': icon, 'fanart': icon})
            self._add_to_recently(result)
            xbmcplugin.setResolvedUrl(self.addon_handle, True, listitem=play_item)

    
    def _filter_program(self, result):
        list_all = False
        data = []
        
        record = utils.get_new_record("none", "none", "none")
        record["type"] = "category"
        record["mode"] = "get_my_list"
        record["name"] = "My list"
        record["data"]["program"] = "list"
        data.append(record)
        
        record = utils.get_new_record("none", "none", "none")
        record["type"] = "category"
        record["mode"] = "get_recently"
        record["name"] = "Recently watched"
        record["data"]["program"] = "list"
        data.append(record)
        
        for key in result:
            if( "false" == self.addon.getSetting(key["data"]["program"]) ):
                list_all = True
            else:
                data.append(key)
            
        if( list_all ):
            record = utils.get_new_record("none", "none", "none")
            record["type"] = "category"
            record["mode"] = "get_all_programs"
            record["name"] = "Show all programs"
            record["data"]["program"] = "list"
            data.insert(2, record)

        return data
    
    
    def _load_recently(self):
        result = self.data.load_list(self.listRecent)
        return result
    
    
    def _add_to_recently(self, data, max_items=50):
        data_copy = data.copy()
        
        
        data_copy["data"]["target_url"] = data_copy["source_url"]
        data_copy["type"] = "stream_meta_data"
        data_copy["mode"] = "play_stream"
        
        if( "zdf" == data_copy["data"]["mediathek"] ):
            data_copy["data"]["program"] = "ZDF"
        
        program = self.mh.get_program_name(data_copy["data"]["program"])
        data_copy["name"] = program + " | " + data_copy["name"]
        
        result = self.data.load_list(self.listRecent)
        
        if( [] != result ):
            for key in result:
                if( key["name"] == data_copy["name"] ):
                    return
        
        result.insert(0, data_copy)
        if( max_items < len(result) ):
            result.pop()
            
        self.data.save_list(self.listRecent, result)
    
    
    def _load_my_list(self):
        result = self.data.load_list(self.listMyList)
        return result


    def _get_search_menu(self, data):
        result = []
        
        history = self._load_search_history(data)
        mediathek = data["mediathek"]
        program = data["program"]
        
        record = utils.get_new_record(mediathek, program, "")
        record["type"] = "category"
        record["mode"] = "new_search"
        record["name"] = "New search"
        record["data"] = data
        result.append(record)
        
        for key in history:
            record = utils.get_new_record(mediathek, program, "")
            record["type"] = "category"
            record["mode"] = "get_search_result_from_data"
            record["name"] = key["args"]["name"]
            record["data"] = key
            record["data"]["mediathek"]= data["mediathek"]
            record["data"]["program"]= data["program"]
            result.append(record)
        
        return result
    
    
    def _load_search_history(self, data):
        result = self.data.load_list(self.listSearch)
        return result
    
    
    def _add_to_search_history(self, search_str, data, max_items=20):
        result = self.data.load_list(self.listSearch)
        
        if( [] != result ):
            for key in result:
                if( key["args"]["name"].lower() == search_str.lower() ):
                    return
        
        data["args"]["name"] = search_str
        result.insert(0, data)
        if( max_items < len(result) ):
            result.pop()

        self.data.save_list(self.listSearch, result)


    def _get_search_str(self):
        return self._get_text_from_keyboard("Search", "")

    
    def _get_text_from_keyboard(self, heading="", text="", hidden=False):
        string = ""
        keyboard = xbmc.Keyboard(text, heading)
        keyboard.setHiddenInput(hidden)
        keyboard.doModal()
        if keyboard.isConfirmed():
            string = keyboard.getText()
        return string
        


