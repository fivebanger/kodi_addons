


class Debug():
    
    def __init__(self):
        pass
    
    
    def add_context_menu_item(self, li, function, data):
        pass
        
        
    def debug_01(self, data):
        pass