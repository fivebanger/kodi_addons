



def get_new_record(mediathek, program, source_url):
    data = {"mediathek": mediathek, "program": program, "target_url": "", "duration": "", "image_url": "", "args":{}}
    aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
    return {"type": "unknown", "mode": "unknown", "name": "unknown", "aired": aired, "subtitle_url": "", "plot": "", "availability": "", "source_url": source_url, "data": data}

