# -*- coding: utf-8 -*-

import logging

import utils
from zdf_dreisat_mediathek import ZDFDreiSatMediathek

try:
    from debug import dump_to_file
except:
    from release import dump_to_file


api_token_zdf = "5d60797c60d131389d7d216941705bd790002bb5 reraeB"
user_agent_zdf = "Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0"
header_zdf = {'Api-Auth': api_token_zdf[::-1], 'Accept-Encoding': 'gzip, deflate', 'User-Agent': user_agent_zdf}

categories_zdf = [
    {"name": "Startseite", "url": "/content/documents/zdf?profile=cellular-5"},
    {"name": "Filme", "url": "/content/documents/filme-104.json?profile=cellular-5"},
    {"name": "Serien", "url": "/content/documents/serien-100.json?profile=cellular-5"},
    {"name": "Dokus & Reportagen", "url": "/content/documents/doku-wissen-104.json?profile=cellular-5"},
    {"name": "Nachrichten", "url": "/content/documents/nachrichten-sendungen-100.json?profile=cellular-5"},
    {"name": "Comedy & Satire", "url": "/content/documents/comedy-102.json?profile=cellular-5"},
    {"name": "Kinder/ZDFtivi", "url": "/content/documents/zdftivi-fuer-kinder-100.json?profile=cellular-5"},
    {"name": "Politik & Gesellschaft", "url": "/content/documents/politik-gesellschaft-102.json?profile=cellular-5"},
    {"name": "ZDFkultur", "url": "/content/documents/kultur-110.json?profile=cellular-5"},
    {"name": "sportstudio", "url": "/content/documents/sport-106.json?profile=cellular-5"},
    {"name": "Krimi", "url": "/content/documents/krimi-102.json?profile=cellular-5"},
    {"name": "Verbraucher", "url": "/content/documents/verbraucher-102.json?profile=cellular-5"},
]

list_az_mapping_zdf = {
    "09": "0 - 9",
    "a": "A",
    "b": "B",
    "c": "C",
    "d": "D",
    "e": "E",
    "f": "F",
    "g": "G",
    "h": "H",
    "i": "I",
    "j": "J",
    "k": "K",
    "l": "L",
    "m": "M",
    "n": "N",
    "o": "O",
    "p": "P",
    "q": "Q",
    "r": "R",
    "s": "S",
    "t": "T",
    "u": "U",
    "v": "V",
    "w": "W",
    "x": "X",
    "y": "Y",
    "z": "Z"
}


class ZDFMediathek(ZDFDreiSatMediathek):

    def __init__(self):
        self.delta_t = 0
        self.mediathek = "zdf"
        self.program = ""
        self.source_url = ""
        self.base_url = "https://api.zdf.de"
        self.header = header_zdf
        self.categories = categories_zdf
        self.list_az = list_az_mapping_zdf
        self.player_id = 'ngplayer_2_4'
        self.search_str = ''
        self.from_to = ''
        self.show_live = False
        self.logger = logging.getLogger('[zdf_mediathek]')
        
        
    def _get_content_from_module(self, content, show_teaser=False):
        result = []

        for idx, key in enumerate(content["module"]):
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            tracking_title = key.get("trackingTitle")
            teaser = key.get("teaser")
            
            if( (None != tracking_title) and
                (list == type(teaser)) ):
                record["type"] = "category"
                record["mode"] = "get_content_from_categoy"
                record["name"] = key["title"]
                record["data"]["target_url"] = self.source_url
                record["data"]["args"]["module_idx"] = idx
                record["data"]["args"]["ref"] = tracking_title
                                    
                result.append(record)
            
            elif dict == type(teaser):
                target = teaser['target']['canonical']
                
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = key["title"]
                record["data"]["target_url"] = f"{self.base_url}{target}?profile=cellular-5"
                                    
                result.append(record)
            
            elif list == type(teaser):
                teaser_result = self._get_content_from_teaser_cellular(teaser)
                result.extend(teaser_result)
        
        return result

