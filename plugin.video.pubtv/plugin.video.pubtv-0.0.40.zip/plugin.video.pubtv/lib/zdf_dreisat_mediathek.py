# -*- coding: utf-8 -*-

import time
import json
import requests

from datetime import datetime, timedelta

import utils
from mediathek import Mediathek

try:
    from debug import dump_to_file
except:
    from release import dump_to_file



def get_stream_record(mime_type, quality, stream_url, kind, language):
    record = {}
    record["mime_type"] = mime_type
    record["quality"] = quality
    record["stream_url"] = stream_url
    record["kind"] = kind
    record["language"] = language
    return record




class ZDFDreiSatMediathek(Mediathek):

    def get_categories(self, program):
        self.program = program
        return self._get_categories_static()
        #return self._get_categories_api()


    def get_shows_by_date(self, program, date):
        self.program = program
        result = []

        start_time = ['05', '30', '00', '+02:00']   # hour, minute, second, UTC offset
        date_from = f"{date}T{start_time[0]}:{start_time[1]}:{start_time[2]}{start_time[3]}"
        t = time.strptime(date_from, '%Y-%m-%dT%H:%M:%S%z')
        date_to = datetime(t.tm_year, t.tm_mon, t.tm_mday)
        date_to = date_to + timedelta(days=1)
        date_to = f"{date_to.strftime('%Y-%m-%d')}T{start_time[0]}:{start_time[1]}:{start_time[2]}{start_time[3]}"
        
        self.from_to = f"from={date_from}&to={date_to}"
        self.from_to = self.from_to.replace(':', '%3A')
        self.from_to = self.from_to.replace('+', '%2B')
        
        url = self._get_mapped_url('get_shows_by_date', self.from_to)
        content = self._load_json_page(url)
        
        if "" != content:
            target = 'http://zdf.de/rels/content/video-page-teaser'
            result = self._get_content_from_teaser(content['http://zdf.de/rels/cmdm/broadcasts'], target)

        return result
        

    def get_shows_by_char(self, program, charakter):
        self.program = program
        result = []
        
        url = self._get_mapped_url('get_shows_by_char')
        content = self._load_json_page(url)
        
        brand = utils.get_safe(content, "['brand']", [])
        for key in brand:
            if self.list_az[charakter] == key["title"]:
                teaser = key.get("teaser", [])
                teaser_function = self._get_mapped_fct('get_shows_by_char')
                result = teaser_function(teaser)
                break
                
        return result


    def search(self, program, search_str):
        self.program = program
        self.search_str = search_str.replace(" ", "+")        
        url = f"{self.base_url}/search/documents?&q={self.search_str}&limit=20&profile=teaser&page=1"
        
        content = self._load_json_page(url)
             
        teaser = utils.get_safe(content, "['http://zdf.de/rels/search/results']", [])
        result = self._get_content_from_teaser(teaser)
        self._get_next(result, content)
            
        return result


    def get_content(self, program, url):
        self.program = program
        result = []
        content = self._load_json_page(url)
        
        if( "" != content ):
            if( content.get("module") ):
                result = self._get_content_from_module(content, True)
            
            elif content.get('http://zdf.de/rels/search/results'):
                videos = self._get_content_from_teaser(content['http://zdf.de/rels/search/results'])
                result.extend(videos)
                self._get_next(result, content)
        
        return result


    def get_items_from_content(self, program, url, args):
        self.program = program
        result = []
        content = self._load_json_page(url)
        
        if( "" != content ):
            if content.get('module'):
                mode = args.get('mode')
                
                if 'show_teaser' == mode:
                    # 3sat related code
                    result = self._get_content_from_module(content, True)
                elif 'get_from_teaser' == mode:
                    # 3sat related code
                    timestamp = content.get('modificationDate')
                    
                    if timestamp:
                        if args['timestamp'] != timestamp:
                            return result
                        
                    for idx, key in enumerate(content.get('module')):
                        if idx == args['ref']:
                            #if key.get('resultsWithVideo'):
                            #    break
                            if key.get('teaser'):
                                result.extend(self._get_content_from_teaser(key['teaser']))
                                
                            if key.get('filterRef'):
                                results_videos = key['filterRef']['resultsWithVideo']
                                videos = self._get_content_from_teaser(results_videos['http://zdf.de/rels/search/results'])
                                # add next...?
                                result.extend(videos)
                                
                            break
                else:
                    # zdf related code
                    for key in content["module"]:
                        tracking_title = key.get("trackingTitle")
                        if( args["ref"] == tracking_title ):
                            result = self._get_content_from_teaser_cellular(key["teaser"])
                            break
                
        return result
    
    
    def get_stream_data(self, program, url, quality="high"):
        self.program = program
        result = []
        record = utils.get_new_record(self.mediathek, self.program, url)
        
        content = self._load_json_page(url)
        
        if "" != content:
            video_content = content['mainVideoContent']['http://zdf.de/rels/target']
            availability = video_content.get('visibleTo', '')
            duration = video_content.get('duration', 0)
            layouts = utils.get_safe(content, "['teaserImageRef']['layouts']", {})
            target = video_content.get('http://zdf.de/rels/streams/ptmd-template')
            
            if target:
                record["type"] = "play_stream"
                record["mode"] = "end"
                record["name"] = content['teaserHeadline']
                record["plot"] = content['teasertext']
                record["availability"] = self._get_availability(availability)
                record["data"]['duration'] = duration
                record["data"]["image_url"] = self._get_image_url(layouts)
                
                url = f'{self.base_url}{target}'
                url = url.replace('{playerId}', self.player_id)
                content = self._load_json_page(url)
            
            else:
                content = ""
        
        if( "" != content ):
            record["data"]["target_url"] = self._get_stream_url(content["priorityList"], quality=quality)

        result.append(record)
        return result


    def _get_stream_url(self, data, quality='high', audio_track='german'):
        # filter streams
        audio_map = {
            'german': {'kind': 'main', 'language': 'deu'},      # german without audio description
            'german_ad': {'kind': 'ad', 'language': 'deu'},     # german with audio description
            'ot': {'kind': 'ot', 'language': 'any'}             # original audio version
        }
        
        #mime_types = ['application/x-mpegURL', 'video/mp4', 'video/webm']
        mime_types = ['video/webm', 'video/mp4']
        streams_filtered = []
        audio = audio_map[audio_track]

        for stream in data:
            for mime_type in mime_types:
                mime_type_stream = stream["formitaeten"][0]["mimeType"]
                
                if mime_type == mime_type_stream:
                    qualities = stream["formitaeten"][0]["qualities"]
                    
                    for stream_quality in qualities:
                        if 'auto' != stream_quality["quality"]:
                            for track in stream_quality["audio"]["tracks"]:
                                kind = track.get("class", audio["kind"])
                                language = track.get("language", audio["language"])
                                
                                if 'any' == audio["language"]:
                                    language = 'any'
    
                                if (audio["kind"] == kind) and (audio["language"] == language):
                                    record = get_stream_record(mime_type, stream_quality["quality"], track["uri"], kind, language)
                                    streams_filtered.append(record)
    
        # get stream according to quality request
        qlist_high = ['hd', 'veryhigh', 'high', 'low']
        qlist_medium = ['veryhigh', 'high', 'low']
        qlist_low = ['high', 'low']
        
        quality_map = {'high': qlist_high, 'medium': qlist_medium, 'low': qlist_low}
        target_quality_list = quality_map[quality]
        
        for quality in target_quality_list:
            for stream in streams_filtered:
                if stream["quality"] == quality:
                    return stream["stream_url"]
                
        return ''


    def _get_content_from_teaser(self, content, teaser_target='http://zdf.de/rels/target'):
        # 3sat related code, also used for zdf get_shows_by_date() function
        result = []
        
        for teaser in content:
            item = teaser[teaser_target]
            has_video = item.get('hasVideo', False)
            
            if ((True == has_video) and item.get('mainVideoContent')):
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                video_content = item['mainVideoContent']['http://zdf.de/rels/target']
                availability = utils.get_safe(teaser, "['visibleTo']")
                broadcasted = utils.get_safe(teaser, "['airtimeBegin']")
                layouts = utils.get_safe(item, "['teaserImageRef']['layouts']", {})
                
                title = teaser.get("title")
                name = teaser.get('subtitle')
                if None == name:
                    name = item['teaserHeadline']
                if title and not name.startswith(title):
                    name = f'{title} - {name}'
                        
                record["type"] = "stream_meta_data"
                record["mode"] = "play_stream"
                #old approach record["name"] = item['teaserHeadline'].replace('\t', '')
                record["name"] = name
                record["plot"] = item['teasertext']
                record["data"]["target_url"] = f"{self.base_url}{item['self']}"
                record["data"]["image_url"] = self._get_image_url(layouts)
                record["data"]['duration'] = video_content['duration']
                record["availability"] = self._get_availability(availability)
                record['aired'] = self._get_time(broadcasted)
                                    
                result.append(record)

            elif (True == has_video) and item.get('canonical'):
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                if teaser.get('teaserHeadline'):
                    name = teaser['teaserHeadline']
                else:
                    name = item['teaserHeadline']

                if 'page-index-teaser' in item['profile']:
                    record["type"] = "category"
                    record["mode"] = "get_content_from_categoy"
                    record["name"] = name
                    record["data"]["target_url"] = f"{self.base_url}{item['canonical']}"
                    record["data"]["args"]["mode"] = 'show_teaser'
                                        
                    result.append(record)
                
                else:
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = item['teaserHeadline']
                    record["data"]["target_url"] = f"{self.base_url}{item['canonical']}"
                                        
                    result.append(record)

        return result
    
    
    def _get_content_from_teaser_cellular(self, content, teaser_target='void'):
        # zdf related code
        result = []
        
        for key in content:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)

            video_content = utils.get_safe(key, "['target']['mainVideoContent']", None)
            video_type = utils.get_safe(key, "['target']['videoType']", 'unknown')
            has_video = utils.get_safe(key, "['target']['hasVideo']", False)
            target = utils.get_safe(key, "['target']['canonical']", '')
            
            if 'live' != video_type:
                if video_content:
                    program = utils.get_safe(key, "['broadcastInformation']['station']", self.program)
                    if self.program == program:
                        # filter "missed" result by current program
                        title = key.get("overline")
                        name = key["title"]
                        if title and not name.startswith(title):
                                name = f'{title} - {name}'

                        broadcasted = utils.get_safe(key, "['broadcastInformation']['effectiveAirtimeBegin']")
                        availability = utils.get_safe(key, "['dotty']['endDate']")
                        layouts = utils.get_safe(key, "['image']['layouts']", {})
                        
                        record["availability"] = self._get_availability(availability)
                        record["aired"] = self._get_time(broadcasted)
                        record["data"]["duration"] = utils.get_safe(key, "['target']['mainVideoContent']['http://zdf.de/rels/target']['duration']")
                        record["data"]["image_url"] = self._get_image_url(layouts)
                        record["data"]["target_url"] = f'{self.base_url}{target}?profile=teaser'
                        record["type"] = "stream_meta_data"
                        record["mode"] = "play_stream"
                        record["name"] = name
                        record["plot"] = key.get('text', '')
                    
                        result.append(record)
    
                elif has_video:
                    if 'ARD' != key.get('category'):
                        # filter ARD content, no idea how to get items later on
                        name = key["title"]
                        #name = key['target']['title']
                        
                        record["data"]["target_url"] = f'{self.base_url}{target}?profile=cellular-5'
                        record["type"] = "category"
                        record["mode"] = "get_content"
                        record["name"] = name
                    
                        result.append(record)
            
            elif (('live' == video_type) and self.show_live):
                if video_content:
                    title = key.get("title", "no info")
                     
                    record["data"]["target_url"] = f'{self.base_url}{target}?profile=teaser'
                    record["type"] = "stream_meta_data"
                    record["mode"] = "play_stream"
                    record["name"] = f'live - {title}'
                    result.append(record)
      
                elif (('live' == video_type) and has_video):
                    title = key.get("overline")
                    name = key["title"]
                    if title and not name.startswith(title):
                        name = f'{title} - {name}'
                     
                    record["data"]["target_url"] = f'{self.base_url}{target}?profile=cellular-5'
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = name
                
                    result.append(record)
            
        return result
    
    
    def _get_time(self, broadcasted):
        aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
        
        # broadcasted: 2024-07-24T05:40:00+02:00
        # availability: 2024-08-03T23:59:00.000+02:00
        timeformats = ["%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S.%f%z"]
        
        if( "" != broadcasted):
            for t_format in timeformats:
                try:
                    bcstd = time.strptime(broadcasted, t_format)
                    
                    '''
                    tm_hour = bcstd.tm_hour + self.delta_t
                    if( 24 <= tm_hour ):
                        tm_hour = tm_hour - 24
                    '''
                    tm_hour = bcstd.tm_hour
                    
                    aired["year"] = str(bcstd.tm_year)
                    aired["mon"] = str(bcstd.tm_mon).zfill(2)
                    aired["day"] = str(bcstd.tm_mday).zfill(2)
                    aired["hour"] = str(tm_hour).zfill(2)
                    aired["min"] = str(bcstd.tm_min).zfill(2)
                    
                    break
                except:
                    pass
            
        return aired
    
    
    def _get_availability(self, end_date):
        date_str = 'Keine Information'
        
        if '' != end_date:
            date = self._get_time(end_date)
            if '' != date['day']:
                date_str = f'Video verfügbar bis {date["day"]}.{date["mon"]}.{date["year"]}'

        return date_str


    def _get_image_url(self, data):
        #image_quality = ['1280x720', '768x432', '384x216']
        image_quality = ['768x432', '384x216']
        image_url = ""
        
        for resolution in image_quality:
            image_url = data.get(resolution, "")
            if "" != image_url:
                break

        return image_url


    def _get_categories_static(self):
        result = []
        self.source_url = ""

        for key in self.categories:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                        
            record["data"]["target_url"] = self.base_url + key["url"]
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = key["name"]
            
            result.append(record)
            
        return result


    def _get_categories_api(self):
        result = []
        
        url = self._get_mapped_url('_get_categories_api')
        content = self._load_json_page(url)
        
        if( "" != content ): 
            result = self._get_content_from_module(content)
        
        return result


    def _load_json_page(self, url):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")
        self.logger.debug("loading page {}".format(self.source_url))

        content = requests.get(self.source_url, allow_redirects=True, headers=self.header)
        result = content.text
        
        if( "<!DOCTYPE html>" in result[:40] ):
            jresult = ""
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""
        
        dump_to_file(jresult)
        return jresult

    
    def _get_next(self, result, content):
        # currently not used
        if content.get('next'):
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                    
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = 'Next page >>'
            record["data"]["target_url"] = f"{self.base_url}{content['next']}"
                                
            result.append(record)
    
    
    def _get_mapped_url(self, function, *args):
        return self._get_mapped(function, 'url', args)
    
    
    def _get_mapped_fct(self, function):
        return self._get_mapped(function, 'fct', ())
    
    
    def _get_mapped_keys(self, function):
        return self._get_mapped(function, 'keys', ())
        
        
    def _get_mapped(self, function, param, args):
        item_map = {
            'get_shows_by_char': {
                'target': self.mediathek,
                'zdf': {
                    'url': "{}/content/documents/zdf/sendungen-a-z?profile=cellular-5", 
                    'fct': self._get_content_from_teaser_cellular
                },
                '3sat': {
                    'url': "{}/content/documents/zdf/sendungen-a-z",
                    'fct': self._get_content_from_teaser
                },
            },
            '_get_categories_api': {
                'target': self.mediathek,
                'zdf': {
                    'url': "{}/content/documents/zdf?profile=cellular-5",
                },
                '3sat': {
                    'url': "{}/content/documents/zdf",
                },
            },
            'get_shows_by_date': {
                'target': self.program,
                'ZDF': {
                    'url': "{}/cmdm/zdf/epg/broadcasts?{}&limit=200&page=1&tvServices=ZDF&order=asc&profile=teaser",
                },
                'ZDFinfo': {
                    'url': "{}/cmdm/zdf/epg/broadcasts?{}&limit=200&page=1&tvServices=ZDFinfo&order=asc&profile=teaser",
                },
                'ZDFneo': {
                    'url': "{}/cmdm/zdf/epg/broadcasts?{}&limit=200&page=1&tvServices=ZDFneo&order=asc&profile=teaser",
                },
                '3sat': {
                    'url': "{}/cmdm/dreisat/epg/broadcasts?{}&limit=200&page=1&tvServices=3sat&order=asc&profile=teaser",
                }
            }
        }
        
        target = item_map[function]['target']
        result = item_map[function][target][param]
        
        if str == type(result):
            result = result.replace('{}', self.base_url, 1)
            for arg in args:
                result = result.replace('{}', arg, 1)
        
        return result



'''
https://api.3sat.de/cmdm/dreisat/epg/broadcasts?from=2024-08-01T05%3A30%3A00%2B02%3A00&to=2024-08-02T05%3A30%3A00%2B02%3A00&limit=200&page=1&tvServices=3sat&order=asc&profile=teaser
https://api.zdf.de/cmdm/zdf/epg/broadcasts?from=2024-08-01T05%3A30%3A00%2B02%3A00&to=2024-08-02T05%3A30%3A00%2B02%3A00&limit=200&page=1&tvServices=3sat&order=asc&profile=teaser
https://api.zdf.de/cmdm/zdf/epg/broadcasts?from=2024-08-01T05%3A30%3A00%2B02%3A00&to=2024-08-02T05%3A30%3A00%2B02%3A00&limit=200&page=1&tvServices=ZDF&order=asc&profile=teaser
https://api.zdf.de/cmdm/zdf/epg/broadcasts?from=2024-08-01T05%3A30%3A00%2B02%3A00&to=2024-08-02T05%3A30%3A00%2B02%3A00&limit=200&page=1&tvServices=ZDFinfo&order=asc&profile=teaser
https://api.zdf.de/cmdm/zdf/epg/broadcasts?from=2024-08-01T05%3A30%3A00%2B02%3A00&to=2024-08-02T05%3A30%3A00%2B02%3A00&limit=200&page=1&tvServices=ZDFneo&order=asc&profile=teaser



{self.base_url}/cmdm/{self.mediathek}/epg/broadcasts?from=2024-08-01T05%3A30%3A00%2B02%3A00&to=2024-08-02T05%3A30%3A00%2B02%3A00&limit=200&page=1&tvServices={self.program}&order=asc&profile=teaser
'''




