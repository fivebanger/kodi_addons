


def get_new_record(mediathek, program, source_url):
    data = {"mediathek": mediathek, "program": program, "target_url": "", "duration": "", "image_url": "", "args":{}}
    aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
    return {"type": "unknown", "mode": "unknown", "name": "unknown", "aired": aired, "subtitle_url": "", "plot": "", "availability": "", "source_url": source_url, "data": data}




def get_safe(dict_base, keys, default=""):
    result = default
    
    keys = keys.replace("[", "")
    keys = keys.split("]")
    
    try:
        for key in keys:
            if( "" != key ):
                if( key.startswith("\"") ):
                    key = key.replace("\"", "")
                elif( key.startswith("\'") ):
                    key = key.replace("\'", "")
                else:
                    key = int(key)
                dict_base = dict_base[key]
        result = dict_base
    except:
        pass
    
    return result

