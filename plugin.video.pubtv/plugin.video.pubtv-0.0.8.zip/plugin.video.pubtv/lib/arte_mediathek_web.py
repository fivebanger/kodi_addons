# -*- coding: utf-8 -*-

import time
import json


import urllib2
import StringIO
import gzip

import re
        
import utils
from mediathek import Mediathek




COUNTRY = "de"
base_url = "https://www.arte.tv/"
api_url = "https://api-cdn.arte.tv/api/emac/v3/" + COUNTRY + "/web/"

opa_token = "AOwImM4EGZ2gjYjRGZzEzYxMTNxMWOjJDO4gDO3UWN3UmN5IjNzAzMlRmMwEWM2I2NhFWN1kjYkJjZ1cjY1czN reraeB"
emac_token = "wYxYGNiBjNwQjZzIjMhRDOllDMwEjM2MDN3MjY4U2M1ATYkVWOkZTM5QzM4YzN2ITM0E2MxgDO1EjN5kjZmZWM reraeB"
player_token = "QMjZTOkF2NwQDZlFTOmJDOiFGN1QGM4EjY5QWOhBzN4YzM4YGMiRTNjZjZyImMjFWZlRWZ3Q2Y1MmYyYDZyYzM reraeB"

opa_header  = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:60.0) Gecko/20100101 Firefox/60.0', 'Authorization': opa_token[::-1]}
emac_header = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:60.0) Gecko/20100101 Firefox/60.0', 'Authorization': emac_token[::-1]}
player_header  = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; rv:60.0) Gecko/20100101 Firefox/60.0", "Authorization": player_token[::-1]}



list_az_mapping = {
                    "09": "0",
                    "a": "a",
                    "b": "b",
                    "c": "c",
                    "d": "d",
                    "e": "e",
                    "f": "f",
                    "g": "g",
                    "h": "h",
                    "i": "i",
                    "j": "j",
                    "k": "k",
                    "l": "l",
                    "m": "m",
                    "n": "n",
                    "o": "o",
                    "p": "p",
                    "q": "q",
                    "r": "r",
                    "s": "s",
                    "t": "t",
                    "u": "u",
                    "v": "v",
                    "w": "w",
                    "x": "x",
                    "y": "y",
                    "z": "z"
                 }



class ARTEMediathek(Mediathek):

    def __init__(self):
        self.img_res = 2
        self.delta_t = 1
        self.strm_quality = "high"
        self.mediathek = "arte"
        self.program = "arte_de"
        self.source_url = ""
        self.country = "de"
        self.page_limit = 20
        
        if( True == time.localtime().tm_isdst ):
            self.delta_t = 2


    def get_categories(self, program):
        self._select_country(program)
        url = "https://www.arte.tv/" + self.country + "/"
        return self.get_content(self.program, url)
    

    def get_shows_by_date(self, program, date):
        date = date.replace("-", "")
        url = "https://www.arte.tv/de/guide/" + date + "/"
        content = self._get_zones_from_url(url, None)
        return self._get_content_from_data(content["zones"][1])
        

    def get_shows_by_char(self, program, charakter):
        self._select_country(program)
        charakter = list_az_mapping[charakter]
        
        url = "https://api-cdn.arte.tv/api/emac/v3/de/web/data/MANUAL_TEASERS/?code=magazines_HOME&limit=100"
        content = self._load_json_page(url, emac_header)
        
        data = []
        for key in content["data"]:
            title = key["title"]
            if( charakter.isalpha() ):
                if( charakter == title[0].lower() ):
                    data.append(key)
            else:
                if( False == title[0].isalpha() ):
                    data.append(key)

        content = {"data": data}
        return self._get_content_from_data(content)


    def search(self, program, search_str):
        self.curr_prog = program
        url = "https://api-cdn.arte.tv/api/emac/v3/de/web/data/SEARCH_LISTING/?query=" + search_str + "&page=1&limit=20"
        return self.get_content(program, url)


    def get_content(self, program, url):
        self._select_country(program)
        
        result = []
        if( "/api/emac/" in url ):
            content = self._load_json_page(url, emac_header)
        elif( "/api/opa/" in url ):
            content = self._load_json_page(url, opa_header)
        else:
            content = self._get_zones_from_url(url, None)
        
        if( content ):
            if( content.get("data") ):
                result = self._get_content_from_data(content)
            elif( content.get("zones") ):
                result = self._get_content_from_zones(content)

        return result
    

    def get_items_from_content(self, program, url, args):
        self._select_country(program)
        
        zone = {"data": []}
        if( args.get("name") ):
            content = self._get_zones_from_url(url, None)
            
            for key in content["zones"]:
                if( args["name"] == key["title"] ):
                    zone = key
                    break
                    
        return self._get_content_from_data(zone)


    def get_stream_data(self, program, url, quality="high"):
        self._select_country(program)

        result = []
        
        content = self._load_json_page(url, player_header)
        content = content["data"]["attributes"]
        
        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                        
#         broadcasted = self._get_safe(content, ["document", "airtime"])
#         record["aired"] = self._get_aired(broadcasted)
        record["aired"] = ""
        
        record["type"] = "play_stream"
        record["mode"] = "end"
        record["name"] = self._get_safe(content, ["metadata", "title"])
        record["subtitle_url"] = ""
        record["plot"] = self._get_safe(content, ["metadata", "description"])
        
        
        availability = self._get_safe(content, ["rights", "end"])
        record["availability"] = self._encode_avail(availability) #self._get_safe(content, ["document", "availabilityInfo"], "no info")

        record["data"]["duration"] = content["metadata"]["duration"]["seconds"]
        record["data"]["image_url"] = content["metadata"]["images"][0]["url"]    #self._get_teasers_image(content["document"]["teaserBild"])

        # stream_urls = content["document"]["formitaeten"]
        
        quality_idx = {"low": 1, "medium": 2, "high": 3}
        quality_mapping = ["void", "low", "med", "veryhigh"]
        q = quality_idx[quality]
            
#         while(q):
#             try:
#                 for key in stream_urls:
#                     if( "application/x-mpegURL" == key["mimeType"] ):
#                         if( quality_mapping[q] == key["quality"] ):
#                             record["data"]["target_url"] = key["url"]
#                             q = 0
#                             break
#             except:
#                 pass
#             
#             if( 0 < q ):
#                 q = q - 1
        record["data"]["target_url"] = self._get_safe(content, ["streams", 0, "url"])
            
        result.append(record)
        
        return result


    def _get_content_from_data(self, content):
        result = []

        for key in content["data"]:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                            
            if( ("external" == key["kind"]["code"].lower()) or
                (self.source_url == key["url"]) or
                (None == key["programId"]) ):
                if( "external" == key["kind"]["code"].lower() ):
                    if( "?genres=" in key["url"] ):
                        record["type"] = "category"
                        record["mode"] = "get_content"
                        record["name"] = key["title"]
                        record["data"]["target_url"] = key["url"]
                        record["data"]["image_url"] = self._get_image_url(key)
                        
                        result.append(record)
            elif( False == key["kind"]["isCollection"] ):
                broadcasted =  self._get_safe(key, ["broadcastDates", 0])
                record["aired"] = self._get_aired(broadcasted)
                
                record["type"] = "stream_meta_data"
                record["mode"] = "play_stream"
                record["name"] = key["title"]
                record["subtitle_url"] = ""
                record["plot"] = self._get_safe(key, ["shortDescription"])
                availability = self._get_safe(key, ["availability", "end"])
                record["availability"] = self._encode_avail(availability)
                
                record["data"]["target_url"] = "https://api.arte.tv/api/player/v2/config/" + self.country + "/" + key["programId"]
                record["data"]["duration"] = key["duration"]
                record["data"]["image_url"] = self._get_image_url(key)
                
                result.append(record)
            else:
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = key["title"]
                #record["data"]["target_url"] = "https://api-cdn.arte.tv/api/emac/v3/de/web/data/COLLECTION_SUBCOLLECTION/?collectionId=" + key["programId"] + "&page=1&limit=20"
                record["data"]["target_url"] = key["url"]
                record["data"]["image_url"] = self._get_image_url(key)
                    
                result.append(record)
        
        next_page = self._get_safe(content, ["nextPage"], None)
        if( None != next_page ):
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = "Next page >>"
            record["data"]["target_url"] = content["nextPage"].replace("https://api-internal", "https://api-cdn")
            
            result.append(record)
            
        return result


    def _select_country(self, program):
        if( "arte_de" == program ):
            self.country = "de"
        elif( "arte_fr" == program ):
            self.country = "fr"
        self.program = program


    def _get_zones_from_url(self, url, header):
        content = self._load_json_page(url, header)
        currentCode = content["pages"]["currentCode"]
        return content["pages"]["list"][currentCode]


    def _get_content_from_zones(self, content):
        result = []
        
        for key in content["zones"]:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            data_result = self._get_content_from_data(key)
            link_url = self._get_safe(key, ["link", "url"], None)
            
            if( ("banner" == key["displayOptions"]["itemTemplate"]) or
                (0 == len(key["data"])) or
                (0 == len(data_result)) ):
                pass
            elif( (None == link_url) or
                  (self.source_url == key["link"]["url"]) or
                  ( "tab=" in key["link"]["deeplink"]) ):
                record["type"] = "category"
                record["mode"] = "get_content_from_categoy"
                record["name"] = key["title"]
                record["data"]["target_url"] = self.source_url
                record["data"]["args"]["id"] = key["id"]
                record["data"]["args"]["name"] = key["title"]
                
                result.append(record)
            else:       
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = key["title"]
                record["data"]["target_url"] = key["link"]["url"]
                
                result.append(record)
        
        if( 1 == len(result) ):
            result = self.get_items_from_content(self.program, result[0]["data"]["target_url"], result[0]["data"]["args"])
        
        return result


    def _get_aired(self, broadcasted):
        aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
        if( "" != broadcasted):
            bcstd = time.strptime(broadcasted,"%Y-%m-%dT%H:%M:%SZ")
            
            aired["year"] = str(bcstd.tm_year)
            aired["mon"] = str(bcstd.tm_mon).zfill(2)
            aired["day"] = str(bcstd.tm_mday).zfill(2)
            aired["hour"] = str(bcstd.tm_hour + self.delta_t).zfill(2)
            aired["min"] = str(bcstd.tm_min).zfill(2)
            
        return aired


    def _get_image_url(self, data):
        url = ""
        img_format = ["landscape", "square"]
        
        for key in img_format:
            url = self._get_safe(data, ["images", key, "resolutions", self.img_res, "url"])
            if( "" != url ):
                break
        
        return url
    
    
    def _encode_avail(self, avail):
        availability = "No Iinfo"
        if( 10 < len(avail) ):                         #"2020-02-19T06:16:00+00:00"
            #avail = time.strptime(avail,"%Y-%m-%dT%H:%M+%S:%S")
            availability = "Video verfügbar bis "
            availability = availability + str(avail[8:10]) + "."
            availability = availability + str(avail[5:7]) + "."
            availability = availability + str(avail[0:4])
        
        return availability
    
    
    def _encode_avail_(self, avail):
        availability = ""
        try:
            avail = time.strptime(avail,"%Y-%m-%dT%H:%M:%SZ")
            availability = "Video verfügbar bis "
            availability = availability + str(avail.tm_mday).zfill(2) + "."
            availability = availability + str(avail.tm_mon).zfill(2) + "."
            availability = availability + str(avail.tm_year)
        except:
            pass
        
        return availability
    
    
    def _encode_avail__(self, avail):
        availability = ""
        try:
            avail = avail[0:19]
            avail = time.strptime(avail,"%Y-%m-%dT%H:%M:%S")
            availability = "Video verfügbar bis "
            availability = availability + str(avail.tm_mday).zfill(2) + "."
            availability = availability + str(avail.tm_mon).zfill(2) + "."
            availability = availability + str(avail.tm_year)
        except:
            pass
        
        return availability
                    
                    
    def _get_safe(self, dict_base, keys, default=""):
        result = default
        try:
            for key in keys:
                dict_base = dict_base[key]
            result = dict_base
        except:
            pass
        return result


    def _load_json_page(self, url, headers=None):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")
        req = urllib2.Request(self.source_url)

        if( headers ):
            for key in headers:
                req.add_header(key, headers[key])
            req.has_header = lambda header_name: (True if header_name == 'Content-Length' else urllib2.Request.has_header(req, header_name))
        else:
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0')
            req.add_header('Accept-Encoding','gzip, deflate')
        
        response = urllib2.urlopen(req)

        compressed = response.info().get('Content-Encoding') == 'gzip'
        result = response.read()
        response.close()
        
        if( compressed ):
            buf = StringIO.StringIO(result)
            f = gzip.GzipFile(fileobj=buf)
            result = f.read()
        
        
        if( "<!doctype html>" in result[:40].lower() ):
            jresult = self._extract_json(result)
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""
        
        return jresult


    def _extract_json(self, html):
        try:
            content = re.compile("__INITIAL_STATE__ = ({.*});").search(html).group(1)
            content = json.loads(content)
        except:
            content = ""
        return content


    def _decode_deeplink(self, deeplink):
        # arte://collection/RC-014095?tab=RC-016723
        import urlparse

        #deeplink = "arte://collection/RC-014095?tab=RC-016723"
        #deeplink = "arte://collection/RC-014095"
        
        link = ""
        
        if( None == deeplink ):
            return link
        
        encoded = deeplink.split("?")
        args = {}
        
        if( 1 < len(encoded) ):
            args = urlparse.parse_qsl(encoded[1])
            args = dict(args)
        
        if( encoded[0].startswith("arte://collection/") ):
            collectionId = encoded[0].replace("arte://collection/", "")
            link = "https://api-cdn.arte.tv/api/emac/v3/de/web/data/COLLECTION_SUBCOLLECTION/?collectionId=" + collectionId + "&page=1&limit=10"
            
            
            if( args.get("tab") ):
                link = link + "&subCollectionId=" + args["tab"]
        
        return link


