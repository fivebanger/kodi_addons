# -*- coding: utf-8 -*-

import re
import time
import json
import requests

import utils
from mediathek import Mediathek


list_az_mapping = {
                    "09": "%23",
                    "a": "A",
                    "b": "B",
                    "c": "C",
                    "d": "D",
                    "e": "E",
                    "f": "F",
                    "g": "G",
                    "h": "H",
                    "i": "I",
                    "j": "J",
                    "k": "K",
                    "l": "L",
                    "m": "M",
                    "n": "N",
                    "o": "O",
                    "p": "P",
                    "q": "Q",
                    "r": "R",
                    "s": "S",
                    "t": "T",
                    "u": "U",
                    "v": "V",
                    "w": "W",
                    "x": "X",
                    "y": "Y",
                    "z": "Z"
                 }


class ARDMediathek(Mediathek):

    def __init__(self):
        self.img_res = "768"
        self.show_visible_title = True
        self.delta_t = 1
        self.mediathek = "ard"
        self.program = ""
        self.source_url = ""
        self.base_url = "https://api.ardmediathek.de/public-gateway"
        
        if( True == time.localtime().tm_isdst ):
            self.delta_t = 2

        
    def get_categories(self, program):
        self.program = program
        url = self._get_default_url(program)
        return self.get_content(program, url)


    def get_shows_by_date(self, program, date):
        self.program = program
        url = self._get_program_url(program, date)
        return self.get_content(program, url)


    def get_shows_by_char(self, program, charakter):
        self.program = program
        charakter = list_az_mapping[charakter]
        url = self._get_shows_az_url(program, charakter)
        return self.get_content(program, url)


    def search(self, program, search_str):
        self.program = program
        url = self._get_search_url(program, search_str, 0)
        return self.get_content(program, url)
        

    def get_content(self, program, url):
        self.program = program

        result = []
        content = self._load_json_page(url)
        
        if( "" != content ):  
            if( content.get("teasers") ):
                result = self._get_content_from_teasers(content)
                
            elif ( content.get("widgets") ):
                result = self._get_content_from_widgets(content)
                
            elif ( content.get("vodResults") ):
                    result = self._get_content_from_search_page(content)
                
            elif ( content.get("data") ):
                if ( content["data"].get("defaultPage") ):
                    result = self._get_content_from_default_page(content["data"]["defaultPage"]["widgets"])
                
                elif ( content["data"].get("programPage") ):
                    result = self._get_content_from_program_page(content["data"]["programPage"]["widgets"])
                    
        return result


    def get_stream_data(self, program, url, quality="high"):
        self.program = program
        result = []
        
        content = self._load_json_page(url)
        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
        
        aired = {}       
        try:
            bcstd = content["widgets"][0]["broadcastedOn"]
            bcstd = time.strptime(bcstd,"%Y-%m-%dT%H:%M:%SZ")
            
            aired["year"] = str(bcstd.tm_year)
            aired["mon"] = str(bcstd.tm_mon).zfill(2)
            aired["day"] = str(bcstd.tm_mday).zfill(2)
            aired["hour"] = str(bcstd.tm_hour + self.delta_t).zfill(2)
            aired["min"] = str(bcstd.tm_min).zfill(2)
            
            record["aired"] = aired
        except:
            pass
        
        record["type"] = "play_stream"
        record["mode"] = "end"
        record["name"] = content["widgets"][0]["title"].replace("\n", " ")
        record["subtitle_url"] = ""
        record["plot"] = content["widgets"][0]["synopsis"]
        record["availability"] = self._encode_avail(content)

        record["data"]["duration"] = content["widgets"][0]["mediaCollection"]["embedded"]["_duration"]
        record["data"]["image_url"] = content["widgets"][0]["image"]["src"].replace("{width}", self.img_res)
        
        stream_urls = self._get_safe(content, ["widgets", 0, "mediaCollection", "embedded", "_mediaArray", 0, "_mediaStreamArray"], [])

        quality_idx = {"low": 1, "medium": 2, "high": 3}
        quality_mapping = [0, 1, 2, 3]
        q = quality_idx[quality]

        while(q):
            try:
                for key in stream_urls:
                    if( quality_mapping[q] == key["_quality"] ):
                        if( isinstance(key["_stream"], list) ):
                            record["data"]["target_url"] = key["_stream"][0]
                        else:
                            record["data"]["target_url"] = key["_stream"]
                        q = 0
                        break
            except:
                pass
            
            if( 0 < q ):
                q = q - 1

        if( record["data"]["target_url"].startswith("//") ):
            record["data"]["target_url"] = "https:" + record["data"]["target_url"]
            
        result.append(record)
        return result

    
    def _get_content_from_teasers(self, content):
        teasers = content["teasers"]
        result = self._get_data_from_teasers(teasers)
        
        page_number = content["pagination"]["pageNumber"] + 1
        page_size = content["pagination"]["pageSize"]
        total = content["pagination"]["totalElements"]
        
        if( total > (page_number * page_size) ):
            url_parts = content["links"]["self"]["href"].split("?")
            url = url_parts[0] + "?pageNumber=" + str(page_number) + "&pageSize=" + str(page_size) + "&embedded=true"
            
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = "Next page >>"
            record["data"]["target_url"] = url
            
            result.append(record)
            
        return result

    
    def _get_data_from_teasers(self, teasers):
        result = []
        
        for teaser in teasers:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                    
            if( teaser.get("type") ):
                if( ("compilation" == teaser["type"]) or
                    ("show" == teaser["type"]) ):
                        
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = teaser["mediumTitle"].replace("\n", " ")
                    record["data"]["target_url"] = teaser["links"]["target"]["href"]
                    record["data"]["image_url"] = self._get_image_from_teaser(teaser["images"])
                    
                    result.append(record)
                    
                elif( "live" != teaser["type"] ):
                    number_of_clips = self._get_safe(teaser, ["numberOfClips"], 1)
                    
                    if( 0 < number_of_clips):
                        record["type"] = "stream_meta_data"
                        record["mode"] = "play_stream"
                        record["name"] = teaser["mediumTitle"].replace("\n", " ")
                        record["plot"] = self._get_safe(teaser, ["show", "longSynopsis"])
                        record["subtitle_url"] = ""
                        record["aired"] = self._get_aired(self._get_safe(teaser, ["broadcastedOn"]))
                        
                        record["data"]["target_url"] = teaser["links"]["target"]["href"]
                        record["data"]["duration"] = self._get_safe(teaser, ["duration"])
                        record["data"]["image_url"] = self._get_image_from_teaser(teaser["images"])
    
                        result.append(record)
        
        return result

    
    def _get_content_from_widgets(self, content):
        widgets = content["widgets"][0]
        
        result = self._get_data_from_teasers(widgets["teasers"])
        
        page_number = widgets["pagination"]["pageNumber"] + 1
        page_size = widgets["pagination"]["pageSize"]
        total = widgets["pagination"]["totalElements"]
        
        if( total > (page_number * page_size) ):
            url_parts = widgets["links"]["self"]["href"].split("?")
            url = url_parts[0] + "?pageNumber=" + str(page_number) + "&pageSize=" + str(page_size) + "&embedded=true"
            
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = "Next page >>"
            record["data"]["target_url"] = url
            
            result.append(record)
        
        return result


    def _get_content_from_default_page(self, content):
        result = []
        
        for key in content:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = key["title"].replace("\n", " ")
            record["data"]["target_url"] = key["links"]["self"]["href"]
            record["data"]["image_url"] = ""
            
            result.append(record)
            
        return result


    def _get_content_from_program_page(self, content):
        result = []
        
        if( 0 < len(content) ):
            result = self._get_data_from_teasers(content[0]["teasers"])
        
        return result
    
    
    def _get_content_from_search_page(self, content):
        result = []
        
        vod_page_number = content["vodPageNumber"] + 1
        vod_page_size = content["vodPageSize"]
        vod_total = content["vodTotal"]
        
        if( 1 >= vod_page_number ):
            data = self._get_data_from_teasers(content["showResults"])
            result.extend(data)
        
        data = self._get_data_from_teasers(content["vodResults"])
        result.extend(data)
        
        if( vod_total > (vod_page_number * vod_page_size) ):
            search_str = content["tracking"]["searchText"]
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)

            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = "Next page >>"
            record["data"]["target_url"] = self._get_search_url(self.program, search_str, vod_page_number)
            
            result.append(record)
        
        return result
    
    
    def _get_default_url(self, program):
        variables = "{\"client\":\"%s\",\"name\":\"home\",\"personalized\":false}" %(program)
        extentions = "{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"e3593c5c5c5095fdc0f68da926dd48234c2aec62a01a4d26eaaa8aded4c6de5e\"}}"
        url = "%s?variables=%s&extensions=%s" %(self.base_url, variables, extentions)
        return url
    
    
    def _get_program_url(self, program, date):
        variables = "{\"client\":\"%s\",\"startDate\":\"%s\"}" %(program, date)
        extentions = "{\"persistedQuery\":{\"version\":1,\"sha256Hash\":\"a62c5366a603ad60a46e4b0dd0f52b1855d401026016a639bbbfbe88e2118989\"}}"
        url = "%s?variables=%s&extensions=%s" %(self.base_url, variables, extentions)
        return url
    
    
    def _get_shows_az_url(self, program, charakter):
        page_number = 0
        page_size = 100
        url_base = "https://page.ardmediathek.de/page-gateway/compilations/%s/shows/" %(program)
        url = "%s?pageNumber=%d&pageSize=%d&embedded=true" %(charakter, page_number, page_size)
        return url_base + url
    
    
    def _get_search_url(self, program, search_str, page_number):
        url_base = "https://page.ardmediathek.de/page-gateway/pages/%s/search" %(program)
        url = "?devicetype=pc&embedded=true&searchString=%s&vodPageNumber=%d&showPageNumber=%d" %(search_str, page_number, page_number)
        return url_base + url
                    
                    
    def _get_safe(self, dict_base, keys, default=""):
        result = default
        try:
            for key in keys:
                dict_base = dict_base[key]
            result = dict_base
        except:
            pass
        return result
    
    
    def _encode_avail(self, content):
        availability = ""
        
        try:
            avail = content["widgets"][0]["availableTo"]
            avail = time.strptime(avail,"%Y-%m-%dT%H:%M:%SZ")
            availability = "Video verfügbar bis "
            availability = availability + str(avail.tm_mday).zfill(2) + "."
            availability = availability + str(avail.tm_mon).zfill(2) + "."
            availability = availability + str(avail.tm_year)
        except:
            pass
        
        return availability
    
    
    def _get_image_from_teaser(self, images):
        image_url = ""
        
        for key in images:
            if( key.startswith("aspect") ):
                image_url = images[key]["src"].replace("{width}", self.img_res)
                break
            
        return image_url


    def _get_aired(self, broadcasted):
        aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
        
        if( "" != broadcasted):
            bcstd = time.strptime(broadcasted,"%Y-%m-%dT%H:%M:%SZ")
            
            aired["year"] = str(bcstd.tm_year)
            aired["mon"] = str(bcstd.tm_mon).zfill(2)
            aired["day"] = str(bcstd.tm_mday).zfill(2)
            aired["hour"] = str(bcstd.tm_hour + self.delta_t).zfill(2)
            aired["min"] = str(bcstd.tm_min).zfill(2)
            
        return aired
    
    
    def _load_json_page(self, url):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")
        content = requests.get(self.source_url, allow_redirects=True);
        if(content.encoding is not None):
            result = content.text.encode(content.encoding)
        else:
            result = content.text

        if( "<!DOCTYPE html>" in result[:40] ):
            jresult = self._extract_json(result)
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""

        return jresult


    def _extract_json(self, html):
        try:
            content = re.compile("__APOLLO_STATE__ = ({.*});").search(html).group(1)
            content = json.loads(content)
        except:
            content = ""
        return content

    

