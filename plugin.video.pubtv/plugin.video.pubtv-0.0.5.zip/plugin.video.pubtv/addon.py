
import urlparse
import os
import sys
import xbmcaddon

addon_id = 'plugin.video.pubtv'
addon_cfg = xbmcaddon.Addon(addon_id)
addon_path = addon_cfg.getAddonInfo('path')

#Make lib available
sys.path.insert(0, os.path.join(addon_path, "lib"))

from dispatcher import Dispatcher


base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
addon_args = urlparse.parse_qsl(sys.argv[2][1:])
addon_args = dict(addon_args)


dispatcher = Dispatcher(base_url, addon_id, addon_handle, addon_args)
dispatcher.route()

