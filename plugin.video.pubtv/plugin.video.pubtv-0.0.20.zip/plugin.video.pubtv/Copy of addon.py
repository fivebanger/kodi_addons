

try:
    import urllib.parse as urlparse
    print("python 3")
except ImportError:
    import urlparse

argv = ['plugin://plugin.video.pubtv/', '19', '?data=%7b%22target_url%22%3a%20%22%22%2c%20%22mediathek%22%3a%20%22ard%22%2c%20%22args%22%3a%20%7b%7d%2c%20%22program%22%3a%20%22daserste%22%2c%20%22image_url%22%3a%20%22%22%2c%20%22duration%22%3a%20%22%22%7d&mode=list_categories', 'resume:false']
base_url = argv[0]

print( "here" )
print( argv )
print( argv[2][1:] )

addon_handle = int(argv[1])
addon_args = urlparse.parse_qsl(argv[2][1:])
addon_args = dict(addon_args)

print( addon_args )




query = {"test": "param"}
base_url = 'pluguns://pub_tv/' + '?' + urlparse.urlencode(query)

print(base_url)


