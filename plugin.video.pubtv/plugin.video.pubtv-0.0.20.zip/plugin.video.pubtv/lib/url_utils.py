
try:
    # Python 3
    import urllib.parse as urllib
except ImportError:
    # Python 2
    import urllib


class Urlbuild():
    
    def __init__(self, base_url):
        self.base_url = base_url

        
    def addon(self, query):
        return self.base_url + '?' + urllib.urlencode(query)


