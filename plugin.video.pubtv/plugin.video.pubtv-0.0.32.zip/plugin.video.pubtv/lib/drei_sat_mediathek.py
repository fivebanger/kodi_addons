
# -*- coding: utf-8 -*-

import time
import json
import requests

import utils
from mediathek import Mediathek



api_token = "528573d9434d560d7ccbdda720c337a7c9a81922 reraeB"
user_agent = "Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0"
header = {'Api-Auth': api_token[::-1], 'Accept-Encoding': 'gzip, deflate', 'User-Agent': user_agent}
#header = {'Api-Auth': api_token[::-1]}



categories = [
    {"name": "Startseite", "url": "https://api.3sat.de/content/documents/zdf"},
    {"name": "Themen", "url": "https://api.3sat.de/content/documents/zdf/themen"},
    {"name": "Kultur", "url": "https://api.3sat.de/content/documents/zdf/kultur"},
    {"name": "Wissen", "url": "https://api.3sat.de/content/documents/zdf/wissen"},
    {"name": "Gesellschaft", "url": "https://api.3sat.de/content/documents/zdf/gesellschaft"},
    {"name": "Film", "url": "https://api.3sat.de/content/documents/zdf/film"},
    {"name": "Dokumentation", "url": "https://api.3sat.de/content/documents/zdf/dokumentation"},
    {"name": "Kaberett", "url": "https://api.3sat.de/content/documents/zdf/kabarett"},
]



list_az_mapping = {
                    "09": "0-9",
                    "a": "A",
                    "b": "B",
                    "c": "C",
                    "d": "D",
                    "e": "E",
                    "f": "F",
                    "g": "G",
                    "h": "H",
                    "i": "I",
                    "j": "J",
                    "k": "K",
                    "l": "L",
                    "m": "M",
                    "n": "N",
                    "o": "O",
                    "p": "P",
                    "q": "Q",
                    "r": "R",
                    "s": "S",
                    "t": "T",
                    "u": "U",
                    "v": "V",
                    "w": "W",
                    "x": "X",
                    "y": "Y",
                    "z": "Z"
                 }



class DreiSatMediathek(Mediathek):

    def __init__(self):
        self.delta_t = 0
        self.mediathek = "3sat"
        self.program = "3sat"
        self.source_url = ""
        self.base_url = "https://api.3sat.de"
        
        if( True == time.localtime().tm_isdst ):
            self.delta_t = 1


    def get_categories(self, program):
        self.program = program
        return self._get_categories_static()
        
        
    def get_shows_by_date(self, program, date):
        result = []
        
        date_tmp = date.split('-')
        to = '{}-{}-{}'.format(date_tmp[0], date_tmp[1], str(int(date_tmp[2]) + 1).zfill(2))
        
        url = 'https://api.3sat.de/cmdm/dreisat/epg/broadcasts?from={from}T06%3A00%3A00%2B01%3A00&to={to}T06%3A00%3A00%2B01%3A00&limit=200&page=1&tvServices=3sat&order=asc&profile=teaser'
        url = url.replace('{from}', date)
        url = url.replace('{to}', to)
        content = self._load_json_page(url, header)
        
        if "" != content:
            for item in content['http://zdf.de/rels/cmdm/broadcasts']:
                teaser = item['http://zdf.de/rels/content/video-page-teaser']
                
                has_video = teaser.get('hasVideo')
                if True == has_video:
                    record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                    
                    video_cont = teaser['mainVideoContent']['http://zdf.de/rels/target']
                    
                    record["type"] = "stream_meta_data"
                    record["mode"] = "play_stream"
                    record["name"] = teaser['teaserHeadline'].replace('\t', '')
                    #record["name"] = item['title'].replace('\t', '')
                    record["plot"] = teaser['teasertext']
                    record["data"]["target_url"] = self._build_url(teaser['self'])
                    record["data"]["image_url"] = self._get_image(teaser['teaserImageRef'])
                    record["data"]['duration'] = video_cont['duration']
                    record["availability"] = self._get_availability(teaser)
                    
                    airtime = item['airtimeBegin'][:19]
                    
                    at_time = airtime.split('T')
                    at_time = at_time[1].split(':')
                    
                    #at_date = airtime.split('T')
                    #at_date = at_date[0].split('-')
                    #t_obj = time.strptime(airtime, '%Y-%m-%dT%H:%M:%S')
                    #hour = str(int(at_time[0]) + self.delta_t)
                    
                    aired = {"year": date_tmp[0], "mon": date_tmp[1], "day": date_tmp[2], "hour": at_time[0], "min": at_time[1]}
                    record['aired'] = aired
                                        
                    result.append(record)
                
        return result


    def get_shows_by_char(self, program, charakter):
        result = []
        url = 'https://api.3sat.de/content/documents/zdf/sendungen-a-z'
        content = self._load_json_page(url, header)
        
        if "" != content:
            for item in content['brand']:
                if list_az_mapping[charakter] == item['title']:
                    if item.get('teaser'):
                        result = (self._get_result_from_teaser(item['teaser']))
                    break
                
        return result


    def search(self, program, search_str):
        url = 'https://api.3sat.de/search/documents?&q={}&limit=200&profile=teaser&page=1'
        url = url.format(search_str)
        return self.get_content(program, url)


    def get_content(self, program, url):
        self.logger.debug('get_content')
        result = []
        content = self._load_json_page(url, header)
        
        if( "" != content ):
            if( content.get("module") ):
                result = self._get_content_from_module(content)
            
            elif content.get('http://zdf.de/rels/search/results'):
                videos = self._get_results_with_videos(content)
                result.extend(videos)
        
        return result


    def get_items_from_content(self, program, url, args):
        self.logger.debug('get_items_from_content')
        result = []
        content = self._load_json_page(url, header)
        
        if( "" != content ):
            if content.get('module'):
                mode = args.get('mode')
                
                if 'show_teaser' == mode:
                    result = self._get_content_from_module(content, True)
                elif 'get_from_teaser' == mode:
                    timestamp = content.get('modificationDate')
                    
                    if timestamp:
                        if args['timestamp'] != timestamp:
                            return result
                        
                    for idx, key in enumerate(content.get('module')):
                        if idx == args['ref']:
                            #if key.get('resultsWithVideo'):
                            #    break
                            if key.get('teaser'):
                                result.extend(self._get_result_from_teaser(key['teaser']))
                                
                            if key.get('filterRef'):
                                results_videos = key['filterRef']['resultsWithVideo']
                                videos = self._get_results_with_videos(results_videos)
                                result.extend(videos)
                                
                            break
                
        return result
    
    
    def get_stream_data(self, program, url, quality="high"):
        result = []
        record = utils.get_new_record(self.mediathek, self.program, url)
        
        content = self._load_json_page(url, header)
        
        if "" != content:
            video_content = content['mainVideoContent']['http://zdf.de/rels/target']
                                 
            record["type"] = "play_stream"
            record["mode"] = "end"
            record["name"] = content['teaserHeadline']
            record["plot"] = content['teasertext']
            record["availability"] = self._get_availability(video_content)
            record["data"]['duration'] = video_content['duration']
            record["data"]["image_url"] = self._get_image(content['teaserImageRef'])
            
            url = self._build_url(video_content['http://zdf.de/rels/streams/ptmd-template'])
            url = url.replace('{playerId}', 'ngplayer_2_3')
            content = self._load_json_page(url, header)
        
        if( "" != content ):
            quality_idx = {"low": 1, "medium": 2, "high": 4}
            quality_mapping = ["void", "low", "med", "high", "veryhigh"]
            mimetype_mapping = ["void", "video/mp4", "application/x-mpegURL"]
            m = 2
            
            while(m):
                for key in content['priorityList']:
                    item = key['formitaeten'][0]

                    if mimetype_mapping[m] == item['mimeType']:
                        q = quality_idx[quality]
                        streams = item['qualities']
                        
                        while(q):
                            for stream in streams:
                                if quality_mapping[q] == stream['quality']:
                                    record["data"]["target_url"] = stream['audio']['tracks'][0]['uri']
                                    m = 0
                                    q = 0
                                    break
                        
                            if( 0 < q ):
                                q = q - 1
    
                    if 0 == m:
                        break
                        
                if( 0 < m ):
                    m = m - 1

        result.append(record)
        return result
    
    '''
    def _get_result_video(self, content):
        result = []
        item = content['http://zdf.de/rels/target']
        
        if item.get('hasVideo') and item.get('mainVideoContent'):
            if True == item['hasVideo']:
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                video_cont = item['mainVideoContent']['http://zdf.de/rels/target']
                
                record["type"] = "stream_meta_data"
                record["mode"] = "play_stream"
                record["name"] = item['teaserHeadline'].replace('\t', '')
                record["plot"] = item['teasertext']
                record["data"]["target_url"] = self._build_url(item['self'])
                record["data"]["image_url"] = self._get_image(item['teaserImageRef'])
                record["data"]['duration'] = video_cont['duration']
                                    
                result.append(record)
                
        return result
    '''

    def _get_content_from_module(self, content, show_teaser=False):
        self.logger.debug('_get_content_from_module')
        result = []
        
        for idx, key in enumerate(content['module']):
            filter_ref = key.get('filterRef')
            
            if key.get('title'):
                if key.get('teaser'):
                    add = True
                    live = key.get('livestreamRef')
                    
                    if None != live:
                        add = False
                            
                    result_tmp = self._get_result_from_teaser(key['teaser'])
                    
                    if [] == result_tmp:
                        add = False
                    
                    if add:
                        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                    
                        record["type"] = "category"
                        record["mode"] = "get_content_from_categoy"
                        record["name"] = key['title']
                        record["data"]["target_url"] = self.source_url
                        record["data"]["args"]["ref"] = idx
                        record["data"]["args"]['timestamp'] = content['modificationDate']
                        record["data"]["args"]["mode"] = 'get_from_teaser'
                                            
                        result.append(record)
                
                elif filter_ref:
                    if 0 != filter_ref['resultsWithVideo']['totalResultsCount']:
                        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                        
                        #url = filter_ref['resultsWithVideo']['self']
                        url = filter_ref['resultsWithVideo']['first']
                        
                        record["type"] = "category"
                        record["mode"] = "get_content"
                        record["name"] = key['title']
                        record["data"]["target_url"] = self._build_url(url)
                                            
                        result.append(record)

            elif key.get('teaser') and show_teaser:
                result.extend(self._get_result_from_teaser(key['teaser']))
                
            elif filter_ref:
                results_videos = filter_ref['resultsWithVideo']
                videos = self._get_results_with_videos(results_videos)
                result.extend(videos)
                
        return result


    def _get_results_with_videos(self, content):
        self.logger.debug('_get_results_with_videos')
        result = []
                            
        for video in content['http://zdf.de/rels/search/results']:
            item = video['http://zdf.de/rels/target']
            
            if item.get('hasVideo') and item.get('mainVideoContent'):
                if True == item['hasVideo']:
                    record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                    
                    video_cont = item['mainVideoContent']['http://zdf.de/rels/target']
                    
                    record["type"] = "stream_meta_data"
                    record["mode"] = "play_stream"
                    record["name"] = item['teaserHeadline'].replace('\t', '')
                    record["plot"] = item['teasertext']
                    record["data"]["target_url"] = self._build_url(item['self'])
                    record["data"]["image_url"] = self._get_image(item['teaserImageRef'])
                    record["data"]['duration'] = video_cont['duration']
                                        
                    result.append(record)

        if content.get('next'):
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                    
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = 'Next page >>'
            record["data"]["target_url"] = self._build_url(content['next'])
                                
            result.append(record)
        
        return result


    def _get_result_from_teaser(self, content):
        self.logger.debug('_get_result_from_teaser')
        result = []
        
        for teaser in content:
            item = teaser['http://zdf.de/rels/target']
            has_video = item.get('hasVideo')
            
            if (True == has_video) and item.get('mainVideoContent'):                                    
                if True == item['hasVideo']:
                    record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                    
                    video_cont = item['mainVideoContent']['http://zdf.de/rels/target']
                    
                    record["type"] = "stream_meta_data"
                    record["mode"] = "play_stream"
                    record["name"] = item['teaserHeadline'].replace('\t', '')
                    record["plot"] = item['teasertext']
                    record["data"]["target_url"] = self._build_url(item['self'])
                    record["data"]["image_url"] = self._get_image(item['teaserImageRef'])
                    record["data"]['duration'] = video_cont['duration']
                                        
                    result.append(record)

            elif item.get('resultsWithVideo'):
                results_videos = item['resultsWithVideo']
                videos = self._get_results_with_videos(results_videos)
                result.extend(videos)

            elif (True == has_video) and item.get('canonical'):
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                if teaser.get('teaserHeadline'):
                    name = teaser['teaserHeadline']
                else:
                    name = item['teaserHeadline']

                if 'page-index-teaser' in item['profile']:
                    record["type"] = "category"
                    record["mode"] = "get_content_from_categoy"
                    record["name"] = name
                    record["data"]["target_url"] = self._build_url(item['canonical'])
                    record["data"]["args"]["mode"] = 'show_teaser'
                                        
                    result.append(record)
                
                else:
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = item['teaserHeadline']
                    record["data"]["target_url"] = self._build_url(item['canonical'])
                                        
                    result.append(record)
        
        return result


    def _get_availability(self, data):
        try:
            data = data['visibleTo']
            t_arr = data.split('.')
            t_obj = time.strptime(t_arr[0], '%Y-%m-%dT%H:%M:%S')
            t_str = time.strftime('%d.%m.%Y', t_obj)
            return 'Video verfügbar bis {}'.format(t_str)
        except:
            return 'Keine Information'
    
    
    def _build_url(self, url):
        return self.base_url + url
    
    
    def _get_image(self, data):
        image_url = ''
        layouts = data.get('layouts')
        img_res = ['768x432', '768xauto', '384xauto']
        
        if layouts:
            for res in img_res:
                if layouts.get(res):
                    image_url = layouts[res]
                    break
                    
        return image_url


    def _get_categories_static(self):
        result = []
        self.source_url = ""

        for key in categories:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                        
            record["data"]["target_url"] = key["url"]
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = key["name"]
            
            result.append(record)
            
        return result


    def _load_json_page(self, url, headers=None):
        self.logger.debug('load page from url: {}'.format(url))
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")

        if( None == headers ):
            headers = {'User-Agent': user_agent}
        
        content = requests.get(self.source_url, allow_redirects=True, headers=headers)
        #self.logger.debug('req-header: {}'.format(content.request.headers))
        #self.logger.debug('resp-header: {}'.format(content.headers))
        if(content.encoding is not None):
            result = content.text.encode(content.encoding)
        else:
            result = content.text

        result = result.decode("utf-8")
        if( "<!doctype html>" in result[:40].lower() ):
            jresult = self._extract_json(result)
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""
        
        return jresult


    def _extract_json(self, html):
        content = ""
        #try:
        #    content = re.compile("__INITIAL_STATE__ = ({.*});").search(html).group(1)
        #    content = json.loads(content)
        #except:
        #    content = ""
        return content



'''
// a-z
https://api.3sat.de/content/documents/zdf/sendungen-a-z

//show by date
https://api.3sat.de/cmdm/dreisat/epg/broadcasts?from=2022-11-15T06%3A00%3A00%2B01%3A00&to=2022-11-16T06%3A00%3A00%2B01%3A00&limit=200&page=1&tvServices=3sat&order=asc&profile=teaser

//categories
https://api.3sat.de/search/documents?q=%2A&contentTypes=category

//search
https://api.3sat.de/search/documents?&q=test
https://api.3sat.de/search/documents?&q=test&limit=200
https://api.3sat.de/search/documents?&q=test&limit=200&profile=teaser&page=1

https://api.3sat.de/content/documents/zdf/

themen
https://api.3sat.de/content/documents/zdf/themen

//rubriken
https://api.3sat.de/content/documents/zdf/kultur
https://api.3sat.de/content/documents/zdf/wissen
https://api.3sat.de/content/documents/zdf/gesellschaft
https://api.3sat.de/content/documents/zdf/film
https://api.3sat.de/content/documents/zdf/dokumentation
https://api.3sat.de/content/documents/zdf/kabarett

//startseite
https://api.3sat.de/content/documents/zdf/

https://api.3sat.de/content/documents/zdf/wissen/klimagipfel-100.json

https://api.3sat.de/search/documents?q=*&limit=10&attrs=&sender=&paths=%2Fzdf%2Fkultur%2Fkulturzeit%2C%2Fzdf%2Fwissen%2Fscobel%2C%2Fzdf%2Fwissen%2Fwissen-in-3sat%2C%2Fzdf%2Fdokumentation%2C%2Fzdf%2Fwissen%2Fzdf-history%2C%2Fzdf%2Fwissen%2Fwissenschaftsdoku%2C%2Fzdf%2Fgesellschaft%2C%2Fzdf%2Fwissen%2Fnano%2C%2Fzdf%2Fkultur%2Fbuchzeit%2C%2Fzdf%2Fwissen%2C%2Fzdf%2Fkultur%2Fkultur-in-3sat%2C%2Fzdf%2Fwissen%2Fwissenhoch2%2C%2Fzdf%2Fwissen%2Fwissen-aktuell%2C%2Fzdf%2Fkultur%2Fbuch%2C%2Fzdf%2Fwissen%2Fterra-x&editorialTags=Klimagipfel%23undefined%2Cklimagipfel%23undefined&exclEditorialTags=klimagipfel-madrid-106%23undefined&allEditorialTags=false&tagTypes=editorial&videoTypes=episode_clip%2Cclip_clip%2Cclip_episode%2Cepisode_episode&types=page-video&sortBy=date&sortOrder=desc&page=1
'''



