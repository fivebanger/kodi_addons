# -*- coding: utf-8 -*-

import time
import json
import requests

import utils
from mediathek import Mediathek



categories = [
    {"name": "Comedy/Show", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/comedy-und-show-100"},
    {"name": "Doku/Wissen", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/doku-wissen-104"},
    {"name": "Filme", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/filme-104"},
    {"name": "Geschichte", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/geschichte-108"},
    {"name": "heute-Nachrichten", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/heute-de-startseite-146"},
    {"name": "Kinder/ZDFtivi", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/zdftivi-fuer-kinder-100"},
    {"name": "Krimi", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/krimi-102"},
    {"name": "Kultur", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/kultur-110"},
    {"name": "Politik/Gesellschaft", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/politik-gesellschaft-102"},
    {"name": "Serien", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/serien-100"},
    {"name": "Sport", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/sport-106"},
    {"name": "Verbraucher", "url": "https://zdf-cdn.live.cellular.de/mediathekV2/document/verbraucher-102"},
]



list_az_mapping = {
                    "09": "0 - 9",
                    "a": "A",
                    "b": "B",
                    "c": "C",
                    "d": "D",
                    "e": "E",
                    "f": "F",
                    "g": "G",
                    "h": "H",
                    "i": "I",
                    "j": "J",
                    "k": "K",
                    "l": "L",
                    "m": "M",
                    "n": "N",
                    "o": "O",
                    "p": "P",
                    "q": "Q",
                    "r": "R",
                    "s": "S",
                    "t": "T",
                    "u": "U",
                    "v": "V",
                    "w": "W",
                    "x": "X",
                    "y": "Y",
                    "z": "Z"
                 }



class ZDFMediathek(Mediathek):

    def __init__(self):
        self.img_res = "1080"
        self.delta_t = 0
        self.strm_quality = "high"
        self.mediathek = "zdf"
        self.program = ""
        self.source_url = ""
        self.curr_char = ""


    def get_categories(self, program):
        self.program = program
        return self._get_categories_static()
        #return self._get_categories_api()
    

    def get_shows_by_date(self, program, date):
        self.program = program
        #url = "https://zdf-cdn.live.cellular.de/mediathekV2/live-tv/" + date
        url = "https://zdf-cdn.live.cellular.de/mediathekV2/broadcast-missed/" + date
        return self.get_content(program, url)
        

    def get_shows_by_char(self, program, charakter):
        self.program = program
        self.curr_char = list_az_mapping[charakter]
        url = "https://zdf-cdn.live.cellular.de/mediathekV2/brands-alphabetical"
        return self.get_content(program, url)


    def search(self, program, search_str):
        self.curr_prog = program
        search_str = search_str.replace(" ", "+")
        url = "https://zdf-cdn.live.cellular.de/mediathekV2/search?q=" + search_str
        return self.get_content(program, url)


    def get_content(self, program, url):
        self.program = program
        
        result = []
        content = self._load_json_page(url)
        
        if( "" != content ):
            if( content.get("results") ):
                result = self._get_content_from_results(content)
            
            elif( content.get("epgCluster") ):
                result = self._get_content_from_epg_cluster(content)
                
            elif( content.get("broadcastCluster") ):
                result = self._get_content_from_broadcast_cluster(content)
            
            elif ( content.get("document") ):
                if( ("category" == content["document"]["type"]) or
                    ("brand" == content["document"]["type"]) ):
                    result = self._get_content_from_cluster(content)
                
                elif( "topic" == content["document"]["type"] ):
                    for key in content["cluster"]:
                        data = self._get_content_from_data(key["teaser"])
                        result.extend(data)
                
                elif( "brandsAlphabetical" == content["document"]["type"] ):
                    result = self._get_content_from_alphabetical(content)
        
        return result
    

    def get_items_from_content(self, program, url, args):
        self.program = program
        
        result = []
        content = self._load_json_page(url)
        
        if( "" != content ):
#             cluster_idx = args["cluster_idx"]
#             result = self._get_content_from_data(content["cluster"][cluster_idx]["teaser"])
            for key in content["cluster"]:
                if( args["ref"] == key["name"] ):
                    result = self._get_content_from_data(key["teaser"])
                    break
        
        return result


    def get_stream_data(self, program, url, quality="high"):
        self.program = program
        result = []
        
        content = self._load_json_page(url)
        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
        
        if( "" != content ):          
            broadcasted = utils.get_safe(content, '["document"]["airtime"]')
            record["aired"] = self._get_aired(broadcasted)
            
            headline = ['', '']
            headline[1] = utils.get_safe(content, '["document"]["headline"]')
            headline = headline[1].split(' | ', 1) if ' | ' in headline[1] else headline
            name = utils.get_safe(content, '["document"]["titel"]')
            name = u'{} - {}'.format(headline[1], name)
            
            record["type"] = "play_stream"
            record["mode"] = "end"
            record["name"] = name
            record["subtitle_url"] = ""
            record["plot"] = utils.get_safe(content, '["document"]["beschreibung"]')
            record["availability"] = utils.get_safe(content, '["document"]["availabilityInfo"]', "Keine Information")
    
            record["data"]["duration"] = utils.get_safe(content, '["document"]["length"]')
            record["data"]["image_url"] = self._get_image_url(utils.get_safe(content, '["document"]'))
    
            stream_urls = utils.get_safe(content, '["document"]["formitaeten"]', [])
            
            quality_idx = {"low": 1, "medium": 2, "high": 4}
            quality_mapping = ["void", "low", "med", "high", "veryhigh"]
            q = quality_idx[quality]
                
            while(q):
                for key in stream_urls:
                    
                    key_mime_type = utils.get_safe(key, '["mimeType"]', "")
                    key_quality = utils.get_safe(key, '["quality"]', "")
                    key_url = utils.get_safe(key, '["url"]', "")
                    
                    if( ("video/mp4" == key_mime_type) or
                        ("application/x-mpegURL" == key_mime_type) ):
                        if( quality_mapping[q] == key_quality ):
                            record["data"]["target_url"] = key_url
                            q = 0
                            break
                        
                if( 0 < q ):
                    q = q - 1
                
        result.append(record)
        return result


    def _get_categories_api(self):
        result = []
        
        url = "https://zdf-cdn.live.cellular.de/mediathekV2/categories"
        content = self._load_json_page(url)
        if( "" != content ): 
            result = self._get_content_from_cluster(content)
        
        return result
    

    def _get_categories_static(self):
        result = []
        self.source_url = ""

        for key in categories:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                        
            record["data"]["target_url"] = key["url"]
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = key["name"]
            
            result.append(record)
            
        return result


    def _get_content_from_alphabetical(self, content):
        result = []
        
        for key in content["cluster"]:
            if( self.curr_char == key["name"]):
                result = self._get_content_from_data(key["teaser"])
                break
                
        return result
        

    def _get_content_from_epg_cluster(self, content):
        result = []
        for key in content["epgCluster"]:
            if( self.program == key["channel"] ):
                result = self._get_content_from_data(key["teaser"])
                break
        return result
        

    def _get_content_from_broadcast_cluster(self, content):
        data = []

        for key in content["broadcastCluster"]:
            for item in key["teaser"]:
                if( self.program == item["channel"] ):
                    data.append(item)

        result = self._get_content_from_data(data)

        return result
    
    
    def _get_content_from_results(self, content):
        result = self._get_content_from_data(content["results"])
        
        next_page = utils.get_safe(content, '["nextPageUrl"]')
        if( "" != next_page ):
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = "Next page >>"
            record["data"]["target_url"] = next_page
            
            result.append(record)
            
        return result
    
    
    def _get_content_from_data(self, data):
        result = []

        for key in data:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            if( "video" == key["type"] ):
                if( ("" != key["url"]) and (True == key["hasVideo"]) ):
                    broadcasted = utils.get_safe(key, '["airtime"]')
                    record["aired"] = self._get_aired(broadcasted)
                    
                    title = key["headline"]
                    name = key["titel"]
                    name = u'{} - {}'.format(title, name) if "" != title else name
                    
                    record["type"] = "stream_meta_data"
                    record["mode"] = "play_stream"
                    record["name"] = name
                    record["subtitle_url"] = ""
                    record["plot"] = utils.get_safe(key, '["beschreibung"]')
                    record["availability"] = utils.get_safe(key, '["timetolive"]', "Keine Information")
                    
                    record["data"]["target_url"] = key["url"]
                    try:
                        record["data"]["duration"] = key["length"]
                    except:
                        try:
                            length = key["infoline"]["title"].replace(" min", "")
                            length = int(length) * 60
                            record["data"]["duration"] = length
                        except:
                            pass
                    record["data"]["image_url"] = self._get_image_url(key)
                    
                    result.append(record)
                                   
            elif( ("brand" == key["type"]) or
                  ("topic" == key["type"]) or
                  ("category" == key["type"]) ):
                if( self.source_url != key["url"] ):
#                 if( True == key["hasVideo"] ):
#                     
#                     record["type"] = "category"
#                     record["mode"] = "get_content"
#                     record["name"] = key["titel"]
#                     record["data"]["target_url"] = key["url"]
#                         
#                     result.append(record)
                    record["type"] = "category"
                    record["mode"] = "get_content"
                    record["name"] = key["titel"]
                    record["data"]["target_url"] = key["url"]
                    record["data"]["image_url"] = self._get_image_url(key)
                        
                    result.append(record)
        
        return result
        
        
    def _get_content_from_cluster(self, content):
        result = []

        for idx, key in enumerate(content["cluster"]):
            name = key["name"]
            
            if( ("" != name) and
                ([] != key["teaser"]) ):
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
                record["type"] = "category"
                record["mode"] = "get_content_from_categoy"
                record["name"] = name
                record["data"]["target_url"] = self.source_url
                record["data"]["args"]["cluster_idx"] = idx
                record["data"]["args"]["ref"] = name
                                    
                result.append(record)
            else:
                data = self._get_content_from_data(key["teaser"])
                result.extend(data)
        
        return result


    def _get_image_url(self, data):
        # image_quality = ["0", "384", "768", "1280"]
        image_quality = ["0", "384", "768"]
        image_url = ""
        
        q = len(image_quality) - 1
        while(q):
            try:
                image_url = data["teaserBild"][image_quality[q]]["url"]
                break
            except:
                q = q - 1
            
        return image_url
    
    
    def _get_aired(self, broadcasted):
        aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
        
        if( "" != broadcasted):
            bcstd = time.strptime(broadcasted,"%d.%m.%Y %H:%M")
            
            tm_hour = bcstd.tm_hour + self.delta_t
            if( 24 <= tm_hour ):
                tm_hour = tm_hour - 24
            
            aired["year"] = str(bcstd.tm_year)
            aired["mon"] = str(bcstd.tm_mon).zfill(2)
            aired["day"] = str(bcstd.tm_mday).zfill(2)
            aired["hour"] = str(tm_hour).zfill(2)
            aired["min"] = str(bcstd.tm_min).zfill(2)
            
        return aired


    def _load_json_page(self, url):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")
        content = requests.get(self.source_url, allow_redirects=True)
        if(content.encoding is not None):
            result = content.text.encode(content.encoding)
        else:
            result = content.text

        result = result.decode("utf-8")
        if( "<!DOCTYPE html>" in result[:40] ):
            jresult = ""
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""

        return jresult

    
    
    
