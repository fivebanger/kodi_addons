
import datetime

from welt_mediathek import WELTMediathek




available_prog = [
                    {'name': 'WELT', 'program': 'welt', 'mediathek': 'welt'}
                ]



menu_entries = [
    {"name": "Categories", "mode": "list_categories"},
    {"name": "Shows by date", "mode": "list_dates"},
    {"name": "Shows A-Z", "mode": "list_az"},
    {"name": "Search", "mode": "search"}
]


az_entries = [
    {"name": "Shows 0-9", "charakter": "09", "id": 0},
    {"name": "Shows A", "charakter": "a", "id": 1},
    {"name": "Shows B", "charakter": "b", "id": 2},
    {"name": "Shows C", "charakter": "c", "id": 3},
    {"name": "Shows D", "charakter": "d", "id": 4},
    {"name": "Shows E", "charakter": "e", "id": 5},
    {"name": "Shows F", "charakter": "f", "id": 6},
    {"name": "Shows G", "charakter": "g", "id": 7},
    {"name": "Shows H", "charakter": "h", "id": 8},
    {"name": "Shows I", "charakter": "i", "id": 9},
    {"name": "Shows J", "charakter": "j", "id": 10},
    {"name": "Shows K", "charakter": "k", "id": 11},
    {"name": "Shows L", "charakter": "l", "id": 12},
    {"name": "Shows M", "charakter": "m", "id": 13},
    {"name": "Shows N", "charakter": "n", "id": 14},
    {"name": "Shows O", "charakter": "o", "id": 15},
    {"name": "Shows P", "charakter": "p", "id": 16},
    {"name": "Shows Q", "charakter": "q", "id": 17},
    {"name": "Shows R", "charakter": "r", "id": 18},
    {"name": "Shows S", "charakter": "s", "id": 19},
    {"name": "Shows T", "charakter": "t", "id": 20},
    {"name": "Shows U", "charakter": "u", "id": 21},
    {"name": "Shows V", "charakter": "v", "id": 22},
    {"name": "Shows W", "charakter": "w", "id": 23},
    {"name": "Shows X", "charakter": "x", "id": 24},
    {"name": "Shows Y", "charakter": "y", "id": 25},
    {"name": "Shows Z", "charakter": "z", "id": 26},
]

mediatheks = {"welt": WELTMediathek()}

class MediathekHandler(object):
    
    def __init__(self):
        #self.mediathek = mediatheks[mediathek]
        self.mediathek = None
        self.program = ""
        self.source_url = ""
        self.search_str = ""
        self.quality = "high"


    def set_search_string(self, search_str):
        self.search_str = search_str


    def set_stream_quality(self, quality):
        self.quality = quality


    def handle_mode(self, mode, data):
        result = []
        
        if( "get_programs" == mode ):
            result = self.get_programs()
        elif( "get_menu" == mode ):
            result = self.get_menu(data)
        elif( "list_categories" == mode ):
            result = self.list_categories(data)
        elif( "list_dates" == mode ):
            result = self.list_dates(data)
        elif( "get_shows_by_date" == mode ):
            result = self.get_shows_by_date(data)
        elif( "list_az" == mode ):
            result = self.list_az(data)
        elif( "get_shows_by_char" == mode ):
            result = self.get_shows_by_char(data)
        elif( "search" == mode ):
            result = self.search(data)
        elif( "get_content" == mode ):
            result = self.get_content(data)
        elif( "get_content_from_categoy" == mode ):
            result = self.get_items_from_content(data)
        elif( "play_stream" == mode ):
            result = self.play_stream(data)
        else:
            pass
        
        return result


    def get_programs(self):
        result = []
        
        for program in available_prog:
            record = self.get_new_record()
            
            record["type"] = "category"
            record["mode"] = "get_menu"
            record["name"] = program["name"]
            record["data"]["mediathek"] = program["mediathek"]
            record["data"]["program"] = program["program"]
            
            result.append(record)
            
        return result


    def get_menu(self, data):
        result = []
        
        self.mediathek = data["mediathek"]
        self.program = data["program"]
        
        for menu in menu_entries:
            record = self.get_new_record()
            
            record["type"] = "category"
            record["mode"] = menu["mode"]
            record["name"] = menu["name"]
            
            result.append(record)
            
        return result


    def list_categories(self, data):
        m = mediatheks[data["mediathek"]]
        return m.get_categories(data["program"])


    def list_dates(self, data):
        result = []
        
        self.mediathek = data["mediathek"]
        self.program = data["program"]
        
        dates = self._generate_dates(0, 7)

        for date in dates:
            record = self.get_new_record()
            
            record["type"] = "category"
            record["mode"] = "get_shows_by_date"
            record["name"] = "(%s) %s" %(date["date_sort"], date["day_name"])
            record["data"]["args"] = {"date": date["date"]}
            
            result.append(record)
        
        return result


    def get_shows_by_date(self, data):
        m = mediatheks[data["mediathek"]]
        return m.get_shows_by_date(data["program"], data["args"]["date"])


    def list_az(self, data):
        result = []
        
        self.mediathek = data["mediathek"]
        self.program = data["program"]

        for item in az_entries:
            record = self.get_new_record()
            
            record["type"] = "category"
            record["mode"] = "get_shows_by_char"
            record["name"] = item["name"]
            record["data"]["args"] = {"charakter": item["charakter"]}
            
            result.append(record)
        
        return result


    def get_shows_by_char(self, data):
        m = mediatheks[data["mediathek"]]
        return m.get_shows_by_char(data["program"], data["args"]["charakter"])


    def get_content(self, data):
        m = mediatheks[data["mediathek"]]
        return m.get_content(data["program"], data["target_url"])


    def get_items_from_content(self, data):
        m = mediatheks[data["mediathek"]]
        return m.get_items_from_content(data["program"], data["target_url"], data["args"])
    
    
    def play_stream(self, data):
        m = mediatheks[data["mediathek"]]
        return m.get_stream_data(data["program"], data["target_url"], data["args"], self.quality)


    def search(self, data):
        m = mediatheks[data["mediathek"]]
        return m.search(data["program"], self.search_str)


    def _generate_dates(self, start=0, stop=7):
        dates = []
        week  = [ 'Montag', 
                  'Dienstag', 
                  'Mittwoch', 
                  'Donnerstag',  
                  'Freitag', 
                  'Samstag',
                  'Sonntag' ]
        
        for i in range(start, stop):
            result = {}
            d = datetime
            
            date = d.datetime.now() - d.timedelta(days=i)
            result["date"] = date.strftime("%Y-%m-%d")
            result["date_sort"] = date.strftime("%d.%m.")
            result["distance"] = i
            result["day_name"] = week[date.weekday()]
            dates.append(result)
            
        return dates


    def get_program_name(self, program):
        name = ""
        for key in available_prog:
            if( program == key["program"] ):
                name = key["name"]
        return name
    

    def get_new_record(self, mediathek="", program="", source_url=""):
        data = {"mediathek": self.mediathek, "program": self.program, "target_url": "", "duration": "", "image_url": "", "args":{}}
        aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
        return {"type": "unknown", "mode": "unknown", "name": "unknown", "aired": aired, "subtitle_url": "", "plot": "", "availability": "", "source_url": self.source_url, "data": data}


