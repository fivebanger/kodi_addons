# -*- coding: utf-8 -*-

import json
import re
import urllib2
import StringIO
import gzip

import utils
from mediathek import Mediathek



categories = [
    {"name": "Dokumentation", "id": "docu", "url": "https://www.welt.de/mediathek/dokumentation/"},
    {"name": "Reportage", "id": "report", "url": "https://www.welt.de/mediathek/reportage/"},
    {"name": "Magazin", "id": "mag", "url": "https://www.welt.de/mediathek/magazin/"}
]



list_az_mapping = {
                    "09": "0 - 9",
                    "a": "A",
                    "b": "B",
                    "c": "C",
                    "d": "D",
                    "e": "E",
                    "f": "F",
                    "g": "G",
                    "h": "H",
                    "i": "I",
                    "j": "J",
                    "k": "K",
                    "l": "L",
                    "m": "M",
                    "n": "N",
                    "o": "O",
                    "p": "P",
                    "q": "Q",
                    "r": "R",
                    "s": "S",
                    "t": "T",
                    "u": "U",
                    "v": "V",
                    "w": "W",
                    "x": "X",
                    "y": "Y",
                    "z": "Z"
                 }



class WELTMediathek(Mediathek):

    def __init__(self):
        self.img_res_1 = "ci16x9-w880"
        self.img_res_2 = "ci16x9-w600"
        self.delta_t = 0
        self.strm_quality = "high"
        self.mediathek = "welt"
        self.program = "welt"
        self.source_url = ""
        self.curr_char = ""


    def get_categories(self, program):
        result = []
        self.source_url = ""

        for key in categories:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                        
            record["type"] = "category"
            record["mode"] = "get_content_from_categoy"
            record["name"] = key["name"]
            
            record["data"]["target_url"] = key["url"]
            record["data"]["args"]["id"] = key["id"]
            
            result.append(record)
            
        return result
    

    def get_items_from_content(self, program, url, args):
        self.program = program
        
        result = []
        record_items = []
        content = self._load_json_page(url)
        
        result.extend( self._get_sub_categories(content) )
        
        data_content = content.split("data-content=")
        for item in data_content:
            if( (item.startswith('"Teaser.Link"')) or
                (item.startswith('"Stage.Teaser"')) or
                (item.startswith('"Stage"')) ):
                if( "/sendung" in item ):
                    record_items.append(item)

        for item in record_items:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
        
            target_url = re.findall(r'("/mediathek/\S+)', item)
            target_url = "https://www.welt.de" + target_url[0].replace('"', '')
            
            title = re.findall(r'title="(.*?)"', item)
            title = title[0]
            
            image_urls = []
            try:
                image_urls = re.findall(r'("https://www.welt.de/img/mediathek/\S+)', item)
            except:
                image_urls = re.findall(r'("https://www.welt.de/img/incoming/\S+)', item)
            
            image_url = ""
            for item in image_urls:
                item = item.replace('"', '')
                #if( self.img_res in item ):
                if( (self.img_res_2 in item) or
                    (self.img_res_1 in item) ):
                    image_url = item
                    break

            if( ("" == image_url) and
                ([] != image_urls) ):
                image_url = image_urls[0].replace('"', '')
            
            try:
                duration = re.search(r'VideoDuration">(.*)Min', item).group(1)
                duration = duration.replace(" ", "")
                duration = ""
            except:
                duration = ""
            
            record["type"] = "stream_meta_data"
            record["mode"] = "play_stream"
            record["name"] = title
            record["aired"] = ""
            record["subtitle_url"] = ""
            record["plot"] = ""
            record["availability"] = "no info"
            
            record["data"]["target_url"] = target_url
            record["data"]["duration"] = duration
            record["data"]["image_url"] = image_url
            
            record["data"]["args"]["image_url"] = image_url
            record["data"]["args"]["name"] = title
            
            result.append(record)
        
        return result
    
    
    def _get_sub_categories(self, content):
        result = []
        stage_headers = []
        
        data_content = content.split("data-content=")
        for item in data_content:
            if( (item.startswith('"Stage"')) ):
                if( "StageHeader.HeadlineLink" in item ):
                    stage_headers.append(item)

        for item in stage_headers:
            target_url = re.findall(r'("/mediathek/\S+)', item)
            target_url = "https://www.welt.de" + target_url[0].replace('"', '')
            
            title = re.search(r'"StageHeader.Headline">(.*)</h2>', item)
            title = title.group(1).strip()
            title = title.replace("&amp;", "&")
            
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                        
            record["type"] = "category"
            record["mode"] = "get_content_from_categoy"
            record["name"] = title
            
            record["data"]["target_url"] = target_url
            record["data"]["args"]["id"] = "void"
            
            result.append(record)
        
        return result


    def get_stream_data(self, program, url, args, quality="high"):
        self.program = program
        result = []
        stream_urls = []

        content = self._load_json_page(url)
        record = utils.get_new_record(self.mediathek, self.program, self.source_url)
        
        urls = re.findall(r'"src":(.*?)extension', content)
        for item in urls:
            if( item.startswith("\"https://weltn24lfthumb-a") ):
                target_url = item
                target_url = target_url.replace('"', '')
                target_url = target_url.replace(',', '')
                
                stream_urls.append(target_url)

         
        record["type"] = "play_stream"
        record["mode"] = "end"
        record["name"] = args["name"]
        record["subtitle_url"] = ""
        record["plot"] = ""
        record["availability"] = ""
        record["aired"] = ""
        
        if( [] != stream_urls ):
            quality_mapping = {"low": 2, "medium": 1, "high": 0}
            quality = quality_mapping[quality]
            
            record["data"]["duration"] = ""
            record["data"]["image_url"] = args["image_url"]
            record["data"]["target_url"] = stream_urls[quality]
            record["data"]["args"] = args
                
        result.append(record)
        return result




    def _load_json_page(self, url, headers=None):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")
        req = urllib2.Request(self.source_url)

        if( headers ):
            for key in headers:
                req.add_header(key, headers[key])
            req.has_header = lambda header_name: (True if header_name == 'Content-Length' else urllib2.Request.has_header(req, header_name))
        else:
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0')
            req.add_header('Accept-Encoding','gzip, deflate')
        
        response = urllib2.urlopen(req)

        compressed = response.info().get('Content-Encoding') == 'gzip'
        result = response.read()
        response.close()
        
        if( compressed ):
            buf = StringIO.StringIO(result)
            f = gzip.GzipFile(fileobj=buf)
            result = f.read()
        
        
        if( "<!doctype html>" in result[:40].lower() ):
            #jresult = self._extract_json(result)
            jresult = result
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""
        
        return jresult


    def _extract_json(self, html):
        try:
            content = re.compile("__INITIAL_STATE__ = ({.*});").search(html).group(1)
            content = json.loads(content)
        except:
            content = ""
        return content

    
    
    