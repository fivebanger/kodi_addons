




def get_new_record(mediathek, program, source_url):
    data = {"mediathek": mediathek, "program": program, "target_url": "", "duration": "", "image_url": "", "args":{}}
    aired = {"year": "", "mon": "", "day": "", "hour": "", "min": ""}
    return {"type": "unknown", "mode": "unknown", "name": "unknown", "aired": aired, "subtitle_url": "", "plot": "", "availability": "", "source_url": source_url, "data": data}

    
    
    

class Mediathek(object):
    
    def __init__(self):
        pass
    
    
    def get_categories(self, program):
        result = []
        return result
        
        
    def get_shows_by_date(self, program, date):
        result = []
        return result


    def get_shows_by_char(self, program, charakter):
        result = []
        return result


    def search(self, program, search_str):
        result = []
        return result


    def get_content(self, program, url):
        result = []
        return result
    
    
    def get_items_from_content(self, program, url, args):
        result = []
        return result
    
    
    def get_stream_data(self, program, url):
        result = []
        return result
    
    