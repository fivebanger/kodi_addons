
import xbmcvfs
import xbmc
import json
import os.path
import dirs


log_level = xbmc.LOGDEBUG


class Data():    
    
    def load_list(self, type, filename, path='data'):
        
        file = filename+'.jsn'
        
        if type == 'artists':
            result = {"artists": []}
        elif type == 'albums':
            result = {"albums": []}
        elif type == 'tracks':
            result = {"tracks": []}
        elif type == 'fanart':
            result = {"mbrainz_ids": {}, "artist_urls": {}}
        elif type == 'categories':
            result = {'categories': [{'type': 'artists', 'mode': 'categories', 'name': 'My Artists', 'filename': 'artists', 'lock': True},
                                     {'type': 'albums', 'mode': 'categories', 'name': 'My Albums', 'filename': 'albums', 'lock': True},
                                     {'type': 'tracks', 'mode': 'categories', 'name': 'My Tracks', 'filename': 'tracks', 'lock': True}]}
        elif type == 'search':
            pass
        else:
            return None
        
        result = []
        
        if 'data' == path:        
            dir=dirs.check_mdat_data_path()
        elif 'profile' == path:
            dir=dirs.check_addon_data_path()
        else:
            return None
        
        file=os.path.join(dir, file)

        try:
            #if os.path.exists does not work!
            fh = xbmcvfs.File(file, 'r')
            result=json.loads( fh.read() )
            fh.close()
        except:
            xbmc.log( ('[ARD_Audiothek]: Cannot load %s list' % file), xbmc.LOGNOTICE)
            if type == 'categories':
                #save only the categories file but don't mess up the data base
                self.save_file(filename, result)
        
        return result
    
    
    def save_list(self, type, filename, list, list_bak, path='data'):
        
        filename_bak = filename+'_bak.jsn'
        filename = filename+'.jsn'
        
        if 'data' == path:        
            dir=dirs.check_mdat_data_path()
        elif 'profile' == path:
            dir=dirs.check_addon_data_path()
        else:
            return
        
        file=os.path.join(dir, filename)

        #don't do a backup in case original list is empty
#         if 0 != len(list_bak[type]):
#             '''
#             file_bak=os.path.join(dir, filename_bak)
#             fd = open(file_bak, 'w')
#             json.dump(list_bak, fd)
#             fd.close()
#             '''
#             try:
#                 #if os.path.exists does not work!
#                 file_bak=os.path.join(dir, filename_bak)
#                 fh = xbmcvfs.File(file_bak, 'w')
#                 list_bak = json.dumps(list_bak)
#                 fh.write(list_bak)
#                 fh.close()
#             except:
#                 xbmc.log( ('Hotspot: Cannot save %s' % filename_bak), xbmc.LOGERROR)

        try:
            '''
            file=os.path.join(dir, filename)
            fd = open(file, 'w')
            json.dump(list, fd)
            fd.close()
            '''
            #if os.path.exists does not work!
            file=os.path.join(dir, filename)
            fh = xbmcvfs.File(file, 'w')
            list = json.dumps(list)
            fh.write(list)
            fh.close()
        except:
            xbmc.log( ('[ARD_Audiothek]: Cannot save %s' % filename), xbmc.LOGERROR)
            
    
    def load_file(self, filename, path='data'):
        filename = filename+'.jsn'
        result = None        
        
        if 'data' == path:        
            dir=dirs.check_mdat_data_path()
        elif 'profile' == path:
            dir=dirs.check_addon_data_path()
        else:
            return
        
        file=os.path.join(dir, filename)

        try:  
            fh = xbmcvfs.File(file, 'r')
            result=json.loads( fh.read() )
            fh.close()
        except:
            xbmc.log( ('Hotspot: Cannot load %s list' % filename), xbmc.LOGNOTICE)
        
        return result
            

    def save_file(self, filename, list, list_bak=None, path='data'):
        filename = filename+'.jsn'
        
        if 'data' == path:        
            dir=dirs.check_mdat_data_path()
        elif 'profile' == path:
            dir=dirs.check_addon_data_path()
        else:
            return
        
        file=os.path.join(dir, filename)

        if None != list_bak:
            filename_bak = filename+'_bak.jsn'
            '''
            file_bak=os.path.join(dir, filename_bak)
            fd = open(file_bak, 'w')
            json.dump(list_bak, fd)
            fd.close()
            '''
            try:
                #if os.path.exists does not work!
                file_bak=os.path.join(dir, filename_bak)
                fh = xbmcvfs.File(file_bak, 'w')
                list_bak = json.dumps(list_bak)
                fh.write(list_bak)
                fh.close()
            except:
                xbmc.log( ('Hotspot: Cannot save %s' % filename_bak), xbmc.LOGERROR)
        
        '''
        file=os.path.join(dir, filename)
        fd = open(file, 'w')
        json.dump(list, fd)
        fd.close()
        '''
        try:
            #if os.path.exists does not work!
            file=os.path.join(dir, filename)
            fh = xbmcvfs.File(file, 'w')
            list = json.dumps(list)
            fh.write(list)
            fh.close()
        except:
            xbmc.log( ('Hotspot: Cannot save %s' % filename), xbmc.LOGERROR)
            

    def delete_file(self, filename, path='data'):

        filename_bak = filename+'_bak.jsn'
        filename = filename+'.jsn'
        
        if 'data' == path:        
            dir=dirs.check_mdat_data_path()
        elif 'profile' == path:
            dir=dirs.check_addon_data_path()
        else:
            return
        
        file=os.path.join(dir, filename)
        try:
            #if os.path.exists does not work!
            os.remove(file)
        except:
            xbmc.log( ('Hotspot: Cannot delete %s' % file), xbmc.LOGERROR)
        file=os.path.join(dir, filename_bak)
        try:
            os.remove(file)
        except:
            xbmc.log( ('Hotspot: Cannot delete %s' % file), xbmc.LOGERROR)
            

    def rename_file(self, old_filename, new_filename, backup=True, path='data'):

        old_filename_bak = old_filename+'_bak.jsn'
        new_filename_bak = new_filename+'_bak.jsn'
        
        old_filename = old_filename+'.jsn'
        new_filename = new_filename+'.jsn'
        
        if 'data' == path:        
            dir=dirs.check_mdat_data_path()
        elif 'profile' == path:
            dir=dirs.check_addon_data_path()
        else:
            return

        if True == backup:
            old_file=os.path.join(dir, old_filename)
            new_file=os.path.join(dir, old_filename_bak)
            try:
                #if os.path.exists does not work!
                os.rename(old_file, new_file)
            except:
                xbmc.log( ('Hotspot: Cannot rename %s' % old_file), log_level)
        
        old_file=os.path.join(dir, old_filename)
        new_file=os.path.join(dir, new_filename)
        try:
            os.rename(old_file, new_file)
        except:
            xbmc.log( ('Hotspot: Cannot rename %s' % old_file), log_level)
            
            