
import sys

from addon_utils import Dispatcher, sys_path_insert

#Make lib available
sys_path_insert('/lib')

from audiothek import Audiothek


audiothek = Audiothek()
dispatcher = Dispatcher(sys.argv, audiothek)
dispatcher.route()