# -*- coding: utf-8 -*-

import re
import time
import json
import requests
import datetime



import utils
from mediathek import Mediathek

base_url = 'https://audiothek.ardmediathek.de'
home = "https://audiothek.ardmediathek.de/homescreen"

header = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0'}


class ARDAudiothek(Mediathek):
    
    def __init__(self):
        self.program = ""
        self.mediathek = "ard_audiothek"
        self.source_url = ""
        self.img_ratio = "1x1"
        self.img_res = "488"
        self.base_url = 'https://api.ardaudiothek.de/graphql/'
        self.limit = 20
        
    
    def get_categories(self, program):
        self.program = program
        url = "https://api.ardaudiothek.de/graphql/editorialcategories"
        return self.get_content(program, url)
        
        
    def get_service(self, program):
        self.program = program
        url = 'https://api.ardaudiothek.de/graphql/organizations'
        return self.get_content(program, url)
        
        
    def get_home(self, program):
        self.program = program
        url = 'https://api.ardaudiothek.de/graphql/homescreen'
        return self.get_content(program, url)


    def search(self, program, search_str):
        result = []
        search_str = search_str.replace(" ", "+")
        url = u'https://api.ardaudiothek.de/graphql/search/programsets?query={}'.format(search_str)
        result.extend(self.get_content(program, url))
        url = u'https://api.ardaudiothek.de/graphql/search/items?query={}&offset=0&limit=50&order=publish_date_asc'.format(search_str)
        result.extend(self.get_content(program, url))
        return result


    def get_content(self, program, url):
        self.program = program

        result = []
        content = self._load_json_page(url, header)
        
        if( "organizations" in url ):
            result = self._get_items_from_organizations(content)

        elif( "publicationservices" in url ):
            programsets = content["data"]["publicationService"]["programSets"]["nodes"]
            result = self._get_items_from_programsets(programsets)

        elif( "editorialcategoriesbyid" in url ):
            result = self._get_items_from_editorialcategories_id(content)
            
        elif( "editorialcategories" in url ):
            result = self._get_items_from_editorialcategories(content)
            
        elif( "editorialcollections" in url ):
            items = content['data']['editorialCollection']['items']['nodes']
            result = self._get_result_from_items(items)
            
        elif( "search" in url ):
            if None != content["data"]['search']["programSets"]:
                programsets = content["data"]['search']["programSets"]["nodes"]
                result = self._get_items_from_programsets(programsets)
            elif None != content["data"]['search']["items"]:
                programsets = content["data"]['search']["items"]["nodes"]
                result = self._get_result_from_items(programsets)
            
        elif( "programsets" in url ):
            items = content["data"]["programSet"]["items"]["nodes"]
            result = self._get_result_from_items(items)

        else:
            self.logger.error('wrong url: {}'.format(url))
        
        return result
    
    
    def get_items_from_content(self, program, url, args):
        self.program = program
        content = self._load_json_page(url, header)
        return self._get_items_from_category(content, args)
    
    
    def get_stream_data(self, program, url, quality="high"):
        self.program = program
        result = []
        
        content = self._load_json_page(url, header)
        stream_data = content["data"]["item"]

        record = utils.get_new_record(self.mediathek, self.program, url)
        
        record["type"] = "play_stream"
        record["mode"] = "end"
        record["name"] = stream_data["title"]
        record["data"]["target_url"] = stream_data['audios'][0]['url']
        record["data"]["image_url"] = self._get_image(stream_data['image'])
        record["data"]["duration"] = stream_data["duration"]
        
        
        result.append(record)
        return result
    
    
    def _get_items_from_editorialcategories_id(self, content):
        self.logger.debug('_get_items_from_editorialcategories_id()')
        result = []
        
        image_url = content['data']['editorialCategory']['image']
        categories = content['data']['editorialCategory']['sections']

        for idx, key in enumerate(categories):
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            record["type"] = "category"
            record["mode"] = "get_content_from_categoy"
            record["data"]["target_url"] = self.source_url
            record["data"]["args"]["ref"] = idx
            record["data"]["image_url"] = self._get_image(image_url)

            if( "items" == key['nodeType'] and not "featured_programset" == key['type']):
            #if( "items" == key['nodeType'] ):
                if key.get('title'):
                    record["name"] = key['title']
                    record["data"]["args"]["category"] = 'items'
                    result.append(record)
                else:
                    record["name"] = 'Highlights'
                    record["data"]["args"]["category"] = 'items'
                    
                    result.append(record)
                    
            elif( "items" == key['nodeType'] and "featured_programset" == key['type'] ):
                record["name"] = key['title']
                record["data"]["args"]["category"] = 'featured_programset'
                    
                result.append(record)
                    
            elif( "programSets" == key['nodeType'] ):
                record["name"] = key['title']
                record["data"]["args"]["category"] = 'programsets'
                
                result.append(record)
                
            elif( "ProgramSet" == key['nodeType'] ):
                record["name"] = key['title']
                record["data"]["args"]["category"] = 'programset'
                
                result.append(record)
                
            elif( "Item" == key['nodeType'] ):
                if key.get('items'):
                    record["name"] = key['title']
                    record["data"]["args"]["category"] = 'item'
                    
                    result.append(record)
            
        return result
    
    
    def _get_items_from_editorialcategories(self, content):
        self.logger.debug('_get_items_from_editorialcategories()')
        result = []
        
        categories = content["data"]["editorialCategories"]["nodes"]
        
        for key in categories:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = key['title']
            record["data"]["target_url"] = '{}editorialcategoriesbyid/{}'.format(self.base_url, key['id'])
            record["data"]["image_url"] = self._get_image(key['image'])
        
            result.append(record)
        
        return result


    def _get_items_from_organizations(self, content):
        self.logger.debug('_get_items_from_organizations()')
        result = []
        services = []
        
        organizations = content["data"]["organizations"]['nodes']
        
        for key in organizations:
            if( key["name"] == self.program ):
                services = key["publicationServices"]["nodes"]
                break
        
        for key in services:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = key['title']
            record["data"]["target_url"] = '{}publicationservices/{}'.format(self.base_url, key['id'])
            record["data"]["image_url"] = self._get_image(key['image'])
        
            result.append(record)
        
        return result
    
    '''
    def _get_result_from_publicationservice(self, data):
        self.logger.debug('_get_result_from_publicationservice()')
        result = []
        
        for key in data:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = key['title']
            record["data"]["target_url"] = '{}publicationservices/{}'.format(self.base_url, key['id'])
        
            result.append(record)

        return result
    '''

    def _get_items_from_search(self, content):
        self.logger.debug('_get_items_from_search()')
        result = []
        
        items = content["_embedded"]["mt:itemSearchResults"]["_embedded"]["mt:items"]
        data = self._get_result_from_items(items)
        result.extend(data)

        data = self._get_next_page(content)
        result.extend(data)

        return result
    

    def _get_result_from_items(self, items, offset=0, elements=0, target_url=''):
        self.logger.debug('_get_result_from_items()')
        result = []
        
        for key in items:
            if key.get('title'):
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                record["type"] = "stream_meta_data"
                record["mode"] = "play_stream"
                record["name"] = key['title']
                record["data"]["target_url"] = '{}items/{}'.format(self.base_url, key['id'])
                record["data"]["image_url"] = self._get_image(key['image'])
                record["data"]["duration"] = key["duration"]
            
                result.append(record)
            
        if (offset + self.limit) < elements:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            offset_str = 'offset={}'.format(offset + self.limit)
            limit = 'limit={}'.format(self.limit)
            url = target_url
            url = target_url.replace('offset=', offset_str)
            url = url.replace('limit=', limit)
            
            record["type"] = "category"
            record["mode"] = "get_content_from_categoy"
            record["name"] = 'Next >>'
            record["data"]["target_url"] = url
            
            record["data"]["args"]["category"] = 'items_programsets'
            record["data"]["args"]["elements"] = elements
            record["data"]["args"]["offset"] = offset + self.limit
            record["data"]["args"]["target_url"] = target_url
        
            
            result.append(record)
            
        return result


    def _get_items_from_programsets(self, programsets):
        self.logger.debug('_get_items_from_programsets()')
        result = []
        offset=0
        
        for key in programsets:
            if key.get('title') and (0 != key['numberOfElements']):
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                    
                record["type"] = "category"
                record["mode"] = "get_content_from_categoy"
                record["name"] = key['title']
                record["data"]["target_url"] = '{}programsets/{}?offset={}&limit={}&order=publish_date_asc'.format(self.base_url, key['id'], offset, self.limit)
                record["data"]["image_url"] = self._get_image(key['image'])
                record["data"]["program"] = key['publicationService']['organizationName']
                record["data"]["args"]["category"] = 'items_programsets'
                record["data"]["args"]["elements"] = key['numberOfElements']
                record["data"]["args"]["offset"] = offset
                record["data"]["args"]["target_url"] = '{}programsets/{}?offset=&limit=&order=publish_date_asc'.format(self.base_url, key['id'])
            
                result.append(record)

        return result
    
    
    def _get_items_from_category(self, content, args):
        self.logger.debug('_get_items_from_category()')
        result = []
        
        if args["category"] == 'programset':
            categories = content['data']['editorialCategory']['sections']
            
            for idx, key in enumerate(categories):
                if( args["ref"] == idx ):
                    programsets = key['programSets']
                    result = self._get_items_from_programsets(programsets)
                    break 
        
        elif args["category"] == 'items':
            categories = content['data']['editorialCategory']['sections']
    
            for idx, key in enumerate(categories):
                if( args["ref"] == idx ):
                    items = self._get_safe(key, ['nodes'], [])
                    result = self._get_result_from_items(items)
                    break

        elif args["category"] == 'programsets':
            categories = content['data']['editorialCategory']['sections']
    
            for idx, key in enumerate(categories):
                if( args["ref"] == idx ):
                    for item in key['nodes']:
                        if item.get('title'):
                            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                            
                            record["type"] = "category"
                            record["mode"] = "get_content"
                            record["name"] = item["title"]

                            record["data"]["target_url"] = '{}editorialcollections/{}'.format(self.base_url, item['id'])
                            record["data"]["image_url"] = self._get_image(item['image'])
                            
                            result.append(record)
                    break

        elif args["category"] == 'featured_programset':
            categories = content['data']['editorialCategory']['sections']
    
            for idx, key in enumerate(categories):
                if( args["ref"] == idx ):
                    programsets = key['nodes']
                    result = self._get_items_from_programsets(programsets)
                    break

        elif args["category"] == 'item':
            categories = content['data']['editorialCategory']['sections']
    
            for idx, key in enumerate(categories):
                if( args["ref"] == idx ):
                    items = key['items']
                    result = self._get_result_from_items(items)
                    break

        elif args["category"] == 'items_programsets':
            items = content["data"]["programSet"]["items"]["nodes"]
            offset = args["offset"]
            elements = args["elements"]
            target_url = args["target_url"]
            
            result = self._get_result_from_items(items, offset, elements, target_url)
            
        return result


    def _get_image(self, link):
        image_url = ""
        
        try:
            image_url = link["url1X1"]
            image_url = image_url.replace("{width}", self.img_res)
        except:
            self.logger.error('image not found: {}'.format(link))
        
        return image_url
    
                    
    def _get_safe(self, dict_base, keys, default=""):
        result = default
        try:
            for key in keys:
                dict_base = dict_base[key]
            result = dict_base
        except:
            pass
        return result
    
    
    def _load_json_page(self, url, headers=None):
        self.logger.debug('load page from url: {}'.format(url))
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")

        if( None == headers ):
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0'}
        
        content = requests.get(self.source_url, allow_redirects=True, headers=headers)
        #self.logger.debug('req-header: {}'.format(content.request.headers))
        #self.logger.debug('resp-header: {}'.format(content.headers))
        if(content.encoding is not None):
            result = content.text.encode(content.encoding)
        else:
            result = content.text

        result = result.decode("utf-8")
        if( "<!doctype html>" in result[:40].lower() ):
            jresult = self._extract_json(result)
        else:
            try:
                jresult = json.loads(result)
            except:
                self.logger.error('cannot load json')
                jresult = ""
        
        return jresult


    def _extract_json(self, html):
        try:
            content = re.compile("__INITIAL_STATE__ = ({.*});").search(html).group(1)
            content = json.loads(content)
        except:
            content = ""
        return content
    
    
    
    
