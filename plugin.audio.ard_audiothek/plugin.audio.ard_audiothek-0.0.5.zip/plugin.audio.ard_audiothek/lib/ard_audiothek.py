# -*- coding: utf-8 -*-

import re
import time
import json
import requests
import datetime

try:
    # Python 3
    from urllib.parse import urlencode, parse_qsl 
except ImportError:
    # Python 2
    from urlparse import parse_qsl
    from urllib import urlencode

import utils
from mediathek import Mediathek

base_url = 'https://audiothek.ardmediathek.de'
home = "https://audiothek.ardmediathek.de/homescreen"

header = {
            "Accept":"application/hal+json",
            "User-Agent":"okhttp/3.3.0",
            #hmk "Accept-Encoding":"gzip",
         }


class ARDAudiothek(Mediathek):
    
    def __init__(self):
        self.mediathek = "ard"
        self.program = ""
        self.mediathek = "ard_audiothek"
        self.source_url = ""
        self.img_ratio = "1x1"
        self.img_res = "488"
        
    
    def get_categories(self, program):
        self.program = program
        url = "https://audiothek.ardmediathek.de/editorialcategories"
        return self.get_content(program, url)
        
        
    def get_service(self, program):
        self.program = program
        url = "https://audiothek.ardmediathek.de/organizations"
        return self.get_content(program, url)


    def search(self, program, search_str):
        search_str = search_str.replace(" ", "+")
        url = "https://audiothek.ardmediathek.de/search?query=" + search_str
        return self.get_content(program, url)


    def get_content(self, program, url):
        self.program = program

        result = []
        content = self._load_json_page(url, header)
        
        if( "editorialcategories" in url ):
            if( content.get("id") ):
                result = self._get_items_from_editorialcategories_id(content)
            else:
                result = self._get_items_from_editorialcategories(content)
        
        elif( "organizations" in url ):
            result = self._get_items_from_organizations(content)
        
        elif( "search" in url ):
            result = self._get_items_from_search(content)
        
        elif( "programsets" in url ):
            result = self._get_items_from_programsets(content)
        
        elif( "publicationservices" in url ):
            result = self._get_items_from_publicationservices(content)
        
        return result
    
    
    def get_items_from_content(self, program, url, args):
        self.program = program
        content = self._load_json_page(url, header)
        return self._get_items_from_category(content, args["category"])
    
    
    def get_stream_data(self, program, url, quality="high"):
        self.program = program
        result = []
        
        url_tmp = url.split("?")
        base_url = url_tmp[0]
        query = url_tmp[1]
        
        query = parse_qsl(query)
        query = dict(query)

        record = utils.get_new_record(self.mediathek, self.program, url)
        record["type"] = "play_stream"
        record["mode"] = "end"
        record["name"] = query["name"]
        
        record["data"]["target_url"] = base_url
        record["data"]["image_url"] = query["image_url"]
        record["data"]["duration"] = query["duration"]
        
        
        result.append(record)
        return result
    
    
    def _get_items_from_editorialcategories_id(self, content):
        result = []
        
        categories = ["mt:mostPlayed", "mt:featuredProgramSets", "mt:items", "mt:programSets"]

        editorialcategories_name_mapping = { 
            "mt:mostPlayed": "Meistgehörte Episoden",
            "mt:items": "Neueste Episoden",
            "mt:featuredProgramSets": "Ausgewählte Sendungen",
            "mt:programSets": "Weitere Kategorien"
            }
        
        for category in categories:
            items = self._get_safe(content, ["_embedded", category])
        
            if( "" != items ):
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                record["type"] = "category"
                record["mode"] = "get_content_from_categoy"
                record["name"] = editorialcategories_name_mapping[category]
                record["data"]["target_url"] = self.source_url
                record["data"]["args"]["category"] = category
                
                result.append(record)
            
        return result
    
    
    def _get_items_from_editorialcategories(self, content):
        result = []
        
        items = content["_embedded"]["mt:editorialCategories"]
        data = self._get_result_from_items(items)
        result.extend(data)
            
        return result


    def _get_items_from_organizations(self, content):
        result = []
        service = []
        
        organizations = content["_embedded"]["mt:organizations"]
        
        for key in organizations:
            if( key["id"] == self.program ):
                service = key["_embedded"]["mt:publicationServices"]
                break
        
        if( not isinstance(service, list) ):
            service_copy = service.copy()
            service = []
            service.append(service_copy)
        
        data = self._get_result_from_items(service)
        result.extend(data)
        
        return result


    def _get_items_from_search(self, content):
        result = []
        
        items = content["_embedded"]["mt:itemSearchResults"]["_embedded"]["mt:items"]
        data = self._get_result_from_items(items)
        result.extend(data)

        data = self._get_next_page(content)
        result.extend(data)

        return result


    def _get_items_from_programsets(self, content):
        result = []
        
        categories = ["mt:items", "mt:publicationService", "mt:editorialCategories"]
        
#         programsets_name_mapping = { 
#             "mt:items": "Meistgehörte Items",
#             "mt:publicationService": "Neueste Service",
#             "mt:editorialCategories": "Ausgewählte Categories",
#                         }
        
        for item in categories:
            items = self._get_safe(content, ["_embedded", item], [])
            data = self._get_result_from_items(items)
            result.extend(data)

        data = self._get_next_page(content)
        result.extend(data)
            
        return result


    def _get_items_from_publicationservices(self, content):
        result = []
        
        items = content["_embedded"]["mt:programSets"]
        data = self._get_result_from_items(items)
        result.extend(data)
            
        return result
    
    
    def _get_items_from_category(self, content, category):
        result = []
        
        items = content["_embedded"][category]
        data = self._get_result_from_items(items)
        result.extend(data)
        
#         for key in items:
#             record = utils.get_new_record(self.mediathek, self.program, self.source_url)
#                 
#             links = self._get_safe(key, ["_links"], {})
#             
#             if( links.get("mt:bestQualityPlaybackUrl") ):
#                 record["type"] = "stream_meta_data"
#                 record["mode"] = "play_stream"
#                 record["name"] = key["title"]
# 
#                 record["data"]["target_url"] = key["_links"]["mt:bestQualityPlaybackUrl"]["href"]
#                 
#                 image_url = key["_links"]["mt:image"]["href"]
#                 image_url = image_url.replace("{ratio}", self.img_ratio)
#                 image_url = image_url.replace("{width}", self.img_res)
#                 
#                 record["data"]["image_url"] = image_url
#                 record["data"]["duration"] = key["duration"]
#                 
#                 try:
#                     name = record["name"].encode('Latin-1')
#                 except:
#                     name = record["name"].encode('utf-8')
# 
#                 query = { "name": name, 
#                           "image_url": record["data"]["image_url"], 
#                           "duration": record["data"]["duration"]
#                         }
#                 record["data"]["target_url"] = record["data"]["target_url"] + '?' + urlencode(query)
#                 
#                 result.append(record)
#             
#             else:
#                 record["type"] = "category"
#                 record["mode"] = "get_content"
#                 record["name"] = key["title"]
#                 record["data"]["target_url"] = self._get_url_from_link(links)
#                 
#                 result.append(record)

        if( "mt:items" == category ):
            next_page = self._get_safe(content, ["_links", "next", "href"])
            if( "" != next_page ):
                next_page = next_page.replace("./", "/")
                next_page = base_url + next_page
                
                record = utils.get_new_record(self.mediathek, self.program, self.source_url)
                
                record["type"] = "category"
                record["mode"] = "get_content_from_categoy"
                record["name"] = "Next page >>"
                
                record["data"]["target_url"] = next_page
                record["data"]["args"]["category"] = category
                
                result.append(record)
            
        return result
    
    





    def _get_image(self, links):
        image_url = ""
        
        try:
            #image_url = key["_links"]["mt:image"]["href"]
            image_url = links["mt:image"]["href"]
            image_url = image_url.replace("{ratio}", self.img_ratio)
            image_url = image_url.replace("{width}", self.img_res)
        except:
            pass
        
        return image_url


    def _get_result_from_items(self, items):
        result = []
    
        for key in items:
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            links = self._get_safe(key, ["_links"], {})
            
            if( links.get("mt:bestQualityPlaybackUrl") ):
                record["type"] = "stream_meta_data"
                record["mode"] = "play_stream"
                record["name"] = key["title"]
                
                record["data"]["target_url"] = key["_links"]["mt:bestQualityPlaybackUrl"]["href"]
                record["data"]["image_url"] = self._get_image(links)
                record["data"]["duration"] = key["duration"]
            
                try:
                    name = record["name"].encode('Latin-1')
                except:
                    name = record["name"].encode('utf-8')

                query = { "name": name, 
                          "image_url": record["data"]["image_url"], 
                          "duration": record["data"]["duration"]
                        }
                record["data"]["target_url"] = record["data"]["target_url"] + '?' + urlencode(query)
                
                result.append(record)

            else:
                record["type"] = "category"
                record["mode"] = "get_content"
                record["name"] = self._get_safe(key, ["title"], "name")
                record["data"]["target_url"] = self._get_url_from_link(links)
                record["data"]["image_url"] = self._get_image(links)
            
                if( "" != record["data"]["target_url"]):
                    result.append(record)
                    
        return result
    
    
    def _get_next_page(self, content):
        result = []
        
        next_page = self._get_safe(content, ["_links", "next", "href"])
        if( "" != next_page ):
            next_page = next_page.replace("./", "/")
            next_page = base_url + next_page
            
            record = utils.get_new_record(self.mediathek, self.program, self.source_url)
            
            record["type"] = "category"
            record["mode"] = "get_content"
            record["name"] = "Next page >>"
            record["data"]["target_url"] = next_page
            
            result.append(record)
            
        return result
    

    def _get_url_from_link(self, links):
        link = ""
        
        try:
            link = links["self"]["href"].replace("./", "/")
            
            if( "{" in link ):
                link = link.split("{")
                link = link[0]
            
            link = "https://audiothek.ardmediathek.de" + link
        except:
            pass
        
        return link
    
                    
    def _get_safe(self, dict_base, keys, default=""):
        result = default
        try:
            for key in keys:
                dict_base = dict_base[key]
            result = dict_base
        except:
            pass
        return result
    
    
    def _load_json_page(self, url, headers=None):
        #for test only! return ""
        self.source_url = url.replace( " ", "%20" ).replace("&amp;","&")

        if( None == headers ):
            headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:25.0) Gecko/20100101 Firefox/25.0'}
        
        content = requests.get(self.source_url, allow_redirects=True, headers=headers);
        if(content.encoding is not None):
            result = content.text.encode(content.encoding)
        else:
            result = content.text
        
        #hmk result = result.decode("utf-8")
        if( "<!doctype html>" in result[:40].lower() ):
            jresult = self._extract_json(result)
        else:
            try:
                jresult = json.loads(result)
            except:
                jresult = ""
        
        return jresult


    def _extract_json(self, html):
        try:
            content = re.compile("__INITIAL_STATE__ = ({.*});").search(html).group(1)
            content = json.loads(content)
        except:
            content = ""
        return content
    
    
    
    