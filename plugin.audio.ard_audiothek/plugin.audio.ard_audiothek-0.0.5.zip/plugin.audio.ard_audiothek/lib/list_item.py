import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmc
import os
from context_menu import Contextmenu
from url_utils import Urlbuild

class ListItem():
    
    def __init__(self, addon_id, addon_handle, base_url=''):
        self.addon_handle = addon_handle
        self.addon = xbmcaddon.Addon(addon_id)
        self.base_url = base_url
        self.cm = Contextmenu(base_url)
        self.cm_items = []
        self.path = ''
        self.replace_items = True


    def addon_path(self, path):
        url_build = Urlbuild(self.base_url)
        self.path = url_build.addon(path)


    def menu(self, menu_type, name, icon='', fanart=''):
        list_name = name
        
        if '' == fanart:
            fanart = os.path.join(self.addon.getAddonInfo('path'), 'fanart.jpg')
            
        if '' == icon:
            icon = 'DefaultFolder.png'
        
        if menu_type == 'main_menu':
            list_name = name
        elif menu_type == 'spotify_menu':
            list_name = name
        elif menu_type == 'recently_menu':
            list_name = name
        elif menu_type == 'genre':
            list_name = name
        else:
            #return None
            pass
        
        li = xbmcgui.ListItem(list_name)
        li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
        li.addContextMenuItems(self.cm_items, replaceItems=self.replace_items)
        
        xbmcplugin.addDirectoryItem(self.addon_handle, self.path, li, isFolder=True)
        
        
    def stream_new(self, name, stream_meta_url, duration, icon='', fanart='', plot=''):
        content = "songs"
        
        info_type = "music"
        infoLabels = {'duration': duration, 'title': name}
        
        li = xbmcgui.ListItem(name)
        li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
        li.addContextMenuItems(self.cm_items, replaceItems=self.replace_items)
        li.setProperty('IsPlayable', 'true')
        li.setInfo(info_type, infoLabels)
        
        xbmcplugin.addDirectoryItem(self.addon_handle, self.path, li, isFolder=False)
        xbmcplugin.setContent(self.addon_handle, content)
        
        
#         xbmcplugin.addDirectoryItem(self.addon_handle, self.path, li, isFolder=False, totalItems=len)
#         xbmcplugin.setContent(self.addon_handle, content)
        
        
    def stream(self, name, stream_url, duration, icon='', fanart=''):
        content = "songs"
        
        info_type = "music"
        infoLabels = {'duration': duration, 'title': name}
        
        li = xbmcgui.ListItem(name)
        li.setArt({'thumb': icon, 'icon': icon, 'fanart': fanart})
        li.addContextMenuItems(self.cm_items, replaceItems=self.replace_items)
        li.setInfo(info_type, infoLabels)
        
        xbmcplugin.addDirectoryItem(self.addon_handle, stream_url, li, isFolder=False)
        xbmcplugin.setContent(self.addon_handle, content)
        
        
#         xbmcplugin.addDirectoryItem(self.addon_handle, self.path, li, isFolder=False, totalItems=len)
#         xbmcplugin.setContent(self.addon_handle, content)
        
        
    def end_of_directory(self):
        xbmcplugin.endOfDirectory(self.addon_handle)


    def cm_none(self):
        self.cm_items = []


    def cm_menu(self, menue_type, name, cm_mode, data):
        self.cm_items = self.cm.menu_item(menue_type, name, cm_mode, data)


    def cm_menu_add(self, menue_type, name, cm_mode, data):
        self.cm_items.extend(self.cm.menu_item(menue_type, name, cm_mode, data))
        
        