
try:
    # Python 3
    from urllib.parse import urlencode
except ImportError:
    # Python 2
    from urllib import urlencode


class Urlbuild():
    
    def __init__(self, base_url):
        self.base_url = base_url

        
    def addon(self, query):
        return self.base_url + '?' + urlencode(query)


