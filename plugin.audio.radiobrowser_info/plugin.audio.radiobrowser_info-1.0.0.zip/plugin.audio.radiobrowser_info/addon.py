
import sys

from addon_utils import Dispatcher, sys_path_insert

#Make lib available
sys_path_insert('/src')

from radiobrowser import RadioApp


radio = RadioApp()
dispatcher = Dispatcher(sys.argv, radio)
dispatcher.route()