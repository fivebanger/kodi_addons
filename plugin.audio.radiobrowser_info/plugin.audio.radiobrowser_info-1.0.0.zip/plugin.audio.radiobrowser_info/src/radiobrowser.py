
import os
import xbmcaddon
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs


from addon_utils import ListItem, DataHandler, get_text_from_keyboard
from pyradios import RadioBrowser
from m3u_parser import M3UParser


CURRENT_DIR = os.path.dirname(os.path.realpath(__file__))


SEARCH_MENU_STATION = [
    {'mode': 'do_search_station', 'data': {'name': 'New search', 'query': '', 'cm': None}},
]

SEARCH_MENU_GENRE = [
    {'mode': 'do_search_genre', 'data': {'name': 'New search', 'query': '', 'cm': None}},
]

MAIN_MENU =  [
    {'mode': 'get_my_stations', 'data': {'name': 'My stations'}},
    {'mode': 'get_recently', 'data': {'name': 'Recently played'}},
    {'mode': 'search_station', 'data': {'name': 'Search station', 'query': ''}},
    {'mode': 'search_genre', 'data': {'name': 'Search genre', 'query': ''}},
    {'mode': 'get_genres', 'data': {'name': 'Browse by genre'}},
    {'mode': 'get_stations_by_votes', 'data': {'name': 'Browse by votes'}},
    {'mode': 'get_stations_by_clicks', 'data': {'name': 'Browse by clicks'}},
    {'mode': 'get_countries', 'data': {'name': 'Browse by country'}},
    {'mode': 'get_regions', 'data': {'name': 'Browse by region'}},
    {'mode': 'get_languages', 'data': {'name': 'Browse by language'}},
]

CM_MAP = {
    'search_station_cm': [
        {'name': 'Remove from Search', 'mode': 'remove_from_serach_station', 'data': {}, 'action': 'RunPlugin'},
    ],
    'search_genre_cm': [
        {'name': 'Remove from Search', 'mode': 'remove_from_serach_genre', 'data': {}, 'action': 'RunPlugin'},
    ],
    'recently_cm': [
        {'name': 'Add to my stations', 'mode': 'add_to_stations', 'data': {}, 'action': 'RunPlugin'},
        {'name': 'Add to IPTV Simple', 'mode': 'add_to_iptv', 'data': {}, 'action': 'RunPlugin'},
        {'name': 'Remove from recently', 'mode': 'remove_from_recently', 'data': {}, 'action': 'RunPlugin'},
    ],
    'add_station_cm': [
        {'name': 'Add to my stations', 'mode': 'add_to_stations', 'data': {}, 'action': 'RunPlugin'},
        {'name': 'Add to IPTV Simple', 'mode': 'add_to_iptv', 'data': {}, 'action': 'RunPlugin'},
    ],
    'remove_station_cm': [
        {'name': 'Remove from my stations', 'mode': 'remove_from_stations', 'data': {}, 'action': 'RunPlugin'},
        {'name': 'Add to IPTV Simple', 'mode': 'add_to_iptv', 'data': {}, 'action': 'RunPlugin'},
    ]
}




class RadioApp():
    
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.addon_id = self.addon.getAddonInfo('id')
        self.addon_name = self.addon.getAddonInfo('name')
        self.log_name = self.addon_name.replace(' ', '_')
        self.addon_path = None
        self.addon_handle = None
        self.min_cnt = 100
        self.icon = os.path.join(CURRENT_DIR, '..', 'icon.png')
        self.fanart = os.path.join(CURRENT_DIR, '..', 'fanart.jpg')
        
        if not self.addon.getSettingBool('use_fanart'):
            self.fanart = ''
        
        self.search_station_list = 'search_station'
        self.search_genre_list = 'search_genre'
        self.recent_list = 'recent'
        self.my_stations_list = 'stations'
        
        self.dh = DataHandler()
        self.dh.register_path(self.my_stations_list, '/.radiobrowser', 'use_xchange_folder', 'xchange_folder')
    
    
    def set_addon_data(self, addon_path, addon_handle):
        self.addon_path = addon_path
        self.addon_handle = addon_handle
        
        self.min_cnt = self.addon.getSettingInt('min_cnt')
        self.region = self.addon.getSetting('radio_region').lower()
        self.result_order = 'clickcount'
        #self.result_order = 'votes'
        self.radio = RadioBrowser()


    def root(self, data):
        self._handle_result('menu_list', MAIN_MENU)
    
    
    def search_station(self, data):
        result = SEARCH_MENU_STATION
        history = self.dh.load_list(self.search_station_list)
        result.extend(history)
        self._handle_result('menu_list', result, 'search_station_cm')
    
    
    def do_search_station(self, data):
        query = data['query']
        count, offset = self._get_count(data)
        
        if '' == query:
            query = get_text_from_keyboard()
            self._add_to_search(query, self.search_station_list, 'do_search_station')

        api_result = self.radio.search(name=query, limit=count, offset=offset, order=self.result_order, reverse=True, hidebroken=True)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'do_search_station', query=query)
        self._handle_result('stations_list', result, 'add_station_cm')
        
        
    def remove_from_serach_station(self, data):
        result = self.dh.load_list(self.search_station_list)
        
        for item in result:
            if item['data']["query"] == data['query']:
                result.remove(item)
                self.dh.save_list(self.search_station_list, result)
                xbmc.executebuiltin( "Container.Refresh" )
                break
    
    
    def search_genre(self, data):
        result = SEARCH_MENU_GENRE
        history = self.dh.load_list(self.search_genre_list)
        result.extend(history)
        self._handle_result('menu_list', result, 'search_genre_cm')
    
    
    def do_search_genre(self, data):
        query = data['query']
        count, offset = self._get_count(data)
        
        if '' == query:
            query = get_text_from_keyboard()
            self._add_to_search(query, self.search_genre_list, 'do_search_genre')

        api_result = self.radio.search(tag=query, limit=count, offset=offset, order=self.result_order, reverse=True, hidebroken=True)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'do_search_station', query=query)
        self._handle_result('stations_list', result, 'add_station_cm')
        
        
    def remove_from_serach_genre(self, data):
        result = self.dh.load_list(self.search_genre_list)
        
        for item in result:
            if item['data']["query"] == data['query']:
                result.remove(item)
                self.dh.save_list(self.search_genre_list, result)
                xbmc.executebuiltin( "Container.Refresh" )
                break
    
    
    def get_genres(self, data):
        api_result = self.radio.tags()
        result = self._unify_menu(api_result, 'get_stations_by_genre')
        self._handle_result('menu_list', result)
        
    
    def get_stations_by_genre(self, data):
        genre = data['slug']
        count, offset = self._get_count(data)
        api_result = self.radio.stations_by_tag(genre, limit=count, offset=offset, order=self.result_order, reverse=True, hidebroken=True, countrycode=self.region)
        #api_result = self.radio.stations_by_tag(genre, limit=count, offset=offset, order=self.result_order, reverse=True, hidebroken=True)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_genre', slug=genre)
        self._handle_result('stations_list', result, 'add_station_cm')
    
    
    def get_stations_by_votes(self, data):
        count, offset = self._get_count(data)
        api_result = self.radio.stations_by_votes(limit=count, offset=offset, order=self.result_order, reverse=True, hidebroken=True)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_votes')
        self._handle_result('stations_list', result, 'add_station_cm')
        
    
    def get_stations_by_clicks(self, data):
        count, offset = self._get_count(data)
        api_result = self.radio.search(limit=count, offset=offset, order=self.result_order, reverse=True, hidebroken=True)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_clicks')
        self._handle_result('stations_list', result, 'add_station_cm')
    
    
    def get_countries(self, data):
        api_result = self.radio.countries()
        result = self._unify_menu(api_result, 'get_stations_by_country')
        self._handle_result('menu_list', result)
        
    
    def get_stations_by_country(self, data):
        country = data['slug']
        count, offset = self._get_count(data)
        api_result = self.radio.stations_by_country(country, exact=True, limit=count, offset=offset, order=self.result_order, reverse=True, hidebroken=True)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_country', slug=country)
        self._handle_result('stations_list', result, 'add_station_cm')
        
    
    def get_regions(self, data):
        api_result = self.radio.states()
        result = self._unify_menu(api_result, 'get_stations_by_region')
        self._handle_result('menu_list', result)
        
    
    def get_stations_by_region(self, data):
        region = data['slug']
        count, offset = self._get_count(data)
        api_result = self.radio.stations_by_state(region, exact=True, limit=count, offset=offset, order=self.result_order, reverse=True, hidebroken=True)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_region', slug=region)
        self._handle_result('stations_list', result, 'add_station_cm')
    
    
    def get_languages(self, data):
        api_result = self.radio.languages()
        result = self._unify_menu(api_result, 'get_stations_by_language')
        self._handle_result('menu_list', result)
        
    
    def get_stations_by_language(self, data):
        language = data['slug']
        count, offset = self._get_count(data)
        api_result = self.radio.stations_by_language(language, exact=True, limit=count, offset=offset, order=self.result_order, reverse=True, hidebroken=True)
        result = self._unify_stations(api_result)
        result = self._add_next(api_result, result, count, offset, 'get_stations_by_language', slug=language)
        self._handle_result('stations_list', result, 'add_station_cm')
    

    def play_stream(self, data):
        station_id = data["id"]
        name = data["name"]
        icon = data["icon_url"]
        url_resolved = None
        is_custom = False
        
        if "" != station_id:
            station = self.radio.station_by_uuid(station_id)
            if station:
                station = station[0]
                name = station["name"]
                icon = station["favicon"]
                url_resolved = station['url_resolved']
        else:
            url_resolved = data["stream_url"]
            is_custom = True
        
        # clear playlist to ensure to not play next item in case of a play error. may lead to Kodi crash:
        # "Logic error due to two concurrent busydialogs, this is a known issue. The application will exit."
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        playlist.clear()
            
        if None != url_resolved:
            # simulate play error: 
            # url_resolved = url_resolved[2:]
            xbmc.log(f'[{self.log_name}] play stream {name}, custom: {is_custom}, id: {station_id}, url: {url_resolved}', xbmc.LOGINFO)
            self._add_to_recently(data)
            li = xbmcgui.ListItem(path=url_resolved)
            li.setInfo('music', {'title': name})
            li.setArt({'thumb': icon, 'icon': icon, 'fanart': self.fanart})
            xbmcplugin.setResolvedUrl(self.addon_handle, True, listitem=li)
    

    def play_station(self, data):
        station_id = data["id"]
        name = data['id']
        url_resolved = None
        
        station = self.radio.station_by_uuid(station_id)
        if station:
            station = station[0]
            name = station["name"]
            icon = station["favicon"]
            url_resolved = station['url_resolved']
                
            # ensure that "data" keys are populated since play_stream() was called just with "id"
            data["name"] = name
            data["stream_url"] = url_resolved
            data["icon_url"] = icon
        
        if( None == url_resolved ):
            xbmc.log(f'[{self.log_name}] play_station error, id: {station_id}', xbmc.LOGERROR)
            heading = name
            message = "Cannot play stream"
            xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING)
        else:
            xbmc.log(f'[{self.log_name}] play station {name}, id: {station_id}, url: {url_resolved}', xbmc.LOGINFO)
            self._add_to_recently(data)
            li = xbmcgui.ListItem()

            li.setInfo('music', {'title': name})
            li.setArt({'thumb': icon, 'icon': icon, 'fanart': self.fanart})
            
            fullscreen = False
            if fullscreen:
                player = xbmc.Player()
                player.stop()
                player.play(url_resolved, li)
            else:
                playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
                playlist.clear()
                playlist.add(url=url_resolved, listitem=li)
    
                player = xbmc.Player()
                player.play()
    
    
    def get_my_stations(self, data):
        result = self.dh.load_list(self.my_stations_list)
        if '0' == self.addon.getSetting('sortmethod_stations'):
            result = sorted(result, key=lambda k: k['data']['name'].lower())
        self._handle_result('stations_list', result, 'remove_station_cm')
    
    
    def add_to_stations(self, data):
        name = data["name"]
        result = self.dh.load_list(self.my_stations_list)
        
        if( [] != result ):
            for item in result:
                if( item['data']["id"] == data["id"] ):
                    heading = name
                    message = "Already added to list"
                    xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING)
                    return
                
        record = {}
        record['data'] = data
        record['mode'] = 'play_stream'
        result.insert(0, record)
        
        self.dh.save_list(self.my_stations_list, result)
        heading = name
        message = "Added to my stations"
        xbmcgui.Dialog().notification(heading, message, self.icon)
    
    
    def remove_from_stations(self, data):
        result = self.dh.load_list(self.my_stations_list)
        
        for item in result:
            if( item['data']["name"] == data["name"] ):
                result.remove(item)
                self.dh.save_list(self.my_stations_list, result)
                xbmc.executebuiltin( "Container.Refresh" )
                break

    
    def add_to_iptv(self, data):
        retry = 2
        
        while retry:
            retry -= 1
            
            m3u_file = self.addon.getSetting('m3u_file')
            m3u_bak = m3u_file + 'bak'
            
            if not xbmcvfs.exists(m3u_file):
                if retry:
                    dialog = xbmcgui.Dialog()
                    dialog.ok("Radiobrowser", "Please choose a valid m3u file")
                    self.addon.openSettings()
                else:
                    dialog = xbmcgui.Dialog()
                    dialog.ok("Radiobrowser", "No valid m3u file list specified")
                    return
            else:
                break
            
        tvg_name = data['name']
        group_title = 'Radio-Browser'
        tvg_logo = data['icon_url']
        stream_url = data['stream_url']
        
        if None == stream_url:
            heading = tvg_name
            message = "No valid stream found"
            xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING)
            return
        
        fh = xbmcvfs.File(m3u_file, 'r')
        m3u_dat = fh.read()
        fh.close()
        
        if tvg_name in m3u_dat:
            heading = tvg_name
            message = "Already added to IPTV Simple"
            xbmcgui.Dialog().notification(heading, message, xbmcgui.NOTIFICATION_WARNING)
            return
        
        if not m3u_dat.startswith('#EXTM3U'):
            m3u_tmp = m3u_dat
            m3u_dat = '#EXTM3U\n'
            m3u_dat = m3u_dat + m3u_tmp
        
        fh = xbmcvfs.File(m3u_bak, 'w')
        fh.write(m3u_dat)
        fh.close() 

        new_line = f'#EXTINF:-1 tvg-name="{tvg_name}" group-title="{group_title}" radio="true" tvg-logo="{tvg_logo}",{tvg_name}\n'
        new_stream = f'{stream_url}\n'
        m3u_dat = m3u_dat + new_line + new_stream
            
        fh = xbmcvfs.File(m3u_file, 'w')
        fh.write(m3u_dat)
        fh.close()
        
        heading = tvg_name
        message = "Added to IPTV Simple"
        xbmcgui.Dialog().notification(heading, message, self.icon)


    def import_iptv(self, data):
        default = self.addon.getSettingString('import_iptv_path')
        file_mask = '.m3u'
        file = xbmcgui.Dialog().browse(1, "Select m3u file", "", mask=file_mask, defaultt=default)
        
        if not file.endswith(file_mask):
            return

        head = os.path.split(file)[0] + '\\'
        self.addon.setSettingString('import_iptv_path', head)
        
        fh = xbmcvfs.File(file)
        data = fh.read()
        fh.close()
        
        parser = M3UParser()
        result = parser.parse_data(data)
        
        added = 0
        updated = 0
        my_stations = self.dh.load_list(self.my_stations_list)
        
        for item in result:
            add = True
            for station in my_stations:
                if station['data']['name'] == item['name']:
                    add = False
                    updated += 1
                    station['data']['icon_url'] = item['icon_url']
                    station['data']['stream_url'] = item['stream_url']
                    break
                
            if add:
                if False != item['is_radio']:
                    added += 1
                    record = {'data': {}, 'mode': ''}
                    record['mode'] = 'play_stream'
                    record['data']['id'] = ''
                    record['data']['name'] = item['name']
                    record['data']['icon_url'] = item['icon_url']
                    record['data']['stream_url'] = item['stream_url']
                    my_stations.append(record)
            
        self.dh.save_list(self.my_stations_list, my_stations)
        
        xbmc.log(f'[{self.log_name}] import_iptv: {added} stations added, {updated} stations updated', xbmc.LOGINFO)
        dialog = xbmcgui.Dialog()
        dialog.ok("Radiobrowser", f"{added} stations added\r\n{updated} stations updated")
        
        
    def get_recently(self, data):
        result = self.dh.load_list(self.recent_list)
        self._handle_result('stations_list', result, 'recently_cm')
        
        
    def remove_from_recently(self, data):
        result = self.dh.load_list(self.recent_list)
        
        for item in result:
            if item['data']["id"] == data['id']:
                result.remove(item)
                self.dh.save_list(self.recent_list, result)
                xbmc.executebuiltin( "Container.Refresh" )
                break
    
    def _get_count(self, data, count=20, offset=0):
        count = data.get('count', count)
        offset = data.get('offset', offset)
        return count, offset
        
        
    def _add_to_search(self, query, search_list, tag, max_items=50):
        result = self.dh.load_list(search_list)
        
        for item in result:
            if item['data']["query"] == query:
                return
        
        record = {'data': {}, 'mode': ''}
        record['mode'] = tag
        record['data']['name'] = query
        record['data']['query'] = query
        
        result.insert(0, record)
               
        if( max_items < len(result) ):
            result.pop()

        self.dh.save_list(search_list, result)
    
    
    def _add_to_recently(self, data, max_items=50):
        result = self.dh.load_list(self.recent_list)
        
        for item in result:
            if item['data']["id"] == data["id"]:
                result.remove(item)
                break
        
        record = {'data': {}, 'mode': ''}
        record['mode'] = 'play_stream'
        record['data']['id'] = data['id']
        record['data']['name'] = data['name']
        record['data']['icon_url'] = data['icon_url']
        record['data']['stream_url'] = data['stream_url']
        
        result.insert(0, record)
               
        if( max_items < len(result) ):
            result.pop()

        self.dh.save_list(self.recent_list, result)

        
    def _unify_stations(self, data):
        result = []
        
        if data:
            stations = data
            for item in stations:
                record = {'data': {}, 'mode': ''}
                record['mode'] = 'play_stream'
                record['data']['id'] = item['stationuuid']
                record['data']['name'] = item['name']
                record['data']['icon_url'] = item['favicon']
                record['data']['stream_url'] = item['url_resolved']
                result.append(record)

        return result
    
    
    def _filter_result(self, data, tag, min_count_stations):
        #api_result = data.get(tag, [])
        api_result = data
        
        if api_result and min_count_stations:
            # filter result by minimum count of stations
            result = []
            
            for item in api_result:
                if item['stationcount'] >= min_count_stations:
                    result.append(item)
            
            return result
        
        return api_result
    
    
    def _unify_menu(self, data, mode):
        result = []
        
        data = self._filter_result(data, '', self.min_cnt)

        if data:
            for item in data:
                record = {'data': {}, 'mode': ''}
                record['data']['count'] = 20
                record['data']['offset'] = 0
                record['data']['name'] = item['name']
                record['data']['slug'] = item['name']
                record['mode'] = mode
                result.append(record)
            
        return result
    

    def _add_next(self, data, result, count, offset, mode, **kwargs):
        if data:
            total = len(data)
            
            if  count <= total:
                record = {'data': {}, 'mode': ''}
                record['mode'] = mode
                record['data']['id'] = ''
                record['data']['name'] = 'Next >>'
                record['data']['icon_url'] = ''
                record['data']['stream_url'] = ''
                record["data"]['count'] = count
                record["data"]['offset'] = offset + count
                
                for key, val in kwargs.items():
                    record["data"][key] = val

                result.append(record)
            
        return result
        
        
    def _handle_result(self, mode, result, cm_menu=None):
        li = ListItem(self.addon_path, self.addon_handle)
        
        if 'menu_list' == mode:
            for item in result:
                context_menu = cm_menu
                if 'cm' in item['data']:
                    context_menu = item['data']['cm']
                
                if context_menu:
                    for cm in CM_MAP[context_menu]:
                        li.add_context_menu_item(cm['name'], cm['mode'], item['data'], cm['action'])
                
                li.add_item(item['data']["name"], item["mode"], item["data"], self.icon, self.fanart)
                
        elif 'stations_list' == mode:
            for item in result:
                context_menu = cm_menu
                # if 'cm' in item['data']:
                #     context_menu = item['data']['cm']

                if context_menu:
                    for cm in CM_MAP[context_menu]:
                        li.add_context_menu_item(cm['name'], cm['mode'], item['data'], cm['action'])

                if '' == item['data']["icon_url"]:
                    item["data"]['icon_url'] = self.icon
                
                if 'play_stream' == item["mode"]:
                    li.add_music_item(item['data']["name"], item["mode"], item["data"], item['data']["icon_url"], self.fanart)
                else:
                    li.add_item(item['data']["name"], item["mode"], item["data"], item['data']["icon_url"], self.fanart)
                
        elif 'stations_list_tmp' == mode:
            for item in result:
                context_menu = cm_menu
                # if 'cm' in item['data']:
                #     context_menu = item['data']['cm']

                if context_menu:
                    for cm in CM_MAP[context_menu]:
                        li.add_context_menu_item(cm['name'], cm['mode'], item['data'], cm['action'])

                if '' == item['data']["icon_url"]:
                    item["data"]['icon_url'] = self.icon

                li.add_item(item['data']["name"], item["mode"], item["data"], item['data']["icon_url"], self.fanart)

        li.end_of_directory()
    
    
    
